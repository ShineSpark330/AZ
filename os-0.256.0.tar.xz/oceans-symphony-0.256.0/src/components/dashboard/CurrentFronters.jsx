import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { base44, localEntities } from "@/api/base44Client";
import { TOUR_DEMO_ALTERS } from "@/lib/tourDemoData";
import {
  User, Zap, RefreshCw, X, Edit2, Smile, Activity, AlertTriangle,
  Check, Loader2, BookOpen
} from "lucide-react";
import SwitchJournalModal from "@/components/journal/SwitchJournalModal";
import { saveStatusMentions } from "@/lib/mentionUtils";
import TriggerEditModal from "@/components/fronting/TriggerEditModal";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import { useRotatingImageUrl } from "@/lib/imageRotation";
import { formatDistanceToNow } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import MentionTextarea from "@/components/shared/MentionTextarea";
import { prepareAuthoredText, recordAuthoredText, isLogCommandError } from "@/lib/authoredText";
import { toast } from "sonner";
import SetFrontSheet from "@/components/fronting/SetFrontSheet";
import PrivateMessagesIndicator from "./PrivateMessagesIndicator";
import { useTerms } from "@/lib/useTerms";
import AlterActionMenu from "@/components/alters/AlterActionMenu";
import EmotionWheelPicker from "@/components/emotions/EmotionWheelPicker";
import { removeFrontFor } from "@/hooks/useSwipeActions";
import { useFrontLevels, getSessionLevel, frontLevelLabel } from "@/lib/frontLevels";
import { commitFrontLevel, useHoldDragLevel, FrontLevelRail, useFrontOptionsMenu } from "@/components/fronting/FrontLevelRail";
import SearchableSelect from "@/components/shared/SearchableSelect";
import useAnonymizeMode, { anonymizeBlurNames, anonymizeBlurAvatars } from "@/hooks/useAnonymizeMode";
import UpcomingPlans from "@/components/dashboard/UpcomingPlans";

const TRIGGER_CATEGORIES = [
  { id: "sensory",         label: "Sensory",        emoji: "👂", hint: "loud noise, smell, touch" },
  { id: "emotional",       label: "Emotional",      emoji: "💙", hint: "grief, fear, loneliness" },
  { id: "interpersonal",   label: "Interpersonal",  emoji: "👥", hint: "conflict, rejection" },
  { id: "trauma_reminder", label: "Trauma reminder",emoji: "⚡", hint: "anniversary, place, memory" },
  { id: "physical",        label: "Physical",       emoji: "🫀", hint: "pain, fatigue, illness" },
  { id: "internal",        label: "Internal",       emoji: "🧠", hint: "intrusive thought, body memory" },
  { id: "unknown",         label: "Unknown",        emoji: "❓" },
];

function getContrastColor(hex) {
  if (!hex) return "#ffffff";
  const clean = hex.replace("#", "");
  const r = parseInt(clean.substring(0, 2), 16);
  const g = parseInt(clean.substring(2, 4), 16);
  const b = parseInt(clean.substring(4, 6), 16);
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum > 0.5 ? "#1a1a2e" : "#ffffff";
}

function sessionNoteText(session) {
  if (!session?.note) return "";
  try {
    const parsed = JSON.parse(session.note);
    return Array.isArray(parsed) ? (parsed[parsed.length - 1]?.text || "") : session.note;
  } catch { return session.note; }
}

function FronterChip({ alter, isPrimary, startTime, session, coFronterLabel, holdProps = {}, railActive = false, isExpanded, onToggleExpand }) {
  const bg = alter?.color || null;
  const text = bg ? getContrastColor(bg) : null;
  const navigate = useNavigate();
  const rotatingAvatarUrl = useRotatingImageUrl({ alterId: alter?.id, role: "avatar", mode: alter?.avatar_rotation_mode, fallbackUrl: alter?.avatar_url, alter });
  const resolvedAvatar = useResolvedAvatarUrl(rotatingAvatarUrl);
  // Mirror the anonymize toggle from the Alters page so the chips here
  // blur the same way for screenshots.
  const { mode: anonymize } = useAnonymizeMode();
  const blurNames = anonymizeBlurNames(anonymize);
  const blurAvatar = anonymizeBlurAvatars(anonymize);

  const hasNote = !!sessionNoteText(session);
  const isTriggered = !!session?.is_triggered_switch;
  // Fronting level (opt-in feature) — shown in the subtitle when set.
  const chipTerms = useTerms();
  const chipLevelCfg = useFrontLevels();
  const chipLevelObj = getSessionLevel(session, chipLevelCfg);
  const chipLevel = chipLevelObj ? frontLevelLabel(chipLevelObj, chipTerms) : null;

  // Double-tap detection: open a small "Jump to / Edit session"
  // popover. First tap still fires onToggleExpand (existing behaviour
  // — the per-alter panel briefly opens then sits behind the popover).
  // 350ms is the same threshold the Activity grid uses.
  const lastTapRef = useRef(0);
  const [actionMenuOpen, setActionMenuOpen] = useState(false);

  // The standard gesture trio (owner decision, v0.121.1 — the old
  // swipe-left/right front gestures are gone): tap toggles the per-alter
  // panel, double-tap opens the jump/edit-session popover, press-and-hold
  // opens the level spectrum (its Remove stop takes them off front).
  const handleTap = () => {
    if (railActive || Date.now() < (window.__chipSuppressTapUntil || 0)) return;
    const now = Date.now();
    if (now - lastTapRef.current < 350) {
      lastTapRef.current = 0;
      setActionMenuOpen(true);   // owner spec: double-tap = the alter menu
      return;
    }
    lastTapRef.current = now;
    onToggleExpand?.(alter.id);
  };


  return (
    <>
    <div
      role="button"
      tabIndex={0}
      aria-label={`${alter.name}${chipLevel ? ` — ${chipLevel}` : ""}, ${chipTerms.fronting} for ${startTime ? formatDistanceToNow(new Date(startTime), { addSuffix: false }) : "unknown time"}. Tap to ${isExpanded ? "collapse" : "expand"} the per-alter panel. Double-tap to jump to the session on the Timeline or edit it. Press and hold to set their ${chipTerms.fronting} level or remove them from ${chipTerms.front}.`}
      aria-expanded={!!isExpanded}
      {...holdProps}
      onClick={handleTap}
      onKeyDown={e => e.key === "Enter" || e.key === " " ? onToggleExpand?.(alter.id) : undefined}
      className="flex items-center gap-2.5 bg-card border border-border/50 rounded-2xl px-1.5 py-2 transition-all cursor-pointer select-none hover:border-border hover:bg-muted/20 relative"
    >
      {/* Avatar with badges */}
      <div className="relative flex-shrink-0">
        <div
          className={`w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center border border-border/30 ${blurAvatar ? "blur-sm" : ""}`}
          style={{ backgroundColor: bg || "hsl(var(--muted))" }}
        >
          {resolvedAvatar ? (
            <img src={resolvedAvatar} alt={alter.name} className="w-full h-full object-cover" />
          ) : (
            <User className="w-5 h-5" style={{ color: text || "hsl(var(--muted-foreground))" }} />
          )}
        </div>
        {/* Primary indicator */}
        {isPrimary && (
          <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-green-500 border-2 border-background flex items-center justify-center">
            <Zap className="w-2 h-2 text-white" />
          </div>
        )}
        {/* Note indicator — thought bubble on this alter's avatar */}
        {hasNote && !isPrimary && (
          <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-background border border-border/60 flex items-center justify-center text-[0.5625rem] leading-none">
            💬
          </div>
        )}
        {hasNote && isPrimary && (
          <div className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full bg-background border border-border/60 flex items-center justify-center text-[0.5625rem] leading-none">
            💬
          </div>
        )}
        {/* Triggered indicator */}
        {isTriggered && (
          <div className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-orange-500 border-2 border-background flex items-center justify-center text-[0.5625rem] leading-none">
            ⚡
          </div>
        )}
      </div>

      <div className="min-w-0 flex-1">
        <p className={`text-sm font-semibold text-foreground truncate ${blurNames ? "blur-sm" : ""}`}>{alter.name}</p>
        <p className="text-[0.6875rem] text-muted-foreground truncate">
          {/* The level IS the role now (defaults read Fronting /
              Co-{fronting}, so pre-levels users see the same words). The
              lead still gets the ⚡ badge on their avatar. */}
          {chipLevel ? `${chipLevel} · ` : (isPrimary ? "Primary · " : `${coFronterLabel} · `)}
          {startTime ? formatDistanceToNow(new Date(startTime), { addSuffix: false }) : "—"}
        </p>
      </div>
    </div>

    {/* Double-tap → the alter's full action menu. It carries the session
        tools (jump to Timeline / edit session) when a session is in
        context, so the old two-button popover is no longer needed. */}
    {actionMenuOpen && (
      <AlterActionMenu alter={alter} activeSessions={session ? [session] : []} session={session}
        onClose={() => setActionMenuOpen(false)} />
    )}
    </>
  );
}

// Compact avatar + name header for AlterPanel's controlled (meeting) mode,
// where there's no FronterChip above the panel to identify the alter.
function PanelHeader({ alter, onRemove }) {
  const rotatingAvatarUrl = useRotatingImageUrl({ alterId: alter?.id, role: "avatar", mode: alter?.avatar_rotation_mode, fallbackUrl: alter?.avatar_url, alter });
  const resolvedAvatar = useResolvedAvatarUrl(rotatingAvatarUrl);
  const bg = alter?.color || null;
  const text = bg ? getContrastColor(bg) : null;
  return (
    <div className="flex items-center gap-2.5 px-3 py-2.5 border-b border-border/30">
      <div
        className="w-8 h-8 rounded-xl overflow-hidden flex-shrink-0 flex items-center justify-center border border-border/30"
        style={{ backgroundColor: bg || "hsl(var(--muted))" }}
      >
        {resolvedAvatar
          ? <img src={resolvedAvatar} alt={alter?.name} className="w-full h-full object-cover" />
          : <User className="w-4 h-4" style={{ color: text || "hsl(var(--muted-foreground))" }} />}
      </div>
      <span className="flex-1 min-w-0 text-sm font-semibold text-foreground truncate">{alter?.name}</span>
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          aria-label={`Remove ${alter?.name}`}
          className="p-1 rounded-full text-muted-foreground hover:text-destructive transition-colors flex-shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}

// Hold-menu header avatar — resolves legacy local-image:// avatars the same
// way FronterChip / PanelHeader do (a raw <img src> on those renders broken).
function HoldMenuAvatar({ alter }) {
  const rotatingAvatarUrl = useRotatingImageUrl({ alterId: alter?.id, role: "avatar", mode: alter?.avatar_rotation_mode, fallbackUrl: alter?.avatar_url, alter });
  const resolvedAvatar = useResolvedAvatarUrl(rotatingAvatarUrl);
  return resolvedAvatar
    ? <img src={resolvedAvatar} alt={alter.name} className="w-full h-full object-cover" />
    : <User className="w-5 h-5 text-muted-foreground" />;
}

// AlterPanel — the per-alter "currently fronting" panel: avatar + name (via
// the FronterChip above), EmotionWheelPicker, 1–5 / boolean symptom rows, and
// a free-text note.
//
// Two modes, switched purely by props so existing callers are untouched:
//
//   1. Session mode (default, used by CurrentFronters): pass `session`. The
//      panel reads the FrontingSession's JSON-string payloads and WRITES back
//      to the FrontingSession on the Save button. Exactly the original behaviour.
//
//   2. Controlled mode (used by the System Meeting participants section): pass
//      `participant` ({ alter_id, emotions, symptoms, note }) + `onChange`.
//      The panel becomes a controlled editor — every edit is pushed up via
//      `onChange(nextParticipant)` and the host persists it (here, on the
//      SystemCheckIn.participants array). No FrontingSession is read or written
//      and the DB Save button is replaced by the host's overall save. The
//      symptom shape is the same `[{ id, label, value, type }]` array the
//      fronting flow uses, so analytics / reports read it identically.
export function AlterPanel({ alter, session, onClose, onSaved, participant, onChange, hideHeader = false }) {
  const terms = useTerms();
  const queryClient = useQueryClient();
  const controlled = !session && !!onChange;
  const { data: panelAlters = [] } = useQuery({ queryKey: ["alters"], queryFn: () => base44.entities.Alter.list() });

  const [note, setNote] = useState(() =>
    controlled ? (participant?.note || "") : sessionNoteText(session)
  );

  const [showEmotions, setShowEmotions] = useState(false);
  const [localEmotions, setLocalEmotions] = useState(() => {
    if (controlled) return Array.isArray(participant?.emotions) ? participant.emotions : [];
    try { return JSON.parse(session?.session_emotions || "[]"); } catch { return []; }
  });

  const [showSymptoms, setShowSymptoms] = useState(false);
  const [symptomValues, setSymptomValues] = useState(() => {
    if (controlled) {
      const map = {};
      for (const it of (participant?.symptoms || [])) if (it?.id) map[it.id] = it.value;
      return map;
    }
    // session_symptoms exists on disk in two shapes: the current array of
    // { id, label, value, type } (what handleSave below writes) and an older
    // id→value map. Normalise to the map shape we use internally — without
    // this, re-editing a session loaded as an array dropped every previously
    // recorded symptom on save.
    try {
      const parsed = JSON.parse(session?.session_symptoms || "[]");
      if (Array.isArray(parsed)) {
        const map = {};
        for (const it of parsed) if (it?.id) map[it.id] = it.value;
        return map;
      }
      if (parsed && typeof parsed === "object") return parsed;
      return {};
    } catch { return {}; }
  });

  const [showTrigger, setShowTrigger] = useState(!!session?.is_triggered_switch);
  const [triggerCategory, setTriggerCategory] = useState(session?.trigger_category || "");
  const [triggerLabel, setTriggerLabel] = useState(session?.trigger_label || "");
  const [saving, setSaving] = useState(false);

  const { data: symptoms = [] } = useQuery({
    queryKey: ["symptoms"],
    queryFn: () => base44.entities.Symptom.list(),
  });
  const { data: customEmotions = [] } = useQuery({
    queryKey: ["customEmotions"],
    queryFn: () => base44.entities.CustomEmotion.list(),
  });
  const { data: customTriggerTypes = [] } = useQuery({
    queryKey: ["customTriggerTypes"],
    queryFn: () => base44.entities.TriggerType.list(),
  });
  const allTriggerCategories = [
    ...TRIGGER_CATEGORIES,
    ...customTriggerTypes.map(t => ({ id: t.id, label: t.label, emoji: t.emoji || "🏷️", hint: t.hint || "" })),
  ];

  const activeSymptoms = symptoms.filter(s => !s.is_archived);
  const levelCfg = useFrontLevels();

  // Build the canonical [{ id, label, value, type }] symptom array from the
  // internal id→value map (same shape handleSave writes for sessions). The
  // label/type come from the live symptoms catalogue, but if it hasn't loaded
  // yet (or a symptom was archived/deleted) we fall back to the label/type the
  // participant already had recorded — so an existing meeting's symptoms are
  // never clobbered just because the catalogue query is still in flight.
  const buildSymptomArr = (map) => {
    const existing = {};
    for (const it of (participant?.symptoms || [])) if (it?.id) existing[it.id] = it;
    return Object.entries(map)
      .filter(([, v]) => v !== null && v !== undefined && v !== 0 && v !== false)
      .map(([id, value]) => {
        const s = symptoms.find(x => x.id === id);
        if (s) return { id, label: s.label, value, type: s.type };
        const prev = existing[id];
        return prev ? { id, label: prev.label, value, type: prev.type } : null;
      })
      .filter(Boolean);
  };

  // Controlled mode: mirror local edits up to the host (SystemCheckIn
  // participants) on every change. No DB write — the host persists the
  // participants array on the meeting record when the meeting is saved.
  useEffect(() => {
    if (!controlled) return;
    onChange?.({
      alter_id: participant?.alter_id || alter.id,
      emotions: localEmotions,
      symptoms: buildSymptomArr(symptomValues),
      note: note,
    });
     
  }, [controlled, note, localEmotions, symptomValues, symptoms]);

  const addCustomEmotionMutation = useMutation({
    mutationFn: async ({ label, category = "custom", color }) => {
      const cleanLabel = (label || "").trim();
      if (!cleanLabel) return null;
      const existing = customEmotions.find((e) => e.label.toLowerCase() === cleanLabel.toLowerCase());
      if (existing) return existing;
      return base44.entities.CustomEmotion.create({ label: cleanLabel, category, ...(color ? { color } : {}) });
    },
    onSuccess: (emotion) => {
      if (!emotion) return;
      setLocalEmotions((prev) => prev.includes(emotion.label) ? prev : [...prev, emotion.label]);
      queryClient.invalidateQueries({ queryKey: ["customEmotions"] });
    },
    onError: (e) => {
      toast.error(e?.message || "Couldn't add custom emotion");
    },
  });

  const handleSave = async () => {
    if (!session) return;
    // ONE pipeline for the note: ~commands, whispers, signposts, @mentions.
    // This alter signs their own note unless a signpost says otherwise.
    let prepared;
    try { prepared = await prepareAuthoredText(note || "", { alters: panelAlters, terms, surfaceLabel: "note", baseAuthorIds: alter?.id ? [alter.id] : [] }); }
    catch (e) { if (isLogCommandError(e)) { toast.error(e.message); return; } throw e; }
    if (prepared === null) return;
    const cleanNote = prepared.content.trim();
    setSaving(true);
    try {
      const nowIso = new Date().toISOString();
      const updates = {};

      // Note — alter-specific, appended to this session's note array (shows as 💬 on timeline)
      if (cleanNote) {
        let existing = [];
        try { const parsed = JSON.parse(session.note || "[]"); existing = Array.isArray(parsed) ? parsed : []; } catch {}
        updates.note = JSON.stringify([...existing, { text: cleanNote, timestamp: nowIso }]);
      }

      if (localEmotions.length > 0) {
        updates.session_emotions = JSON.stringify(localEmotions);
      }

      const symptomArr = Object.entries(symptomValues)
        .filter(([, v]) => v !== null && v !== undefined && v !== 0 && v !== false)
        .map(([id, value]) => {
          const s = symptoms.find(x => x.id === id);
          return s ? { id, label: s.label, value, type: s.type } : null;
        })
        .filter(Boolean);
      if (symptomArr.length > 0) updates.session_symptoms = JSON.stringify(symptomArr);

      if (showTrigger && triggerCategory) {
        updates.is_triggered_switch = true;
        updates.trigger_category = triggerCategory;
        updates.trigger_label = triggerLabel;
      }

      await base44.entities.FrontingSession.update(session.id, updates);
      if (cleanNote) {
        await recordAuthoredText({ ...prepared, alters: panelAlters, sourceType: "session-note", sourceId: session.id, sourceLabel: "Session note", navigatePath: "/timeline" });
      }
      queryClient.invalidateQueries({ queryKey: ["frontHistory"] });
      // The edited row is an ACTIVE session — refresh the canonical query the
      // dashboard / notification / friends-sync read, or they'd show stale data.
      queryClient.invalidateQueries({ queryKey: ["activeFront"] });
      toast.success("Saved");
      onSaved();
    } catch {
      toast.error("Failed to save");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={`${controlled ? "" : "col-span-2"} rounded-xl bg-card border border-border/50 overflow-hidden`}>

      {/* Optional avatar + name header (controlled mode shows it because there's
          no FronterChip above the panel; session mode keeps the chip header). */}
      {!hideHeader && controlled && (
        <PanelHeader alter={alter} onRemove={onClose} />
      )}

      {/* Plans for this alter — surfaced inline. Only in session mode: a
          meeting participant panel isn't a fronting context. */}
      {!controlled && (
        <div className="px-3 pt-3">
          <UpcomingPlans
            placement="alter_panel"
            filterByAlterId={alter.id}
            title={`📅 Plans for ${alter.name}`}
            limit={3}
          />
        </div>
      )}

      {/* Fronting level (opt-in) — how close to front this alter is.
          Session mode only; writes through the canonical refetch-before-
          write helper so it can never race the modal or the rail. */}
      {!controlled && session && levelCfg.enabled && (
        <div className="px-3 pt-2 flex items-center gap-2">
          <span className="text-xs text-muted-foreground flex-shrink-0">{terms.Front} level</span>
          <div className="flex-1 min-w-0">
            <SearchableSelect
              value={session.front_level || levelCfg.levels[0]?.id}
              onChange={async (v) => { if (v) await commitFrontLevel({ alterId: alter.id, levelId: v, queryClient }); }}
              options={levelCfg.levels.map(l => ({ id: l.id, label: frontLevelLabel(l, terms) }))}
              placeholder={`Set ${terms.front} level...`}
              searchPlaceholder="Search levels..."
            />
          </div>
        </div>
      )}

      {/* Note — bare textarea, no chrome */}
      <div className="px-3 pt-1 pb-2">
        <MentionTextarea
          value={note}
          onChange={setNote}
          alters={panelAlters}
          signposts
          placeholder={`Note for ${alter.name}... appears as 💬 on their timeline`}
          className="text-sm resize-none border-0 bg-transparent p-0 focus-visible:ring-0 min-h-[52px] placeholder:text-muted-foreground/40 placeholder:text-xs"
          rows={2}
        />
      </div>

      {/* Action row — icons only so labels never wrap on narrow screens. */}
      <div className="px-3 pb-3 flex items-center gap-1.5">
        <button
          onClick={() => { setShowEmotions(v => !v); setShowSymptoms(false); setShowTrigger(false); }}
          aria-label="Add emotions"
          aria-expanded={showEmotions}
          title="Emotions"
          className={`flex items-center justify-center gap-1 min-w-[34px] h-[28px] px-2 rounded-full text-xs border whitespace-nowrap transition-all ${
            showEmotions ? "bg-primary text-primary-foreground border-primary" : "text-muted-foreground border-border hover:bg-muted/50"
          }`}
        >
          <Smile className="w-3.5 h-3.5" />
          {localEmotions.length > 0 && <span>{localEmotions.length}</span>}
        </button>

        <button
          onClick={() => { setShowSymptoms(v => !v); setShowEmotions(false); setShowTrigger(false); }}
          aria-label="Add symptoms"
          aria-expanded={showSymptoms}
          title="Symptoms"
          className={`flex items-center justify-center min-w-[34px] h-[28px] px-2 rounded-full text-xs border whitespace-nowrap transition-all ${
            showSymptoms ? "bg-primary text-primary-foreground border-primary" : "text-muted-foreground border-border hover:bg-muted/50"
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
        </button>

        {!controlled && (
          <button
            onClick={() => { setShowTrigger(v => !v); setShowEmotions(false); setShowSymptoms(false); }}
            aria-label={`Mark triggered ${terms.switch}`}
            aria-expanded={showTrigger}
            title={`Triggered ${terms.switch}`}
            className={`flex items-center justify-center min-w-[34px] h-[28px] px-2 rounded-full text-xs border whitespace-nowrap transition-all ${
              showTrigger
                ? "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700"
                : "text-muted-foreground border-border hover:bg-muted/50"
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
          </button>
        )}

        {/* Controlled mode persists via the host's overall save — no per-panel
            DB Save button. Session mode keeps Close + Save. */}
        {!controlled && (
          <div className="ml-auto flex items-center gap-1.5">
            <button onClick={onClose} aria-label="Close panel" className="p-1 text-muted-foreground hover:text-foreground transition-colors">
              <X className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
              Save
            </button>
          </div>
        )}
      </div>

      {/* Emotion picker */}
      {showEmotions && (
        <div className="border-t border-border/30 px-3 py-2">
          <EmotionWheelPicker
            selectedEmotions={localEmotions}
            onToggle={label => setLocalEmotions(prev =>
              prev.includes(label) ? prev.filter(e => e !== label) : [...prev, label]
            )}
            customEmotions={customEmotions}
            onAddCustom={(label, category, color) => addCustomEmotionMutation.mutate({ label, category, color })}
          />
        </div>
      )}

      {/* Symptom list */}
      {showSymptoms && (
        <div className="border-t border-border/30 px-3 py-2 space-y-2 max-h-44 overflow-y-auto">
          {activeSymptoms.length === 0 && (
            <p className="text-xs text-muted-foreground/60 italic">No symptoms configured yet.</p>
          )}
          {activeSymptoms.map(s => (
            <div key={s.id} className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: s.color || "#8b5cf6" }} />
              <span className="text-xs flex-1 truncate text-muted-foreground">{s.label}</span>
              {s.type === "boolean" ? (
                <input
                  type="checkbox"
                  checked={!!symptomValues[s.id]}
                  onChange={e => setSymptomValues(v => ({ ...v, [s.id]: e.target.checked ? 1 : 0 }))}
                  className="w-3.5 h-3.5 accent-primary"
                />
              ) : (
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map(n => (
                    <button
                      key={n}
                      onClick={() => setSymptomValues(v => ({ ...v, [s.id]: v[s.id] === n ? 0 : n }))}
                      className={`w-5 h-5 rounded text-[0.625rem] border transition-colors ${
                        (symptomValues[s.id] || 0) >= n
                          ? "bg-primary text-primary-foreground border-primary"
                          : "border-border text-muted-foreground"
                      }`}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Trigger selector */}
      {showTrigger && (
        <div className="border-t border-border/30 px-3 py-2.5 space-y-2">
          <div className="flex flex-wrap gap-1">
            {allTriggerCategories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setTriggerCategory(c => c === cat.id ? "" : cat.id)}
                title={cat.hint}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-all ${
                  triggerCategory === cat.id
                    ? "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700"
                    : "text-muted-foreground border-border/60 hover:bg-muted/50"
                }`}
              >
                {cat.emoji} {cat.label}
              </button>
            ))}
          </div>
          <input
            value={triggerLabel}
            onChange={e => setTriggerLabel(e.target.value)}
            placeholder="Describe what happened..."
            className="w-full text-xs bg-transparent border-0 border-b border-border/40 pb-1 outline-none text-foreground placeholder:text-muted-foreground/40 focus:border-border"
          />
        </div>
      )}
    </div>
  );
}

export default function CurrentFronters({ alters, hideStatusNote = false }) {
  const [showModal, setShowModal] = useState(false);
  // Post-hoc switch metadata: open the same Trigger picker and Switch
  // journal flows that the SetFront modal offers, even when the user
  // didn't go through that modal to set the front (e.g. they used a
  // long-press shortcut or a quick action). Icons live next to the
  // Switch button below.
  const [showTriggerEdit, setShowTriggerEdit] = useState(false);
  const [showSwitchJournal, setShowSwitchJournal] = useState(false);
  const [switchJournalSessionId, setSwitchJournalSessionId] = useState(null);
  const [switchJournalAuthorAlterId, setSwitchJournalAuthorAlterId] = useState(null);
  const [expandedAlterId, setExpandedAlterId] = useState(null);
  const navigate = useNavigate();

  // The "open-set-front" event is handled by the Dashboard's single host
  // now — this component only listens for the close broadcast, so a panel
  // sitting on the v2 board can't open a SECOND sheet on top of the
  // host's. Its own Switch button still opens its local sheet directly.
  useEffect(() => {
    const close = () => setShowModal(false);
    window.addEventListener("open-set-front-close", close);
    return () => window.removeEventListener("open-set-front-close", close);
  }, []);

  const [editingStatus, setEditingStatus] = useState(false);
  const [tempStatus, setTempStatus] = useState("");
  const queryClient = useQueryClient();
  const terms = useTerms();
  // ONE hold-drag rail serves every chip (v0.121.1 — the chips' old
  // swipe-left/right front gestures are fully replaced by the standard
  // hold gesture; the rail's Remove stop covers remove-from-front).
  const chipLevelCfgMain = useFrontLevels();
  // Drag RIGHT on a fronting chip = the alter's options menu (unified
  // gesture grammar — this surface uses the hold-drag hook directly, so
  // it hosts the menu itself).
  const chipOptionsMenu = useFrontOptionsMenu((alterId) => alters.find((x) => x.id === alterId) || null);
  const { rail: chipRail, getHoldProps: getChipHoldProps } = useHoldDragLevel({
    cfg: chipLevelCfgMain,
    onCommit: (alterId, levelId, extras = {}) => {
      window.__chipSuppressTapUntil = Date.now() + 400;
      commitFrontLevel({ alterId, levelId, queryClient, cfg: chipLevelCfgMain, solo: !!extras.solo });
    },
    onRemove: (alterId) => {
      window.__chipSuppressTapUntil = Date.now() + 400;
      const a = alters.find((x) => x.id === alterId);
      if (a) removeFrontFor(a, base44, queryClient, toast, terms);
    },
    onOptions: (alterId) => {
      window.__chipSuppressTapUntil = Date.now() + 400;
      chipOptionsMenu.openOptions(alterId);
    },
  });

  // Read the SAME canonical active-front query the rest of the app uses and
  // invalidates after every set-front / switch (FrontingBar, the persistent
  // notification, friends front-sync). Previously this widget read the 50-row
  // ["frontHistory"] list and filtered in memory — a different cache that the
  // write paths didn't always refresh, so the dashboard could show "no one
  // fronting" off stale data even when a front was set. The server-side
  // { is_active: true } filter is also the correct predicate (excludes ended /
  // ghost rows) and never relies on the active row being in the newest 50.
  const { data: activeFrontRows = [] } = useQuery({
    queryKey: ["activeFront"],
    queryFn: () => base44.entities.FrontingSession.filter({ is_active: true }),
  });
  // Most-recent-first, matching the old "-start_time" ordering this widget
  // relied on for its fallback active pick + display order.
  const realActiveSessions = [...activeFrontRows].sort(
    (a, b) => new Date(b.start_time || 0) - new Date(a.start_time || 0)
  );

  // Latest status note for display — sorted descending, just grab first
  const { data: allStatusNotes = [] } = useQuery({
    queryKey: ["statusNotes"],
    queryFn: () => localEntities.StatusNote.list(),
  });
  const latestStatusNote = allStatusNotes
    .slice()
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))[0] ?? null;

  const isDemo = realActiveSessions.length === 0 && !!window.__tourActive;
  const demoAlterSource = alters.length > 0 ? alters.slice(0, 2) : TOUR_DEMO_ALTERS.slice(0, 2);
  const demoSessions = isDemo
    ? demoAlterSource.map((a, i) => ({
        id: `_tour_s${i}`, alter_id: a.id, is_primary: false, is_active: true,
        start_time: new Date(Date.now() - (i + 1) * 20 * 60 * 1000).toISOString(),
      }))
    : [];
  const activeSessions = isDemo ? demoSessions : realActiveSessions;
  const demoAltersById = Object.fromEntries(demoAlterSource.map(a => [a.id, a]));
  const altersById = isDemo
    ? { ...Object.fromEntries(alters.map((a) => [a.id, a])), ...demoAltersById }
    : Object.fromEntries(alters.map((a) => [a.id, a]));
  // Prefer a real primary (new-model row with is_primary). For legacy rows,
  // do NOT treat them as primary unconditionally — that would let a legacy
  // session shadow a real primary in new-model rows whenever both shapes
  // coexist briefly during a migration. Legacy rows fall through to the
  // `|| activeSessions[0]` fallback below if no new-model primary exists.
  const primarySession = activeSessions.find(s => s.alter_id ? s.is_primary : false);
  const active = primarySession || activeSessions[0] || null;

  const primaryAlterId = primarySession?.alter_id || active?.primary_alter_id || null;

  // If the active session changes (switch, fronter added/removed), close
  // any open per-alter panel since the session it referenced may be gone.
  useEffect(() => { setExpandedAlterId(null); }, [active?.id]);

  const handleSetPrimaryFromHold = async (alter) => {
    try {
      // Refetch so the handler doesn't act on a stale `activeSessions`
      // closure and so we can find every existing primary, not just the first.
      const fresh = await base44.entities.FrontingSession.filter({ is_active: true });
      const newModel = fresh.filter(s => s.alter_id);
      if (newModel.length > 0) {
        const targetSession = newModel.find(s => s.alter_id === alter.id);
        // Demote every existing primary so we never leave duplicates.
        for (const s of newModel.filter(s => s.is_primary && s.alter_id !== alter.id)) {
          try { await base44.entities.FrontingSession.update(s.id, { is_primary: false }); } catch {}
        }
        if (targetSession) {
          await base44.entities.FrontingSession.update(targetSession.id, { is_primary: true });
        } else {
          await base44.entities.FrontingSession.create({
            alter_id: alter.id,
            is_primary: true,
            start_time: new Date().toISOString(),
            is_active: true,
          });
        }
      } else if (active) {
        const newCoFronters = [active.primary_alter_id, ...(active.co_fronter_ids || [])].filter(id => id !== alter.id);
        await base44.entities.FrontingSession.update(active.id, { primary_alter_id: alter.id, co_fronter_ids: newCoFronters });
      }
      queryClient.invalidateQueries({ queryKey: ["activeFront"] });
      queryClient.invalidateQueries({ queryKey: ["frontHistory"] });
      toast.success(`${alter.name} is now primary!`);
    } catch { toast.error(`Failed to update primary ${terms.fronter}`); }
  };

  const handleRemoveFromFront = async (alter) => {
    try {
      // Refetch — the closure-captured `activeSessions` snapshot may be
      // stale, AND if duplicate active rows exist for this alter (e.g.
      // after a botched sync) the old `.find()` would only end the first
      // one and leave the rest active. End EVERY active row matching this
      // alter so the alter is truly off front.
      const fresh = await base44.entities.FrontingSession.filter({ is_active: true });
      const now = new Date().toISOString();
      const targets = fresh.filter(s => (s.alter_id || s.primary_alter_id) === alter.id);
      for (const s of targets) {
        try { await base44.entities.FrontingSession.update(s.id, { is_active: false, end_time: now }); } catch {}
      }
      queryClient.invalidateQueries({ queryKey: ["frontHistory"] });
      queryClient.invalidateQueries({ queryKey: ["activeFront"] });
      toast.success(`${alter.name} removed from ${terms.front}`);
    } catch { toast.error("Failed to remove"); }
  };

  // Refetch active sessions at click-time, then open the switch-journal
  // modal pointing at the CURRENT primary's id. The render-time
  // `activeSessions` snapshot can be stale if a switch happened between
  // last render and click — using it could attach journal entries to an
  // ended/deleted session.
  const handleOpenSwitchJournal = async () => {
    try {
      const fresh = await base44.entities.FrontingSession.filter({ is_active: true });
      const target = fresh.find(s => s.is_primary) || fresh[0];
      setSwitchJournalSessionId(target?.id || null);
      setSwitchJournalAuthorAlterId(target?.alter_id || target?.primary_alter_id || null);
      setShowSwitchJournal(true);
    } catch {
      // Fall back to closure snapshot if refetch fails — better than nothing.
      const target = activeSessions.find(s => s.is_primary) || activeSessions[0];
      setSwitchJournalSessionId(target?.id || null);
      setSwitchJournalAuthorAlterId(primaryAlterId);
      setShowSwitchJournal(true);
    }
  };

  const handleSaveStatus = async () => {
    const note = tempStatus.trim();
    if (!note) { setEditingStatus(false); return; }
    setEditingStatus(false);
    setTempStatus("");
    // Each save creates a NEW immutable timestamped record — never overwrites old ones
    const created = await localEntities.StatusNote.create({
      timestamp: new Date().toISOString(),
      note,
    });
    // @mentions notify like every other surface.
    await saveStatusMentions({ note, alters, sourceId: created?.id, authorAlterId: primaryAlterId });
    queryClient.invalidateQueries({ queryKey: ["mentionLogs"] });
    queryClient.invalidateQueries({ queryKey: ["statusNotes"] });
    toast.success("Status saved");
  };

  if (!active) {
    return (
      <>
        <div className="bg-muted/40 border border-border/40 rounded-2xl px-4 py-4 mb-5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-muted-foreground/30" />
            <p className="text-sm text-muted-foreground">No one is currently {terms.fronting}</p>
          </div>
          <Button data-tour="set-front" size="sm" variant="outline" onClick={() => setShowModal(true)} className="gap-1.5 text-xs">
            <RefreshCw className="w-3 h-3" /> Set {terms.Front}
          </Button>
        </div>
        <SetFrontSheet open={showModal} onClose={() => setShowModal(false)} alters={alters} />
      </>
    );
  }

  let primary = null;
  let coFronters = [];
  if (activeSessions.some(s => s.alter_id)) {
    const primarySess = activeSessions.find(s => s.alter_id && s.is_primary);
    const coSessions = activeSessions.filter(s => s.alter_id && !s.is_primary);
    primary = primarySess ? altersById[primarySess.alter_id] : null;
    // Dedupe co-fronter sessions by alter_id (and exclude the primary's
    // alter_id if there is one). Avoids the previous side-effect-in-filter
    // anti-pattern that relied on `Set.add()` returning truthy.
    const seenIds = new Set(primarySess?.alter_id ? [primarySess.alter_id] : []);
    const dedupedCoSessions = [];
    for (const s of coSessions) {
      if (seenIds.has(s.alter_id)) continue;
      seenIds.add(s.alter_id);
      dedupedCoSessions.push(s);
    }
    coFronters = dedupedCoSessions.map(s => altersById[s.alter_id]).filter(Boolean);
  } else {
    primary = altersById[active.primary_alter_id];
    coFronters = (active.co_fronter_ids || []).map(id => altersById[id]).filter(Boolean);
  }
  const all = [primary, ...coFronters].filter(Boolean);
  // Guarantee the primary fronter is always the first chip, whatever order the
  // sessions came back in (stable for everyone else).
  if (primaryAlterId) {
    all.sort((a, b) => (a.id === primaryAlterId ? -1 : 0) - (b.id === primaryAlterId ? -1 : 0));
  }

  return (
    <>
      <div className="mb-4" data-tour="fronters-widget">
        {isDemo && (
          <div className="mb-2 px-2 py-1 rounded-md bg-primary/10 border border-primary/20 text-[0.625rem] text-primary/80 text-center">
            Tour Preview — sample data
          </div>
        )}
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <p className="text-muted-foreground text-xs font-semibold uppercase tracking-wider">Currently {terms.Fronting}</p>
          </div>
          <div className="flex items-center gap-1">
            {/* Post-hoc switch metadata icons. Visible whenever there's
                at least one active fronting session so users can flag
                the switch as triggered or journal it after the fact,
                regardless of how the switch was actually made (long-
                press, quick action, etc.) without going through the
                full Set Fronters flow. */}
            {activeSessions.length > 0 && !isDemo && (
              <>
                <button
                  type="button"
                  onClick={() => setShowTriggerEdit(true)}
                  aria-label={`Flag the current ${terms.switch} as triggered`}
                  title={`Flag this ${terms.switch} as triggered`}
                  className={`min-w-[28px] min-h-[28px] flex items-center justify-center rounded-md transition-colors ${
                    activeSessions.some(s => s.is_triggered_switch)
                      ? "text-orange-500 bg-orange-500/10 hover:bg-orange-500/20"
                      : "text-muted-foreground hover:text-orange-500 hover:bg-orange-500/10"
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={handleOpenSwitchJournal}
                  aria-label={`Journal this ${terms.switch}`}
                  title={`Journal this ${terms.switch}`}
                  className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                </button>
              </>
            )}
            <Button data-tour="set-front" size="sm" variant="outline" onClick={() => setShowModal(true)} className="gap-1.5 text-xs h-7 px-2.5">
              <RefreshCw className="w-3 h-3" /> {terms.Switch}
            </Button>
          </div>
        </div>

        <div className="mb-2 grid grid-cols-2 gap-2">
          {all.map((alter, i) => {
            const alterSession = activeSessions.find(s => (s.alter_id || s.primary_alter_id) === alter.id);
            // Trust the session's own `is_primary` flag. The previous
            // `|| alter.id === primary?.id` fallback masked the case where
            // the session disagreed with the elected primary — better to
            // surface the disagreement than paper over it.
            const isPrimaryAlter = !!alterSession?.is_primary;
            return (
              <React.Fragment key={alter.id}>
                <FronterChip
                  alter={alter}
                  isPrimary={isPrimaryAlter}
                  startTime={alterSession?.start_time}
                  session={alterSession}
                  coFronterLabel={`Co-${terms.fronting}`}
                  holdProps={getChipHoldProps(alter.id, alterSession?.front_level)}
                  railActive={!!chipRail}
                  isExpanded={expandedAlterId === alter.id}
                  onToggleExpand={(id) => setExpandedAlterId(prev => prev === id ? null : id)}
                />
                {/* Per-alter panel — opens inline directly under THIS chip
                    (spanning both columns) when it's tapped, so the note sits
                    under the alter it belongs to, not below the whole grid. */}
                {expandedAlterId === alter.id && alterSession && (
                  <div className="col-span-2 mb-1">
                    <AlterPanel
                      alter={alter}
                      session={alterSession}
                      onClose={() => setExpandedAlterId(null)}
                      onSaved={() => setExpandedAlterId(null)}
                    />
                  </div>
                )}
              </React.Fragment>
            );
          })}

        </div>

        <FrontLevelRail rail={chipRail} cfg={chipLevelCfgMain} withRemove
          alterName={chipRail ? (alters.find((a) => a.id === chipRail.alterId)?.name || "") : ""} />
        {chipOptionsMenu.node}
        <PrivateMessagesIndicator activeFronters={all} />

        {/* Custom status — each save is a new timestamped record, old
            ones never change. When the dashboard layout enables the
            standalone <StatusNoteCard /> separately, we hide the inline
            copy here so the input doesn't render twice. */}
        {hideStatusNote ? null : editingStatus ? (
          <div className="flex gap-2 items-center">
            <Input
              value={tempStatus}
              onChange={e => setTempStatus(e.target.value)}
              placeholder="What's happening right now..."
              className="text-sm h-8 flex-1"
              autoFocus
              onKeyDown={e => { if (e.key === "Enter") handleSaveStatus(); if (e.key === "Escape") { setTempStatus(""); setEditingStatus(false); } }}
            />
            <Button size="sm" onClick={handleSaveStatus} className="gap-1.5 text-xs h-8 px-2.5">Save</Button>
            <Button size="sm" variant="outline" onClick={() => { setTempStatus(""); setEditingStatus(false); }} className="h-8 px-2">
              <X className="w-3 h-3" />
            </Button>
          </div>
        ) : (
          <button
            onClick={() => { setTempStatus(""); setEditingStatus(true); }}
            data-tour="status-note"
            className="w-full text-left px-3 py-2 rounded-lg bg-muted/30 border border-border/50 hover:bg-muted/50 transition-colors text-xs text-muted-foreground hover:text-foreground flex items-center justify-between gap-2"
          >
            {latestStatusNote
              ? <span className="truncate">💬 {latestStatusNote.note}</span>
              : <span className="italic">Set a new status...</span>
            }
            <Edit2 className="w-3 h-3 flex-shrink-0" />
          </button>
        )}
      </div>
      <SetFrontSheet open={showModal} onClose={() => setShowModal(false)} alters={alters} />

      <TriggerEditModal
        open={showTriggerEdit}
        onClose={() => setShowTriggerEdit(false)}
        sessions={activeSessions}
      />

      {showSwitchJournal && (
        <SwitchJournalModal
          open={showSwitchJournal}
          onClose={() => setShowSwitchJournal(false)}
          // sessionId/authorAlterId captured by handleOpenSwitchJournal at
          // click-time via a fresh DB read — never the stale render snapshot.
          sessionId={switchJournalSessionId}
          authorAlterId={switchJournalAuthorAlterId || primaryAlterId}
        />
      )}

    </>
  );
}
