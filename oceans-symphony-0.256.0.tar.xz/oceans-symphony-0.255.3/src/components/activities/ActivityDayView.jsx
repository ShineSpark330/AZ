import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { createPortal } from "react-dom";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import { format } from "date-fns";
import { ArrowLeft, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44, localEntities } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { parseDate, activityDate } from "@/lib/dateUtils";
import { datesForDay } from "@/lib/importantDates";
import { getCategoryMeta } from "@/lib/locationCategories";
import {
  emotionColor,
  getActivityColor,
  getActivitiesForSlot,
  getAlterIdsForSlot,
  getEmotionsForSlot,
  getLocationsForSlot,
} from "./activityHelpers";
import { statusFor, visualForStatus, isPastTimeScheduled, countableMinutes, ACTIVITY_STATUSES, STATUS_LABELS } from "@/lib/activityStatus";

function EmotionPills({ emotions }) {
  if (!emotions || emotions.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {emotions.map((em, i) => (
        <span
          key={i}
          className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-white text-[0.625rem] font-medium"
          style={{ backgroundColor: emotionColor(em) }}
        >
          {em}
        </span>
      ))}
    </div>
  );
}

function LocationPills({ locations }) {
  if (!locations || locations.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {locations.map((loc, i) => {
        const cat = getCategoryMeta(loc.category);
        return (
          <span
            key={i}
            className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[0.625rem] font-medium"
            style={{ backgroundColor: cat.color + "22", color: cat.color, border: `1px solid ${cat.color}66` }}
          >
            {cat.emoji} {loc.name || cat.label}
          </span>
        );
      })}
    </div>
  );
}

function SymptomPills({ symptomIds, symptomsMap }) {
  if (!symptomIds || symptomIds.length === 0) return null;
  const symptoms = symptomIds.map(id => symptomsMap[id]).filter(Boolean);
  if (symptoms.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {symptoms.map(s => (
        <span
          key={s.id}
          className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[0.625rem] font-medium border"
          style={{ borderColor: s.color || "#94a3b8", color: s.color || "#94a3b8", backgroundColor: (s.color || "#94a3b8") + "22" }}
        >
          {s.label}
        </span>
      ))}
    </div>
  );
}

const INTERVAL = 60;
const ALL_HOURS = Array.from({ length: 24 }, (_, i) => i);

function formatHour(h) {
  const period = h < 12 ? "am" : "pm";
  return `${h % 12 || 12}${period}`;
}

// Build segments: consecutive empty hours → one collapsed band; active hours → individual rows
function buildSegments(getSlotData) {
  const segments = [];
  let emptyBand = null;

  for (const hour of ALL_HOURS) {
    const data = getSlotData(hour);
    const isEmpty = data.timed.length === 0 && data.logged.length === 0;

    if (isEmpty) {
      if (!emptyBand) {
        emptyBand = { type: "empty", startHour: hour, endHour: hour };
      } else {
        emptyBand.endHour = hour;
      }
    } else {
      if (emptyBand) { segments.push(emptyBand); emptyBand = null; }
      segments.push({ type: "active", hour, data });
    }
  }
  if (emptyBand) segments.push(emptyBand);
  return segments;
}

function AlterAvatar({ alterId, alters }) {
  const alter = alters.find(a => a.id === alterId);
  const resolvedUrl = useResolvedAvatarUrl(alter?.avatar_url);
  const [imgErrorFor, setImgError] = useState(null);
  const imgError = !!imgErrorFor && imgErrorFor === resolvedUrl;
  return (
    <div
      className="w-5 h-5 rounded-full border-2 border-white/80 overflow-hidden flex items-center justify-center flex-shrink-0"
      style={{ backgroundColor: alter?.color || "#9333ea" }}
      title={alter?.name}
    >
      {resolvedUrl && !imgError
        ? <img src={resolvedUrl} alt={alter?.name} className="w-full h-full object-cover" onError={() => setImgError(resolvedUrl)} />
        : <span className="font-bold text-white" style={{ fontSize: 7 }}>{alter?.name?.charAt(0)?.toUpperCase() || "?"}</span>
      }
    </div>
  );
}

// Tall color block for timed activities. Emotions are NOT shown here — a
// check-in's emotions render once per hour-row at the slot level (see below),
// so they don't get duplicated onto every activity (and onto every hour a
// long activity spans).
function ActivityBlock({ activity, getColor, alters, alterIds, symptomsMap }) {
  const color = getColor(activity);
  const status = statusFor(activity);
  const v = visualForStatus(status);
  const needsReview = isPastTimeScheduled(activity);
  return (
    <div
      className="rounded-lg overflow-hidden relative w-full"
      style={{
        backgroundColor: v.dashed ? "transparent" : color,
        border: v.dashed ? `1px dashed ${color}` : undefined,
        opacity: v.fillOpacity,
        minHeight: 72,
        boxSizing: "border-box",
      }}
    >
      {needsReview && (
        <span className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full bg-amber-400 ring-1 ring-amber-700/40 z-10" title="Needs review" />
      )}
      {v.showXCenter && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
          <span className="text-white/80 text-3xl">×</span>
        </div>
      )}
      {alterIds.length > 0 && (
        <div className="absolute top-2 right-2 flex -space-x-1 z-10">
          {alterIds.slice(0, 4).map(id => <AlterAvatar key={id} alterId={id} alters={alters} />)}
        </div>
      )}
      <div className="p-3 pr-12">
        {status !== ACTIVITY_STATUSES.LOGGED && (
          <span className="inline-block mb-1 text-[10px] px-1.5 py-0.5 rounded-full bg-black/30 text-white font-semibold uppercase tracking-wide">
            {STATUS_LABELS[status]}
          </span>
        )}
        <p className="font-bold text-white text-base leading-snug break-words max-w-full">{activity.activity_name}</p>
        {activity.duration_minutes > 0 && (
          <p className="text-white/75 text-xs mt-0.5">{activity.duration_minutes}m</p>
        )}
        {activity.notes && (
          <p className="text-white/65 text-xs italic mt-1 leading-snug break-words">{activity.notes}</p>
        )}
        <SymptomPills symptomIds={activity.symptom_ids} symptomsMap={symptomsMap} />
      </div>
    </div>
  );
}

// Small colored pill for logged (no-duration) activities. Like ActivityBlock,
// emotions are rendered once at the slot level, not per pill.
function LoggedPill({ activity, getColor, alters = [], slotAlterIds = [], symptomsMap = {} }) {
  const color = getColor(activity);
  const status = statusFor(activity);
  const v = visualForStatus(status);
  const needsReview = isPastTimeScheduled(activity);
  const alterIds = [...new Set([...(activity.fronting_alter_ids || []), ...slotAlterIds])];
  return (
    <div className="flex flex-col gap-1">
      <div
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full self-start relative"
        style={{
          backgroundColor: v.dashed ? "transparent" : color,
          border: v.dashed ? `1px dashed ${color}` : undefined,
          opacity: v.fillOpacity,
          boxSizing: "border-box",
          textDecoration: v.strike ? "line-through" : undefined,
        }}
      >
        {v.corner && (
          <span className="text-white font-bold">{v.corner}</span>
        )}
        <span className="font-semibold text-white text-sm break-words">{activity.activity_name}</span>
        {status !== ACTIVITY_STATUSES.LOGGED && (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-black/30 text-white font-semibold uppercase tracking-wide">
            {STATUS_LABELS[status]}
          </span>
        )}
        {needsReview && (
          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-400 ring-1 ring-amber-700/40" title="Needs review" />
        )}
        {alterIds.length > 0 && (
          <div className="flex -space-x-1">
            {alterIds.slice(0, 3).map(id => <AlterAvatar key={id} alterId={id} alters={alters} />)}
          </div>
        )}
      </div>
      {activity.notes && (
        <p className="text-xs text-muted-foreground italic leading-snug pl-1 break-words">{activity.notes}</p>
      )}
      <SymptomPills symptomIds={activity.symptom_ids} symptomsMap={symptomsMap} />
    </div>
  );
}

export default function ActivityDayView({
  date,
  activities,
  alters = [],
  frontingHistory = [],
  importantDates = [],
  onClose,
  onActivityClick,
  onTimeRangeSelect,
  // Widget use: render inline inside a tile instead of as the full-screen
  // overlay — no portal, no fixed positioning, no swipe/ESC-to-close, and
  // the add affordances only appear when the caller can act on them.
  embedded = false,
}) {
  const dayImportantDates = datesForDay(importantDates, date);
  const { data: emotionCheckIns = [] } = useQuery({
    queryKey: ["emotionCheckIns"],
    queryFn: () => base44.entities.EmotionCheckIn.list(),
  });
  const { data: categories = [] } = useQuery({
    queryKey: ["activityCategories"],
    queryFn: () => base44.entities.ActivityCategory.list(),
  });
  const { data: symptoms = [] } = useQuery({
    queryKey: ["symptoms"],
    queryFn: () => base44.entities.Symptom.list(),
  });
  const { data: locationRecords = [] } = useQuery({
    queryKey: ["locations"],
    queryFn: () => localEntities.Location.list(),
  });
  const symptomsMap = useMemo(() => {
    const m = {};
    symptoms.forEach(s => { m[s.id] = s; });
    return m;
  }, [symptoms]);

  const catById = useMemo(() => {
    const m = {};
    categories.forEach(c => { m[c.id] = c; });
    return m;
  }, [categories]);

  const dateStr = format(date, "yyyy-MM-dd");
  const isToday = dateStr === format(new Date(), "yyyy-MM-dd");

  const dayActivities = useMemo(() => {
    const dayStart = parseDate(dateStr);
    return activities.filter(a => {
      const actStart = activityDate(a);
      if (format(actStart, "yyyy-MM-dd") === dateStr) return true;
      // Include activities that started the previous day and extend past midnight into this day
      if (a.duration_minutes > 0) {
        const actEnd = new Date(actStart.getTime() + a.duration_minutes * 60 * 1000);
        return actEnd > dayStart;
      }
      return false;
    });
  }, [activities, dateStr]);

  // Quick plans are date-only ("no set time") — they get a 23:59 timestamp
  // so they'd otherwise pile up in the 11pm hour slot at the very bottom of
  // the day. Pull them into their own top-of-day section and keep them out
  // of the hourly timeline below.
  const quickPlans = useMemo(() => dayActivities.filter(a => a.is_quick_plan), [dayActivities]);
  const timedActivities = useMemo(() => dayActivities.filter(a => !a.is_quick_plan), [dayActivities]);

  const totalDuration = useMemo(() => {
    const dayStart = parseDate(dateStr);
    const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
    return dayActivities.reduce((s, a) => {
      // Status-aware: only logged/done/partial contribute time; we use
      // countableMinutes as the budget and clip it to the day's bounds.
      // Scheduled/skipped/cancelled return 0 from countableMinutes.
      const budget = countableMinutes(a);
      if (!budget) return s;
      const actStart = activityDate(a);
      const actEnd = new Date(actStart.getTime() + budget * 60 * 1000);
      const clippedStart = actStart < dayStart ? dayStart : actStart;
      const clippedEnd = actEnd > dayEnd ? dayEnd : actEnd;
      return s + Math.max(0, Math.round((clippedEnd - clippedStart) / 60000));
    }, 0);
  }, [dayActivities, dateStr]);

  const getColor = useCallback((act) => getActivityColor(act, catById), [catById]);

  const getSlotData = useCallback((hour) => {
    const { timed, logged } = getActivitiesForSlot(date, hour, 0, INTERVAL, timedActivities);
    const hasActivities = timed.length > 0 || logged.length > 0;
    // Only attach alters/emotions/locations to rows that actually have activities
    const alterIds = hasActivities ? getAlterIdsForSlot(date, hour, 0, INTERVAL, frontingHistory) : [];
    const emotions = hasActivities ? getEmotionsForSlot(date, hour, 0, INTERVAL, timedActivities, emotionCheckIns) : [];
    const locations = hasActivities ? getLocationsForSlot(date, hour, 0, INTERVAL, locationRecords) : [];
    return { timed, logged, alterIds, emotions, locations };
  }, [date, timedActivities, frontingHistory, emotionCheckIns, locationRecords]);

  const segments = useMemo(() => buildSegments(getSlotData), [getSlotData]);
  const allEmpty = dayActivities.length === 0;

  // Now line
  const [nowMins, setNowMins] = useState(() => { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); });
  useEffect(() => {
    if (!isToday) return;
    const t = setInterval(() => { const n = new Date(); setNowMins(n.getHours() * 60 + n.getMinutes()); }, 60000);
    return () => clearInterval(t);
  }, [isToday]);
  const nowHour = isToday ? Math.floor(nowMins / 60) : null;

  // ESC to close
  useEffect(() => {
    if (embedded || !onClose) return undefined;
    const handler = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose, embedded]);

  // Swipe-down to close — only when scrolled to top
  const touchStartY = useRef(null);
  const scrollRef = useRef(null);
  const handleTouchStart = (e) => { touchStartY.current = e.touches[0].clientY; };
  const handleTouchEnd = (e) => {
    if (embedded || !onClose) { touchStartY.current = null; return; }
    const scrollTop = scrollRef.current?.scrollTop ?? 0;
    const delta = e.changedTouches[0].clientY - (touchStartY.current ?? 0);
    if (scrollTop === 0 && delta > 80) onClose();
    touchStartY.current = null;
  };

  // Auto-scroll to current time or first activity
  const nowLineRef = useRef(null);
  const firstActivityRef = useRef(null);
  useEffect(() => {
    const t = setTimeout(() => {
      const target = (isToday && nowLineRef.current) ? nowLineRef.current : firstActivityRef.current;
      if (!target) return;
      if (embedded) {
        // scrollIntoView would drag the whole home screen; move only our
        // own scroller.
        const box = scrollRef.current;
        if (!box) return;
        const top = target.offsetTop - box.clientHeight / 3;
        box.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
        return;
      }
      target.scrollIntoView({ block: isToday && nowLineRef.current ? "center" : "start", behavior: "smooth" });
    }, 120);
    return () => clearTimeout(t);
  }, [isToday, embedded]);

  const canAdd = typeof onTimeRangeSelect === "function";
  const handleAddNow = () => {
    if (!canAdd) return;
    const now = new Date();
    onTimeRangeSelect(date, now.getHours(), null, now.getMinutes(), null);
  };

  let firstActivitySet = false;

  const body = (
    <div
      className={embedded
        ? "h-full min-h-0 flex flex-col"
        : "fixed inset-0 bg-background z-50 flex flex-col"}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Header */}
      <div
        className={`sticky top-0 z-10 border-b border-border flex items-center gap-3 flex-shrink-0 ${
          embedded ? "px-1 py-1.5 bg-transparent border-border/40" : "bg-background px-4 py-3"}`}
        style={embedded ? undefined : { paddingTop: "calc(0.75rem + env(safe-area-inset-top, 0px))" }}
      >
        {onClose && (
          <Button variant="ghost" size="icon" onClick={onClose} className="flex-shrink-0">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        )}
        <div className="flex-1 min-w-0">
          <h2 className={`font-bold text-foreground leading-tight ${embedded ? "text-[0.875em]" : "text-base"}`}>
            {format(date, embedded ? "EEE, MMM d" : "EEEE, MMMM d")}
          </h2>
          <p className={embedded ? "text-[0.6875em] text-muted-foreground" : "text-xs text-muted-foreground"}>
            {allEmpty
              ? "No activities"
              : `${dayActivities.length} activit${dayActivities.length !== 1 ? "ies" : "y"}${totalDuration > 0 ? ` · ${Math.floor(totalDuration / 60)}h${totalDuration % 60 > 0 ? ` ${totalDuration % 60}m` : ""}` : ""}`
            }
          </p>
          {dayImportantDates.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1">
              {dayImportantDates.map((x, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1 text-[0.6875rem] px-1.5 py-0.5 rounded-full border"
                  style={{ borderColor: (x.color || "var(--color-primary, #6366f1)") + "66", color: x.color || "var(--color-text-primary, #e5e7eb)" }}
                  title={`${x.alterName} — ${x.fieldName}`}
                >
                  <span>📅</span>
                  <span className="font-medium">{x.alterName}</span>
                  <span className="opacity-70">· {x.fieldName}</span>
                </span>
              ))}
            </div>
          )}
        </div>
        {canAdd && (
          <Button size="sm" onClick={handleAddNow} className="gap-1.5 flex-shrink-0">
            <Plus className="w-4 h-4" /> Add
          </Button>
        )}
      </div>

      {/* Scrollable timeline */}
      <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto overscroll-contain">
        <div className={embedded ? "pb-2" : "pb-32"}>

          {/* Quick plans — date-only, "no set time". Their own section at the
              top of the day instead of being buried in the 11pm slot. */}
          {quickPlans.length > 0 && (
            <div className="sticky top-0 z-[5] border-b border-border/40 bg-background/95 backdrop-blur px-3 py-3">
              <p className="text-[0.6875rem] font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
                <span aria-hidden>✨</span> Quick plans · no set time
              </p>
              <div className="space-y-2 max-h-[35vh] overflow-y-auto overscroll-contain">
                {quickPlans.map(a => (
                  <div
                    key={a.id}
                    className="cursor-pointer"
                    onClick={() => onActivityClick?.([a])}
                  >
                    <LoggedPill activity={a} getColor={getColor} alters={alters} symptomsMap={symptomsMap} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Full-day empty state */}
          {allEmpty ? (
            <div className={`flex flex-col items-center justify-center gap-4 text-center ${embedded ? "py-8 px-3" : "py-24 px-8"}`}>
              <p className="text-muted-foreground text-sm">No activities logged for this day</p>
              {canAdd && (
                <Button onClick={handleAddNow} className="gap-2">
                  <Plus className="w-4 h-4" /> Log an activity
                </Button>
              )}
            </div>
          ) : (
            <>
            {/* The first hour's label is drawn half a line ABOVE its row (it
                marks the gridline, not the middle of the hour) — without
                this gap the quick-plans block above paints over it. */}
            <div aria-hidden="true" style={{ height: 10 }} />
            {segments.map((seg) => {
              /* ── Collapsed empty band ── */
              if (seg.type === "empty") {
                const nowInBand = nowHour !== null && nowHour >= seg.startHour && nowHour <= seg.endHour;
                // formatHour(24) used to come out as "12pm", so a day with
                // nothing on it announced itself as "12am – 12pm". A band
                // covering the whole day just says so.
                const wholeDay = seg.startHour === 0 && seg.endHour === 23;
                const label = wholeDay
                  ? "Nothing logged all day"
                  : seg.startHour === seg.endHour
                    ? `${formatHour(seg.startHour)} · no activities`
                    : `${formatHour(seg.startHour)} – ${seg.endHour === 23 ? "midnight" : formatHour(seg.endHour + 1)} · no activities`;

                return (
                  <div
                    key={`empty-${seg.startHour}`}
                    ref={nowInBand ? nowLineRef : null}
                    className="relative flex items-start border-t border-b border-border/20 bg-muted/10 cursor-pointer hover:bg-primary/5 transition-colors"
                    style={{ minHeight: nowInBand ? 48 : 32 }}
                    onClick={() => onTimeRangeSelect?.(date, seg.startHour, null, 0, null)}
                  >
                    {/* Hour label column — aligned to the TOP of the cell,
                        i.e. the demarcation line where this hour begins. */}
                    <div className="w-14 flex-shrink-0 text-right pr-3 select-none self-start"
                      style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", opacity: 0.45, transform: "translateY(-50%)" }}>
                      {formatHour(seg.startHour)}
                    </div>
                    {/* Band text */}
                    <div className="flex-1 py-2 min-w-0">
                      <span className="text-xs text-muted-foreground/40 select-none truncate block">{label}</span>
                    </div>
                    {/* Now line inside empty band */}
                    {/* "Now" inside a collapsed stretch. The band stands for
                        hours of nothing, so the line doesn't pretend to mark
                        an exact minute — it says now is somewhere in here. */}
                    {nowInBand && (
                      <div className="absolute left-14 right-2 bottom-1 flex items-center gap-1.5 pointer-events-none">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary opacity-80 flex-shrink-0" />
                        <span className="h-px flex-1 bg-primary/40" />
                        <span className="text-[0.5625rem] uppercase tracking-wide text-primary/70 flex-shrink-0">now</span>
                      </div>
                    )}
                  </div>
                );
              }

              /* ── Active hour row ── */
              const { timed, logged, alterIds, emotions, locations } = seg.data;
              const isCurrentHour = isToday && nowHour === seg.hour;
              const isFirstActivity = !firstActivitySet;
              if (isFirstActivity) firstActivitySet = true;

              return (
                <div
                  key={`active-${seg.hour}`}
                  ref={isCurrentHour ? nowLineRef : (isFirstActivity ? firstActivityRef : null)}
                  className={`relative flex border-t border-border/20 ${isCurrentHour ? "bg-primary/5" : ""}`}
                  style={{ minHeight: 80 }}
                >
                  {/* Now line */}
                  {isCurrentHour && (
                    <div
                      className="absolute left-0 right-0 pointer-events-none flex items-center z-10"
                      style={{ top: `${((nowMins % 60) / 60) * 100}%` }}
                    >
                      <div className="w-2.5 h-2.5 rounded-full bg-primary flex-shrink-0 ml-11" />
                      <div className="flex-1 h-0.5 bg-primary opacity-80" />
                    </div>
                  )}

                  {/* Hour label column — fixed width, never floats over
                      content. Aligned to the TOP of the cell (the border-t
                      demarcation line) since that's where this hour begins. */}
                  <div
                    className="w-14 flex-shrink-0 text-right pr-3 select-none self-start"
                    style={{
                      fontSize: 13,
                      fontWeight: isCurrentHour ? 700 : 500,
                      color: isCurrentHour ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))",
                      transform: "translateY(-50%)",
                    }}
                  >
                    {formatHour(seg.hour)}
                  </div>

                  {/* Content column */}
                  <div
                    className="flex-1 px-2 py-2 space-y-2 cursor-pointer"
                    onClick={() => {
                      const allActs = [...timed, ...logged];
                      if (allActs.length > 0) onActivityClick?.(allActs);
                      else onTimeRangeSelect?.(date, seg.hour, null, 0, null);
                    }}
                  >
                    {timed.map(a => (
                      <ActivityBlock
                        key={a.id}
                        activity={a}
                        getColor={getColor}
                        alters={alters}
                        alterIds={alterIds}
                        symptomsMap={symptomsMap}
                      />
                    ))}
                    {logged.map(a => (
                      <LoggedPill key={a.id} activity={a} getColor={getColor} alters={alters} slotAlterIds={alterIds} symptomsMap={symptomsMap} />
                    ))}
                    {/* Emotions logged in this hour (from check-ins) — shown ONCE
                        per hour-row, not duplicated onto each activity or onto
                        every hour a long activity spans. */}
                    <EmotionPills emotions={emotions} />
                    <LocationPills locations={locations} />
                  </div>
                </div>
              );
            })}
            </>
          )}
        </div>
      </div>

      {/* Floating add button — above bottom nav. A tile has its own header
          button and no room to float one. */}
      {!embedded && canAdd && (
        <button
          onClick={handleAddNow}
          className="fixed bottom-20 right-4 w-14 h-14 rounded-full bg-primary shadow-lg flex items-center justify-center text-white z-20 hover:bg-primary/90 transition-colors"
          aria-label="Add activity"
        >
          <Plus className="w-6 h-6" />
        </button>
      )}
    </div>
  );

  return embedded ? body : createPortal(body, document.body);
}