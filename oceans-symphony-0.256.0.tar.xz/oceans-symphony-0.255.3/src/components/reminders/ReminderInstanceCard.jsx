import { formatDistanceToNow, format } from "date-fns";
import { useTerms } from "@/lib/useTerms";
import { Clock, ChevronDown } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CATEGORY_ICONS } from "./reminderHelpers";
import { formatSnoozeLabel, DEFAULT_SNOOZE_OPTIONS } from "./snoozeHelpers";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const CATEGORY_DEFAULT_ACTIONS = {
  check_in: { label: "Check In", action_type: "open_check_in" },
  grounding: { label: "Open Grounding", action_type: "open_grounding" },
};

const STATUS_LABELS = {
  acted: "Done",
  dismissed: "Dismissed",
  auto_resolved: "Auto-resolved",
  snoozed: "Snoozed",
};

function AlterAvatar({ alter, categoryIcon }) {
  const resolvedUrl = useResolvedAvatarUrl(alter?.avatar_url);
  const [imgErrorFor, setImgError] = useState(null);
  const imgError = !!imgErrorFor && imgErrorFor === resolvedUrl;
  if (!alter) {
    return (
      <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
        <span className="text-base">{categoryIcon}</span>
      </div>
    );
  }
  const borderColor = alter.color || "#3B82F6";
  return (
    <div
      className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 border-2 overflow-hidden"
      style={{ borderColor }}
    >
      {resolvedUrl && !imgError ? (
        <img src={resolvedUrl} alt={alter.name} className="w-full h-full object-cover" onError={() => setImgError(resolvedUrl)} />
      ) : (
        <div
          className="w-full h-full flex items-center justify-center text-white text-sm font-bold"
          style={{ backgroundColor: borderColor }}
        >
          {alter.name?.[0]?.toUpperCase() || "?"}
        </div>
      )}
    </div>
  );
}

export default function ReminderInstanceCard({ instance, reminder, alter, onAction, onSnooze, onDone, onDismiss, onUnsnooze, readOnly = false }) {
  const terms = useTerms();
  if (!reminder) return null;

  const displayTime = instance.fired_at || instance.scheduled_for;
  const snoozeOptions = reminder.snooze_options?.length ? reminder.snooze_options : DEFAULT_SNOOZE_OPTIONS;
  const isSnoozed = instance.status === "snoozed";

  const Icon = CATEGORY_ICONS[reminder.category] || CATEGORY_ICONS.custom;

  const effectiveActions = (reminder.inline_actions || []).length > 0
    ? reminder.inline_actions
    : CATEGORY_DEFAULT_ACTIONS[reminder.category]
      ? [CATEGORY_DEFAULT_ACTIONS[reminder.category]]
      : [];

  return (
    <div className={`bg-card border border-border/50 rounded-xl p-4 space-y-3 transition-all ${readOnly ? "opacity-60" : ""} ${isSnoozed ? "border-amber-200/60 dark:border-amber-800/40" : ""}`}>
      <div className="flex items-start gap-3">
        <AlterAvatar alter={alter} categoryIcon={Icon} />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <p className="font-semibold text-sm text-foreground leading-tight">{reminder.title}</p>
            {(readOnly || isSnoozed) && (
              <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 ${isSnoozed ? "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400" : "text-muted-foreground bg-muted/50"}`}>
                {STATUS_LABELS[instance.status] || instance.status}
              </span>
            )}
          </div>
          {alter && (
            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
              <span
                className="text-xs px-2 py-0.5 rounded-full font-medium"
                style={{
                  backgroundColor: (alter.color || "#3B82F6") + "22",
                  color: alter.color || "#3B82F6",
                  border: `1px solid ${(alter.color || "#3B82F6")}44`,
                }}
              >
                For {alter.name}
              </span>
              {reminder.alter_scope === "when_fronting" && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-muted/40 text-muted-foreground border border-border/40">
                  · when {terms.fronting}
                </span>
              )}
            </div>
          )}
          {reminder.body && (
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{reminder.body}</p>
          )}
          {isSnoozed && instance.snoozed_until && (
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Snoozed until {format(new Date(instance.snoozed_until), "MMM d, h:mm a")}
            </p>
          )}
          {!isSnoozed && displayTime && (
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {formatDistanceToNow(new Date(displayTime), { addSuffix: true })}
            </p>
          )}
        </div>
      </div>

      {isSnoozed && !readOnly && (
        <div className="flex items-center gap-2 pt-1 border-t border-border/30">
          <Button size="sm" variant="outline" className="text-xs h-7 px-3" onClick={onUnsnooze}>
            Unsnooze now
          </Button>
          <Button size="sm" variant="ghost" className="text-xs h-7 px-3 text-muted-foreground" onClick={onDismiss}>
            Dismiss
          </Button>
        </div>
      )}

      {!readOnly && !isSnoozed && (
        <>
          {effectiveActions.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {effectiveActions.map((action, idx) => (
                <Button key={idx} size="sm" variant="outline" className="text-xs h-7 px-3" onClick={() => onAction(action)}>
                  {action.label}
                </Button>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2 pt-1 border-t border-border/30">
            <Button size="sm" className="text-xs h-7 px-3" onClick={onDone}>Done</Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline" className="text-xs h-7 px-3 gap-1">
                  Snooze <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {snoozeOptions.map((opt, idx) => (
                  <DropdownMenuItem key={idx} onClick={() => onSnooze(opt)}>
                    {formatSnoozeLabel(opt)}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button size="sm" variant="ghost" className="text-xs h-7 px-3 text-muted-foreground hover:text-foreground" onClick={onDismiss}>
              Dismiss
            </Button>
          </div>
        </>
      )}
    </div>
  );
}