// The fronting-level rail — the owner's gesture: press and hold an active
// alter, a vertical spectrum of the user's levels appears, drag to a level,
// release to set it. One continuous gesture, no menu hopping.
//
// Two pieces:
//   • useHoldDragLevel — per-row hook. Stationary 350ms hold arms the rail
//     (movement first = scroll, cancelled); after arming, pointer moves pick
//     the nearest level and release commits. Window-level listeners so the
//     gesture survives re-renders of the row underneath.
//   • FrontLevelRail — the fixed overlay drawn while the gesture is live:
//     a vertical line with a dot + label per level, closest-to-front on top,
//     the picked level highlighted.
//
// Commit writes follow the canonical refetch-before-write rule for
// FrontingSession mutations (see useSwipeActions): fetch fresh active rows,
// update the target's front_level, invalidate ["activeFront"].

import React, { useRef, useState, useCallback, useEffect } from "react";
import { createPortal } from "react-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useTerms } from "@/lib/useTerms";
import { frontLevelLabel, useFrontLevels } from "@/lib/frontLevels";
import { applyTerms } from "@/lib/dailyTaskSystem";
import { recomputePrimaryFromLevels } from "@/lib/setFront";
import { toggleFrontFor, removeFrontFor } from "@/hooks/useSwipeActions";

// Lazy: AlterActionMenu's module imports FrontStatusPill, which imports
// this file — a static import here would close that cycle at eval time.
const AlterActionMenuLazy = React.lazy(() => import("@/components/alters/AlterActionMenu"));

export const LEVEL_ROW_H = 44;
const HOLD_MS = 350;
// Movement that cancels a pending hold. Mouse: 8px is a deliberate drag.
// Touch: a resting fingertip drifts several px on its own — 8px cancelled
// real holds on phones (release then landed as a plain tap: "it just adds
// instead"). Touch gets a wide slop and lets the browser's own scroll
// detection (pointercancel) be the real judge of "this was a scroll".
const SLOP_PX = 8;
// Sideways distance (px) on an open rail that leaves it for the options menu.
const MENU_SWIPE_PX = 80;
const TOUCH_SLOP_PX = 24;

// Shared commit helper — usable outside the gesture too (modal, panel).
// Pass cfg so the derived primary follows the spectrum (star retired).
export async function commitFrontLevel({ alterId, levelId, queryClient, cfg = null, solo = false }) {
  try {
    const fresh = await base44.entities.FrontingSession.filter({ is_active: true });
    const session = fresh.find((s) => (s.alter_id || s.primary_alter_id) === alterId);
    if (!session) return false;
    if (session.front_level !== levelId) {
      await base44.entities.FrontingSession.update(session.id, { front_level: levelId });
    }
    // "Sole" (the rail's sideways slide): clear the picked level — or the
    // whole front — of everyone else. Scope comes from the level config.
    if (solo && cfg) {
      const now = new Date().toISOString();
      const scope = cfg.solo_swipe?.scope || "level";
      const idx = cfg.levels.findIndex((l) => l.id === levelId);
      const lower = cfg.levels[idx + 1] || null;
      for (const s of fresh) {
        const aid = s.alter_id || s.primary_alter_id;
        if (aid === alterId) continue;
        if (scope === "all") {
          await base44.entities.FrontingSession.update(s.id, { is_active: false, end_time: now });
          continue;
        }
        const sLevelId = s.front_level || (s.is_primary ? cfg.levels[0]?.id : cfg.levels[1]?.id || cfg.levels[0]?.id);
        if (sLevelId === levelId) {
          if (lower) await base44.entities.FrontingSession.update(s.id, { front_level: lower.id });
          else await base44.entities.FrontingSession.update(s.id, { is_active: false, end_time: now });
        }
      }
    }
    if (cfg?.enabled) await recomputePrimaryFromLevels({ cfg, queryClient: null });
    queryClient?.invalidateQueries({ queryKey: ["activeFront"] });
    try { window.dispatchEvent(new Event("symphony-front-changed")); } catch { /* SSR */ }
    queryClient?.invalidateQueries({ queryKey: ["frontHistory"] });
    return true;
  } catch {
    toast.error("Couldn't save the level");
    return false;
  }
}

export function useHoldDragLevel({ cfg, onCommit, onRemove, onOptions = null }) {
  const [rail, setRail] = useState(null); // { alterId, x, y, pickedIndex }
  const timer = useRef(null);
  const origin = useRef(null);
  const live = useRef(null);

  const teardown = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    origin.current = null;
    if (live.current) {
      window.removeEventListener("pointermove", live.current.move);
      window.removeEventListener("pointerup", live.current.up);
      window.removeEventListener("pointercancel", live.current.cancel);
      if (live.current.blockScroll) window.removeEventListener("touchmove", live.current.blockScroll);
      live.current = null;
    }
    document.body.style.userSelect = "";
    document.body.style.webkitUserSelect = "";
    setRail(null);
  }, []);

  // The control that owns a live rail can unmount mid-press (the hold rail
  // closing as it hands off, a list re-rendering). Its window listeners
  // must go with it — left behind, the NEXT lift anywhere committed a level
  // (or "Remove") for that alter, unseen.
  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
    if (live.current) {
      window.removeEventListener("pointermove", live.current.move);
      window.removeEventListener("pointerup", live.current.up);
      window.removeEventListener("pointercancel", live.current.cancel);
      if (live.current.blockScroll) window.removeEventListener("touchmove", live.current.blockScroll);
      live.current = null;
      document.body.style.userSelect = "";
      document.body.style.webkitUserSelect = "";
    }
  }, []);

  // Open the rail for `alterId` with the finger at (x, y) and follow the
  // pointer from there. The hold timer calls this; so can another gesture
  // that already has the finger down (AlterHoldRail's slide onto its front
  // button hands off to the level rail — owner, 2026-10-01).
  const beginRail = (alterId, currentLevelId, x, y) => {
    try { navigator.vibrate?.(10); } catch { /* no haptics */ }
    // While the rail is live, dragging must not paint a text selection
    // across the page (the reported bug) — kill selection globally and
    // clear any that already started during the hold.
    document.body.style.userSelect = "none";
    document.body.style.webkitUserSelect = "none";
    try { window.getSelection()?.removeAllRanges(); } catch { /* fine */ }
    const startIndex = Math.max(0, cfg.levels.findIndex((l) => l.id === currentLevelId));
    const maxIndex = cfg.levels.length - 1 + (onRemove ? 1 : 0);
    // Anchor the current level's row under the press point, then clamp
    // into the viewport ONCE, here — and from then on read the finger
    // against where the rail actually IS. (Clamping only at render
    // left the pick math assuming the unclamped position: near a
    // screen edge the finger hovered a gap and nothing selected.)
    const railH = (maxIndex + 1) * LEVEL_ROW_H;
    const anchoredTop = y - (startIndex * LEVEL_ROW_H + LEVEL_ROW_H / 2);
    const top = Math.min(Math.max(8, anchoredTop), window.innerHeight - railH - 8);
    const pickAt = (clientY) =>
      Math.min(maxIndex, Math.max(0, Math.round((clientY - top - LEVEL_ROW_H / 2) / LEVEL_ROW_H)));
    const state = {
      alterId, x, y, top,
      pickedIndex: pickAt(y), startIndex, solo: false,
    };
    setRail(state);
    // Sideways slide (direction configurable) arms "sole" — commit
    // makes this alter the only one at the level (or outright).
    const soloDir = cfg.solo_swipe?.direction === "right" ? 1 : -1;
    const soloOn = cfg.solo_swipe?.enabled !== false;
    // The OTHER sideways direction (right, unless "sole" was set to the
    // right) leaves the rail for the alter's options menu — wherever the
    // rail opens, the menu is one swipe away (owner, 2026-10-01).
    const menuDir = -soloDir;
    const pick = (ev) => {
      const dx = ev.clientX - state.x;
      if (onOptions && dx * menuDir > MENU_SWIPE_PX) {
        teardown();
        try { navigator.vibrate?.(10); } catch { /* no haptics */ }
        onOptions(alterId);
        return;
      }
      const idx = pickAt(ev.clientY);
      const solo = soloOn && dx * soloDir > 64;
      const towardMenu = !!onOptions && dx * menuDir > MENU_SWIPE_PX / 3;
      setRail((r) => (r ? { ...r, pickedIndex: idx, solo, towardMenu } : r));
      state.pickedIndex = idx;
      state.solo = solo;
    };
    const move = (ev) => pick(ev);
    const up = () => {
      const idx = state.pickedIndex;
      const solo = state.solo;
      teardown();
      if (onRemove && idx === cfg.levels.length) onRemove(alterId);
      else if (cfg.levels[idx]) onCommit(alterId, cfg.levels[idx].id, { solo });
    };
    const cancel = () => teardown();
    // Native scroll fires pointercancel the moment the finger moves,
    // killing the rail — touch-action is evaluated at touchstart, so
    // setting it now is too late. preventDefault on touchmove (non-
    // passive) is the one thing that still stops scrolling mid-touch.
    const blockScroll = (ev) => ev.preventDefault();
    window.addEventListener("touchmove", blockScroll, { passive: false });
    live.current = { move, up, cancel, blockScroll };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", cancel);
  };

  const getHoldProps = (alterId, currentLevelId) => {
    if (!cfg?.enabled) return {};
    return {
      // This element answers a hold itself — the widget board checks for
      // this attribute before opening a widget's options on hold.
      "data-own-hold": "",
      onPointerDown: (e) => {
        if (e.button !== undefined && e.button !== 0) return;
        origin.current = { x: e.clientX, y: e.clientY, touch: e.pointerType !== "mouse", alterId, watch: null };
        if (timer.current) clearTimeout(timer.current);
        timer.current = setTimeout(() => {
          timer.current = null;
          beginRail(alterId, currentLevelId, origin.current?.x ?? e.clientX, origin.current?.y ?? e.clientY);
        }, HOLD_MS);
      },
      onPointerMove: (e) => {
        // Before arming: movement decides the gesture. A rightward,
        // sideways-dominant start is the "more options" drag (unified
        // grammar — drag right on any front control opens the alter's
        // menu); anything else is a scroll and cancels the hold.
        const o = origin.current;
        if (!o) return;
        const dx = e.clientX - o.x;
        const dy = e.clientY - o.y;
        if (o.watch == null && timer.current) {
          const slop = o.touch ? TOUCH_SLOP_PX : SLOP_PX;
          if (dx * dx + dy * dy > slop * slop) {
            clearTimeout(timer.current);
            timer.current = null;
            o.watch = onOptions && dx > 0 && dx >= Math.abs(dy) ? "right" : "dead";
          }
        }
        // Same-event fall-through: a fast flick can cross the slop AND the
        // fire distance in one move.
        if (o.watch === "right" && dx > 40 && dx > Math.abs(dy) * 1.2 && onOptions) {
          o.watch = "fired";
          try { navigator.vibrate?.(10); } catch { /* no haptics */ }
          onOptions(o.alterId);
        }
      },
      onPointerUp: () => {
        // Released before arming — normal tap, just drop the pending hold.
        if (timer.current) { clearTimeout(timer.current); timer.current = null; }
        origin.current = null;
      },
      // The browser took the pointer for a scroll (or the OS interrupted):
      // never arm a rail nobody can finish.
      onPointerCancel: () => {
        if (timer.current) { clearTimeout(timer.current); timer.current = null; }
        origin.current = null;
      },
      // Always, not just while armed: text selection and the long-press
      // context menu/callout start DURING the hold, before the rail exists
      // — once the OS begins selecting it cancels the pointer stream and
      // the rail vanishes. These are gesture elements; selecting their
      // text is never the intent.
      onContextMenu: (e) => e.preventDefault(),
      style: {
        touchAction: rail ? "none" : undefined,
        userSelect: "none",
        WebkitUserSelect: "none",
        WebkitTouchCallout: "none",
      },
    };
  };

  const startRailAt = (alterId, currentLevelId, x, y) => {
    if (!cfg?.enabled || live.current) return false;
    beginRail(alterId, currentLevelId, x, y);
    return true;
  };

  return { rail, getHoldProps, startRailAt };
}

// ── Static tap-to-pick variant ─────────────────────────────────────
// Swipe gestures can't flow into a drag, so surfaces whose "set primary"
// swipe was replaced by levels (owner decision: the star is retired when
// levels are on) open THIS instead: the same spectrum, centered, tap a
// level (or the remove stop) to commit, tap outside to cancel.
function LevelPickerOverlay({ alter, currentLevel, cfg, onClose, queryClient, terms }) {
  const rows = [
    ...cfg.levels,
    { id: "__remove", label: "Remove from {{front}}", _remove: true },
  ];
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center"
      onClick={onClose} role="dialog" aria-label={`Set ${terms.front} level for ${alter.name}`}>
      <div className="absolute inset-0 bg-background/60" />
      <div className="relative bg-background border border-border rounded-2xl shadow-2xl px-3 py-2 min-w-[220px] overflow-y-auto overscroll-contain"
        style={{ maxHeight: "min(80vh, calc(100dvh - 48px))" }}
        onClick={(e) => e.stopPropagation()}>
        <p className="text-xs font-medium text-muted-foreground px-1 py-1.5 truncate">{alter.name}</p>
        {rows.map((level) => {
          const current = !level._remove && (currentLevel ? level.id === currentLevel : level.id === cfg.levels[0]?.id);
          return (
            <button
              key={level.id}
              type="button"
              onClick={async () => {
                onClose();
                if (level._remove) removeFrontFor(alter, base44, queryClient, toast, terms);
                else await commitFrontLevel({ alterId: alter.id, levelId: level.id, queryClient, cfg });
              }}
              className={`w-full flex items-center gap-2.5 px-2 py-2 rounded-lg text-left text-sm transition-colors ${
                level._remove
                  ? "text-destructive hover:bg-destructive/10"
                  : current
                    ? "bg-primary/15 text-primary font-medium"
                    : "text-foreground hover:bg-muted/50"
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                style={{ background: level._remove ? "hsl(var(--destructive))" : current ? "var(--color-primary)" : "color-mix(in srgb, var(--color-primary) 35%, transparent)" }} />
              {frontLevelLabel(level, terms)}
            </button>
          );
        })}
      </div>
    </div>,
    document.body
  );
}

// The drop-in replacement for a "toggle primary" gesture callback. With
// levels OFF, trigger() returns false and the caller falls back to the
// classic togglePrimaryFor. With levels ON it opens the tap-to-pick
// spectrum for that alter (or explains they're not fronting).
export function usePrimaryGesture() {
  const cfg = useFrontLevels();
  const queryClient = useQueryClient();
  const terms = useTerms();
  const [pickFor, setPickFor] = useState(null);

  const trigger = async (alter) => {
    if (!cfg.enabled) return false;
    try {
      const fresh = await base44.entities.FrontingSession.filter({ is_active: true });
      const session = fresh.find((s) => (s.alter_id || s.primary_alter_id) === alter.id);
      if (!session) {
        toast.info(`${alter.name} isn't ${terms.fronting} — add them to the ${terms.front} first`);
        return true;
      }
      setPickFor({ alter, currentLevel: session.front_level });
    } catch { /* leave closed */ }
    return true;
  };

  const node = pickFor ? (
    <LevelPickerOverlay
      alter={pickFor.alter}
      currentLevel={pickFor.currentLevel}
      cfg={cfg}
      terms={terms}
      queryClient={queryClient}
      onClose={() => setPickFor(null)}
    />
  ) : null;

  return { trigger, node, levelsOn: cfg.enabled };
}

// Plain press-and-hold → callback, with the same cancel-on-move and
// tap-suppression rules as the level rail. Used where hold opens the
// alter ACTION MENU rather than the spectrum (the alters page's chips and
// grid tiles — there, fronting lives on the bolt button instead).
export function useHoldMenu(onHold, { holdMs = 350 } = {}) {
  const timer = useRef(null);
  const origin = useRef(null);
  const suppress = useRef(0);
  const clear = () => { if (timer.current) { clearTimeout(timer.current); timer.current = null; } };
  return {
    suppressed: () => Date.now() < suppress.current,
    bind: {
      "data-own-hold": "",
      onContextMenu: (e) => e.preventDefault(),
      style: { userSelect: "none", WebkitUserSelect: "none", WebkitTouchCallout: "none" },
      onPointerDown: (e) => {
        if (e.button !== undefined && e.button !== 0) return;
        origin.current = { x: e.clientX, y: e.clientY, watch: null };
        clear();
        timer.current = setTimeout(() => {
          timer.current = null;
          suppress.current = Date.now() + 400;
          try { navigator.vibrate?.(10); } catch { /* no haptics */ }
          onHold();
        }, holdMs);
      },
      onPointerMove: (e) => {
        const o = origin.current;
        if (!o) return;
        const dx = e.clientX - o.x;
        const dy = e.clientY - o.y;
        // Dragging RIGHT is the second way into the menu (unified gesture
        // grammar): a rightward, sideways-dominant start keeps watching
        // and fires at 40px; any other movement is a scroll. Fire-check
        // runs on the same event as classification so a fast flick works.
        if (o.watch == null && timer.current && dx * dx + dy * dy > 64) {
          clear();
          o.watch = dx > 0 && dx >= Math.abs(dy) ? "right" : "dead";
        }
        if (o.watch === "right" && dx > 40 && dx > Math.abs(dy) * 1.2) {
          o.watch = "fired";
          suppress.current = Date.now() + 400;
          try { navigator.vibrate?.(10); } catch { /* no haptics */ }
          onHold();
        }
      },
      onPointerUp: () => { clear(); origin.current = null; },
      onPointerCancel: () => { clear(); origin.current = null; },
    },
  };
}

// Hosts the drag-right options menu for surfaces that use useHoldDragLevel
// DIRECTLY (their own commit/suppress bookkeeping) rather than through
// useFrontGesture: pass the result's openOptions to onOptions, render its
// node next to the rail. resolveAlter maps the gesture's alterId back to
// the alter object.
export function useFrontOptionsMenu(resolveAlter) {
  const [menuFor, setMenuFor] = useState(null);
  const { data: sessions = [] } = useQuery({
    queryKey: ["activeFront"],
    queryFn: () => base44.entities.FrontingSession.filter({ is_active: true }),
  });
  const resolveRef = useRef(resolveAlter);
  resolveRef.current = resolveAlter;
  const openOptions = useCallback((alterId) => {
    const a = resolveRef.current?.(alterId);
    if (a) setMenuFor(a);
  }, []);
  const node = menuFor ? (
    <React.Suspense fallback={null}>
      <AlterActionMenuLazy
        alter={menuFor}
        activeSessions={sessions}
        session={sessions.find((s) => (s.alter_id || s.primary_alter_id) === menuFor.id) || null}
        onClose={() => setMenuFor(null)}
      />
    </React.Suspense>
  ) : null;
  return { openOptions, node };
}

// ── The app-standard front gesture kit ─────────────────────────────
// One hook = the whole per-alter fronting interaction, identical on every
// surface (owner rule, v0.122.0 — the here-now widget defines the grammar):
//   • getHoldProps(alter, currentLevel) — press-and-hold opens the drag
//     rail (Remove stop included). Holding a NON-fronter adds them at the
//     level released on.
//   • quickSet(alter, session) — for explicit "set front" buttons: not
//     fronting → straight onto the TOP level; fronting → the tap-to-pick
//     spectrum for adjusting/removing.
//   • node — render once per surface (rail + picker portals).
//   • suppressed() — guard click handlers against the tap that follows a
//     completed hold.
export function useFrontGesture() {
  const cfg = useFrontLevels();
  const queryClient = useQueryClient();
  const terms = useTerms();
  const altersRef = useRef({});
  const suppress = useRef(0);
  const [pickFor, setPickFor] = useState(null);
  // Drag RIGHT on any front control = the alter's options menu (unified
  // gesture grammar — profile, groups, subsystems all live in there).
  const [menuFor, setMenuFor] = useState(null);
  const { data: menuSessions = [] } = useQuery({
    queryKey: ["activeFront"],
    queryFn: () => base44.entities.FrontingSession.filter({ is_active: true }),
  });

  const addOrLevel = async (alterId, levelId, extras = {}) => {
    const fresh = await base44.entities.FrontingSession.filter({ is_active: true });
    const existing = fresh.find((s) => (s.alter_id || s.primary_alter_id) === alterId);
    if (!existing) {
      const alter = altersRef.current[alterId];
      if (alter) await toggleFrontFor(alter, fresh, base44, queryClient, toast, terms);
    }
    await commitFrontLevel({ alterId, levelId, queryClient, cfg, solo: !!extras.solo });
  };

  const { rail, getHoldProps: rawHoldProps, startRailAt: rawStartRailAt } = useHoldDragLevel({
    cfg,
    onCommit: (alterId, levelId, extras = {}) => {
      suppress.current = Date.now() + 400;
      addOrLevel(alterId, levelId, extras);
    },
    onRemove: (alterId) => {
      suppress.current = Date.now() + 400;
      const alter = altersRef.current[alterId];
      if (alter) removeFrontFor(alter, base44, queryClient, toast, terms);
    },
    onOptions: (alterId) => {
      suppress.current = Date.now() + 400;
      const alter = altersRef.current[alterId];
      if (alter) setMenuFor(alter);
    },
  });

  const getHoldProps = (alter, currentLevel) => {
    if (!alter) return {};
    altersRef.current[alter.id] = alter;
    return rawHoldProps(alter.id, currentLevel);
  };

  const quickSet = async (alter, session) => {
    altersRef.current[alter.id] = alter;
    if (!session) {
      suppress.current = Date.now() + 400;
      await addOrLevel(alter.id, cfg.levels[0]?.id);
    } else {
      setPickFor({ alter, currentLevel: session.front_level });
    }
  };

  const railAlter = rail ? altersRef.current[rail.alterId] : null;
  const node = (
    <>
      <FrontLevelRail rail={rail} cfg={cfg} withRemove alterName={railAlter?.name || ""} />
      {pickFor && (
        <LevelPickerOverlay
          alter={pickFor.alter}
          currentLevel={pickFor.currentLevel}
          cfg={cfg}
          terms={terms}
          queryClient={queryClient}
          onClose={() => setPickFor(null)}
        />
      )}
      {menuFor && (
        <React.Suspense fallback={null}>
          <AlterActionMenuLazy
            alter={menuFor}
            activeSessions={menuSessions}
            session={menuSessions.find((s) => (s.alter_id || s.primary_alter_id) === menuFor.id) || null}
            onClose={() => setMenuFor(null)}
          />
        </React.Suspense>
      )}
    </>
  );

  // Open the level rail NOW, under a finger that's already down — for a
  // gesture handing off to it (AlterHoldRail's slide onto the front button).
  const startRailAt = (alter, currentLevel, x, y) => {
    if (!alter) return false;
    altersRef.current[alter.id] = alter;
    return rawStartRailAt(alter.id, currentLevel, x, y);
  };

  // A tap that should open the alter's options menu (pinned bar / widget).
  const openMenu = (alter) => {
    if (!alter) return;
    altersRef.current[alter.id] = alter;
    setMenuFor(alter);
  };

  return {
    getHoldProps, quickSet, openMenu, startRailAt, node,
    railActive: !!rail,
    suppressed: () => !!rail || Date.now() < suppress.current,
    cfg,
  };
}

export function FrontLevelRail({ rail, cfg, alterName, withRemove = false }) {
  const terms = useTerms();
  if (!rail || !cfg?.enabled) return null;
  const { levels } = cfg;
  const rowCount = levels.length + (withRemove ? 1 : 0);
  const railH = rowCount * LEVEL_ROW_H;
  // The hook already anchored + clamped the top and picks against it;
  // older callers without rail.top fall back to the previous computation.
  const top = rail.top ?? Math.min(
    Math.max(8, rail.y - ((rail.startIndex ?? 0) * LEVEL_ROW_H + LEVEL_ROW_H / 2)),
    window.innerHeight - railH - 8,
  );
  // The dot column stays under the FINGER. When there's no room for the
  // labels on the right (a press near the right edge — pinned bar, grids),
  // they flip to the left instead of shoving the whole rail sideways.
  const flip = rail.x + 200 > window.innerWidth;
  const left = Math.min(Math.max(12, rail.x - 10), window.innerWidth - 32);
  return createPortal(
    <div className="fixed inset-0 z-[80] select-none" style={{ touchAction: "none", WebkitUserSelect: "none", WebkitTouchCallout: "none" }} aria-hidden="true">
      <div className="absolute inset-0 bg-background/50" />
      {alterName && (
        <div className="absolute px-2 py-0.5 rounded-md bg-background border border-border text-xs font-medium whitespace-nowrap"
          style={{ ...(flip ? { right: window.innerWidth - left - 20 } : { left }), top: Math.max(2, top - 26) }}>
          {alterName}
          {rail.towardMenu && !rail.solo && (
            <span className="ml-1.5 font-semibold" style={{ color: "var(--color-primary)" }}>options ›</span>
          )}
          {rail.solo && (
            <span className="ml-1.5 font-semibold" style={{ color: "var(--color-primary)" }}>
              {(cfg.solo_swipe?.scope || "level") === "all"
                ? applyTerms("only one {{fronting}}", terms)
                : "sole at this level"}
            </span>
          )}
        </div>
      )}
      <div className="absolute" style={{ left, top }}>
        {/* the spectrum line */}
        <div className="absolute left-[9px] top-[10px] bottom-[10px] w-0.5 rounded bg-border" />
        {[...levels, ...(withRemove ? [{ id: "__remove", label: `Remove from {{front}}`, _remove: true }] : [])].map((level, i) => {
          const picked = i === rail.pickedIndex;
          const accent = level._remove ? "hsl(var(--destructive))" : "var(--color-primary)";
          return (
            <div key={level.id} className="relative flex items-center" style={{ height: LEVEL_ROW_H, width: 20 }}>
              <span
                className="rounded-full flex-shrink-0 transition-all"
                style={{
                  width: picked ? 20 : 10,
                  height: picked ? 20 : 10,
                  marginLeft: picked ? 0 : 5,
                  background: picked ? accent : `color-mix(in srgb, ${accent} 35%, transparent)`,
                }}
              />
              <span
                className={`absolute px-2 py-0.5 rounded-md text-sm whitespace-nowrap border transition-colors ${
                  picked
                    ? (level._remove
                        ? "bg-destructive text-destructive-foreground border-transparent font-medium"
                        : "bg-primary text-primary-foreground border-transparent font-medium")
                    : `bg-background/90 border-border/60 ${level._remove ? "text-destructive/80" : "text-muted-foreground"}`
                }`}
                style={flip ? { right: 30 } : { left: 30 }}
              >
                {frontLevelLabel(level, terms)}
              </span>
            </div>
          );
        })}
      </div>
    </div>,
    document.body
  );
}
