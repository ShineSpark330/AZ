// The Guide's Setup phase hub: a checklist of the remaining setup tasks
// the user can tick off in any order (v0.84.9 per owner). Progress
// persists to localStorage under CHECKLIST_KEY so re-entering the guide
// (via the dashboard "Continue setup" chip, or Settings → About →
// Re-run setup) picks up where the user left off — checked items stay
// checked. Each item expands inline to show the interactive UI or a
// direct link.

import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Users, Heart, Activity as ActivityIcon, Check, ChevronDown, ChevronRight, Download, Plus, ExternalLink, ShieldAlert, Settings2, CheckSquare, Loader2, Bell, Layers, Sparkles } from "lucide-react";
import { readPlanRemindersEnabled, writePlanRemindersEnabled } from "@/lib/planReminderScheduler";
import { isNative } from "@/lib/platform";
import { toast } from "sonner";
import { DEFAULT_TASK_TEMPLATES, applyTerms as applyTaskTerms } from "@/lib/dailyTaskSystem";
import TaskTemplateManager from "@/components/tasks/TaskTemplateManager";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { useTerms } from "@/lib/useTerms";
import CustomEmotionsManager from "@/components/settings/CustomEmotionsManager";
import AutoBackupSettings from "@/components/settings/AutoBackupSettings";
import ImportAltersModal from "@/components/alters/ImportAltersModal";
import FrontLevelsSettings from "@/components/settings/FrontLevelsSettings";
import { ClassicBarsToggles } from "@/components/settings/DashboardLayoutSettings";
import { BundleList } from "@/components/symptoms/BundlePicker";
import ActivityCustomizationMenu from "@/components/activities/ActivityCustomizationMenu";
import ActivityPackPicker from "@/components/activities/ActivityPackPicker";
import InlineEncryptionSetup from "@/components/onboarding/InlineEncryptionSetup";
import { PersistentNotificationsSection } from "@/components/settings/NotificationSettings";
import NotificationStatusCard from "@/components/shared/NotificationStatusCard";
import { psGetItem, psSetItem } from "@/lib/perSystemStorage";

// Per-system-scoped since v0.85.6 (tester report: a new system was
// inheriting the previous system's half-finished checklist).
// psGetItem falls back to the legacy unscoped key when the registry has
// ≤1 system, so pre-existing single-system users' progress carries over.
export const CHECKLIST_KEY = "symphony_setup_checklist_v1";
export const CHECKLIST_ITEMS = ["alters", "levels", "tracking", "activity", "tasks", "reminders", "newui", "backup"];

export function loadChecklist() {
  try {
    const raw = psGetItem(CHECKLIST_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return typeof parsed === "object" && parsed ? parsed : {};
  } catch { return {}; }
}
export function saveChecklist(state) {
  psSetItem(CHECKLIST_KEY, JSON.stringify(state || {}));
}
export function checklistComplete(state = loadChecklist()) {
  return CHECKLIST_ITEMS.every((k) => !!state[k]);
}
export function checklistProgress(state = loadChecklist()) {
  const done = CHECKLIST_ITEMS.filter((k) => !!state[k]).length;
  return { done, total: CHECKLIST_ITEMS.length };
}

function ChecklistItem({ id, icon: Icon, title, description, done, expanded, onToggleExpand, onToggleDone, highlight, children }) {
  return (
    <div
      className={`border rounded-xl overflow-hidden ${
        highlight ? "border-amber-500/60 bg-amber-500/5 ring-1 ring-amber-500/20" : "border-border/60"
      }`}
    >
      <button
        type="button"
        onClick={onToggleExpand}
        aria-expanded={expanded}
        className="w-full flex items-center gap-2 px-3 py-2.5 text-left hover:bg-muted/40 transition-colors"
      >
        {highlight && (
          <span
            className="text-[0.5625rem] font-semibold uppercase tracking-wide text-amber-600 dark:text-amber-400 border border-amber-500/50 rounded px-1 py-px flex-shrink-0"
            title="Please don't skip this one"
          >
            Important
          </span>
        )}
        <span
          onClick={(e) => { e.stopPropagation(); onToggleDone(); }}
          role="checkbox"
          aria-checked={done}
          aria-label={done ? `Mark ${title} as not done` : `Mark ${title} as done`}
          className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-colors ${
            done
              ? "bg-primary border-primary text-primary-foreground"
              : "border-border/70 hover:border-primary"
          }`}
        >
          {done && <Check className="w-3 h-3" />}
        </span>
        <Icon className="w-4 h-4 text-primary flex-shrink-0" />
        <span className="flex-1 min-w-0">
          <span className={`text-sm font-medium block ${done ? "line-through text-muted-foreground" : ""}`}>{title}</span>
          <span className="text-xs text-muted-foreground block">{description}</span>
        </span>
        {expanded ? <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" /> : <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
      </button>
      {expanded && (
        <div className="border-t border-border/50 px-3 py-3 space-y-3 bg-muted/10">
          {children}
          <div className="flex justify-end pt-1">
            <Button size="sm" variant={done ? "outline" : "default"} onClick={onToggleDone} className="text-xs">
              {done ? "Not done yet" : "Mark done"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// `bundleProps` lets the parent (TourModal) hand in the bundle picker's
// wired-up state so the Tracking section can host it inline (v0.85 —
// picker moved out of its own pre-checklist page and into this hub).
export default function SetupChecklist({ onCloseGuide, bundleProps = null }) {
  const t = useTerms();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [state, setState] = useState(() => loadChecklist());
  const [expanded, setExpanded] = useState(null);
  const [showImport, setShowImport] = useState(false);
  const [showActivityMenu, setShowActivityMenu] = useState(false);
  const [seedingTasks, setSeedingTasks] = useState(false);
  // Reminders step state: the plan-reminders global flag (the permission
  // check lives in NotificationStatusCard).
  const [planRemindersOn, setPlanRemindersOn] = useState(() => readPlanRemindersEnabled());
  const enablePlanReminders = () => {
    writePlanRemindersEnabled(true);
    setPlanRemindersOn(true);
    toast.success("Plan reminders on");
  };
  // Cloud push (reminders reach you with the app closed) — the same
  // registration Settings → Reminders uses. Opt-in, clearly labelled.
  const [pushOn, setPushOn] = useState(false);
  const [pushBusy, setPushBusy] = useState(false);
  useEffect(() => {
    let alive = true;
    import("@/lib/pushRegistration").then(({ isPushEnabled }) => isPushEnabled()).then((v) => { if (alive) setPushOn(!!v); }).catch(() => {});
    return () => { alive = false; };
  }, []);
  const enablePush = async () => {
    setPushBusy(true);
    try {
      const { registerPush } = await import("@/lib/pushRegistration");
      await registerPush();
      setPushOn(true);
      toast.success("Push reminders on");
    } catch (e) {
      toast.error(e?.message || "Couldn't set up push on this device");
    } finally { setPushBusy(false); }
  };
  const [showTaskManager, setShowTaskManager] = useState(false);
  const [taskSelection, setTaskSelection] = useState({});
  const [taskSelectionInit, setTaskSelectionInit] = useState(false);

  const { data: alters = [] } = useQuery({
    queryKey: ["alters"],
    queryFn: () => base44.entities.Alter.list(),
  });
  const { data: activities = [] } = useQuery({
    queryKey: ["activities", "recent5"],
    queryFn: () => base44.entities.Activity.list("-timestamp", 5),
  });
  const { data: taskTemplates = [] } = useQuery({
    queryKey: ["dailyTaskTemplates"],
    queryFn: () => base44.entities.DailyTaskTemplate.list(),
  });

  // Auto-detect completion when the underlying data exists — respects the
  // user's manual override (if they've explicitly marked something done or
  // undone, we don't fight them).
  useEffect(() => {
    setState((prev) => {
      const next = { ...prev };
      let changed = false;
      if (alters.filter((a) => !a.is_archived).length > 0 && !prev.altersUserToggled && !prev.alters) {
        next.alters = true; changed = true;
      }
      if (activities.length > 0 && !prev.activityUserToggled && !prev.activity) {
        next.activity = true; changed = true;
      }
      if (taskTemplates.length > 0 && !prev.tasksUserToggled && !prev.tasks) {
        next.tasks = true; changed = true;
      }
      if (planRemindersOn && !prev.remindersUserToggled && !prev.reminders) {
        next.reminders = true; changed = true;
      }
      if (changed) { saveChecklist(next); return next; }
      return prev;
    });
  }, [alters, activities, taskTemplates, planRemindersOn]);

  // Titles of user's existing templates (lower-cased, term-resolved on both
  // sides so a saved "System meeting" matches the "{{system}} meeting"
  // default). The resolved title is what actually gets persisted.
  const existingTitleSet = useMemo(() => {
    return new Set(taskTemplates.map((tt) => String(applyTaskTerms(tt.title || "", t)).trim().toLowerCase()));
  }, [taskTemplates, t]);

  const resolveDefaultTitle = (def) => applyTaskTerms(def.title || "", t);
  const isDefaultAlreadyAdded = (def) => existingTitleSet.has(String(resolveDefaultTitle(def)).trim().toLowerCase());

  // Initialise selection once — every default pre-ticked EXCEPT ones already
  // added (those show "Added" and don't count toward the batch). Re-init if
  // the existing set changes after a batch add.
  useEffect(() => {
    const initial = {};
    for (const def of DEFAULT_TASK_TEMPLATES) {
      initial[def.title] = !isDefaultAlreadyAdded(def);
    }
    setTaskSelection(initial);
    setTaskSelectionInit(true);
  }, [existingTitleSet]);

  const selectedDefaultCount = useMemo(() => {
    return DEFAULT_TASK_TEMPLATES.filter((d) => taskSelection[d.title] && !isDefaultAlreadyAdded(d)).length;
  }, [taskSelection, existingTitleSet]);

  const handleSeedDefaultTasks = async () => {
    if (seedingTasks) return;
    setSeedingTasks(true);
    try {
      let created = 0;
      for (const def of DEFAULT_TASK_TEMPLATES) {
        if (!taskSelection[def.title]) continue;
        if (isDefaultAlreadyAdded(def)) continue;
        // Persist term-resolved title so "{{system}} meeting" becomes the
        // user's term at seed time (matches TaskTemplateManager's own save
        // path which also resolves before writing).
        await base44.entities.DailyTaskTemplate.create({ ...def, title: resolveDefaultTitle(def) });
        created++;
      }
      queryClient.invalidateQueries({ queryKey: ["dailyTaskTemplates"] });
      toast.success(created > 0 ? `Added ${created} default task${created === 1 ? "" : "s"}` : "Nothing selected to add");
    } catch (e) {
      toast.error(e?.message || "Couldn't add defaults");
    } finally {
      setSeedingTasks(false);
    }
  };

  const toggle = (id) => {
    setState((prev) => {
      const next = { ...prev, [id]: !prev[id], [`${id}UserToggled`]: true };
      saveChecklist(next);
      return next;
    });
  };

  const progress = useMemo(() => {
    const done = CHECKLIST_ITEMS.filter((k) => !!state[k]).length;
    return { done, total: CHECKLIST_ITEMS.length };
  }, [state]);

  const items = [
    {
      id: "alters",
      icon: Users,
      title: `${t.Alters} setup`,
      description: `Add ${t.alters} one at a time, or import a backup.`,
      content: (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">
            You can add {t.alters} one by one from the {t.Alters} page, or import from Simply Plural,
            PluralKit, or a Symphony backup.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={() => { onCloseGuide?.(); navigate("/Home"); }} className="text-xs gap-1">
              <Plus className="w-3 h-3" /> Add {t.alters}
            </Button>
            <Button size="sm" variant="outline" onClick={() => setShowImport(true)} className="text-xs gap-1">
              <Download className="w-3 h-3" /> Import
            </Button>
          </div>
          <ImportAltersModal open={showImport} onClose={() => setShowImport(false)} />
        </div>
      ),
    },
    {
      id: "newui",
      icon: Sparkles,
      title: "Check out the widget board",
      description: "Swipe left on your home screen — pages you build from widgets.",
      content: (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Swipe left on your home screen (or use the grid button in its header) and you're on
            the widget board — extra pages you assemble yourself: what's on them, where each
            piece sits, how big it is and how it looks. Your home screen itself is editable the
            same way: open the ⚙ menu up top and choose "Edit home screen".
          </p>
          <Button
            size="sm"
            className="text-xs gap-1"
            onClick={() => {
              onCloseGuide?.();
              if (window.location.pathname === "/") {
                window.dispatchEvent(new CustomEvent("os-open-widget-board"));
              } else {
                navigate("/");
                setTimeout(() => window.dispatchEvent(new CustomEvent("os-open-widget-board")), 250);
              }
            }}
          >
            <Sparkles className="w-3 h-3" /> Open the widget board
          </Button>
          {/* The v2 bars hosted inside the CLASSIC chrome — the same
              toggles as Settings → Appearance → Layout, one component. */}
          <p className="text-xs text-muted-foreground pt-1">
            The new bars are part of the classic look too: the bottom bars, quick action bar and
            pinned {t.alters} bar are on by default, and the new top bar is one switch away.
          </p>
          <ClassicBarsToggles />
        </div>
      ),
    },
    {
      id: "levels",
      icon: Layers,
      title: `${t.Fronting} levels`,
      description: `How close to ${t.front} someone is — rename or add your own.`,
      content: (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            New {t.systems} start with {t.fronting}, Influencing and Observing. Rename them to
            your own words, add more, or remove the ones you don't use.
            On any {t.fronting} control: tap acts (your choice below), hold opens the level rail,
            and dragging right opens that {t.alter}'s menu.
          </p>
          <FrontLevelsSettings />
        </div>
      ),
    },
    {
      id: "tracking",
      icon: Heart,
      title: "Tracking setup",
      description: "Choose what to track, tune emotions, rename groups.",
      content: (
        <div className="space-y-4">
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">
              Oceans Symphony is designed to help you learn about and understand your {t.system}.
              The following preset packages are categories of experiences and symptoms that can be
              worthwhile for some to keep an eye on — pick as many or as few as you would like.
            </p>
            {bundleProps ? (
              <BundleList
                existingKeys={bundleProps.existingKeys}
                selected={bundleProps.selected}
                onToggleItem={bundleProps.onToggleItem}
                onToggleBundle={bundleProps.onToggleBundle}
                terms={bundleProps.terms}
              />
            ) : null}
            {bundleProps?.applyBundlesDiff && (
              <div className="flex justify-end">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={async () => { await bundleProps.applyBundlesDiff(); }}
                  className="text-xs"
                >
                  Save tracking selection
                </Button>
              </div>
            )}
          </div>
          <div className="border-t border-border/40 pt-3 space-y-2">
            <p className="text-xs text-muted-foreground">
              And tune emotions — mark distress, rename groups, add your own:
            </p>
            <CustomEmotionsManager />
          </div>
          <Button size="sm" variant="outline" onClick={() => { onCloseGuide?.(); navigate("/manage-checkin"); }} className="text-xs gap-1">
            Open check-in manager (sections, diary, more) <ExternalLink className="w-3 h-3" />
          </Button>
        </div>
      ),
    },
    {
      id: "activity",
      icon: ActivityIcon,
      title: "Activity tracker",
      description: "Add activities and sub-activities you'd like to track.",
      content: (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            The Activity tracker records what you're doing throughout the day — logged retroactively
            or planned ahead, in nested categories (Self-care → Hygiene → Shower). It powers the
            timeline's activity column and "goals" progress bars.
          </p>
          <p className="text-xs text-muted-foreground">
            Pick from these preset packs, or build your own from scratch.
          </p>
          <ActivityPackPicker />
          <div className="flex flex-wrap gap-2 pt-1 border-t border-border/40">
            <Button size="sm" variant="outline" onClick={() => setShowActivityMenu(true)} className="text-xs gap-1">
              <Settings2 className="w-3 h-3" /> Add / edit manually
            </Button>
            <Button size="sm" variant="outline" onClick={() => { onCloseGuide?.(); navigate("/activities"); }} className="text-xs gap-1">
              Open full tracker <ExternalLink className="w-3 h-3" />
            </Button>
          </div>
          {showActivityMenu && <ActivityCustomizationMenu onClose={() => setShowActivityMenu(false)} />}
        </div>
      ),
    },
    {
      id: "tasks",
      icon: CheckSquare,
      title: "Daily & recurring tasks",
      description: "Little routines that repeat — check-ins, taking meds, journaling.",
      content: (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Daily tasks are lightweight recurring items that reset every day (or on a schedule you
            set). They're great for anchoring the day — a morning check-in, taking meds, brushing
            teeth. Tick the ones you'd like, or build your own below.
          </p>
          {taskTemplates.length > 0 && (
            <p className="text-xs text-emerald-500">
              ✓ You already have {taskTemplates.length} task template{taskTemplates.length === 1 ? "" : "s"}.
            </p>
          )}

          <div className="space-y-1.5">
            <p className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground">
              Suggested daily tasks
            </p>
            <div className="rounded-lg border border-border/50 divide-y divide-border/40 overflow-hidden">
              {DEFAULT_TASK_TEMPLATES.map((def) => {
                const already = isDefaultAlreadyAdded(def);
                const checked = !!taskSelection[def.title] && !already;
                const resolvedTitle = resolveDefaultTitle(def);
                const resolvedDesc = applyTaskTerms(def.description || "", t);
                return (
                  <label
                    key={def.title}
                    className={`flex items-start gap-2 px-2.5 py-2 text-left cursor-pointer transition-colors ${
                      already ? "opacity-60 cursor-not-allowed bg-muted/20" : "hover:bg-muted/30"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      disabled={already}
                      onChange={() =>
                        setTaskSelection((prev) => ({ ...prev, [def.title]: !prev[def.title] }))
                      }
                      className="mt-0.5 w-4 h-4 accent-primary flex-shrink-0"
                    />
                    <span className="flex-1 min-w-0">
                      <span className="flex flex-wrap items-center gap-1.5">
                        <span className="text-xs font-medium">{resolvedTitle}</span>
                        <span
                          className={`text-[0.5625rem] px-1 py-px rounded font-semibold uppercase tracking-wide ${
                            def.mode === "AUTO"
                              ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
                              : "bg-muted text-muted-foreground"
                          }`}
                          title={def.mode === "AUTO" ? "Ticks itself when you do the thing" : "You tick this manually"}
                        >
                          {def.mode === "AUTO" ? "Auto" : "Manual"}
                        </span>
                        <span className="text-[0.5625rem] text-muted-foreground">+{def.points} XP</span>
                        {already && (
                          <span className="text-[0.5625rem] text-emerald-600 dark:text-emerald-400 font-semibold">
                            ✓ Added
                          </span>
                        )}
                      </span>
                      <span className="text-[0.6875rem] text-muted-foreground block leading-snug">{resolvedDesc}</span>
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              onClick={handleSeedDefaultTasks}
              disabled={seedingTasks || selectedDefaultCount === 0}
              className="text-xs gap-1"
            >
              {seedingTasks ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
              {selectedDefaultCount > 0 ? `Add ${selectedDefaultCount} selected` : "Add selected"}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowTaskManager(true)}
              className="text-xs gap-1"
            >
              <Settings2 className="w-3 h-3" /> Create / edit custom
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => { onCloseGuide?.(); navigate("/tasks"); }}
              className="text-xs gap-1"
            >
              Open task page <ExternalLink className="w-3 h-3" />
            </Button>
          </div>

          {showTaskManager && (
            <div className="fixed inset-0 z-[10001] bg-black/60 flex items-start justify-center p-4 overflow-y-auto" onClick={() => setShowTaskManager(false)}>
              <div className="bg-background border border-border rounded-xl shadow-2xl w-full max-w-lg my-8" onClick={(e) => e.stopPropagation()}>
                <div className="p-4">
                  <TaskTemplateManager templates={taskTemplates} onClose={() => {
                    setShowTaskManager(false);
                    queryClient.invalidateQueries({ queryKey: ["dailyTaskTemplates"] });
                  }} />
                </div>
              </div>
            </div>
          )}
        </div>
      ),
    },
    {
      id: "reminders",
      icon: Bell,
      title: "Notifications & reminders",
      description: "Get nudged before plans start, and for your own reminders.",
      content: (
        <div className="space-y-3">
          {/* The same status card as Settings: what's blocking
              notifications, each with its one-tap fix. */}
          <NotificationStatusCard includeBattery />
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant={planRemindersOn ? "outline" : "default"}
              onClick={enablePlanReminders}
              disabled={planRemindersOn}
              className="text-xs gap-1.5"
            >
              {planRemindersOn ? "Plan reminders on ✓" : "Turn on plan reminders"}
            </Button>
            <Button
              size="sm"
              variant={pushOn ? "outline" : "default"}
              onClick={enablePush}
              disabled={pushOn || pushBusy}
              className="text-xs gap-1.5"
            >
              {pushOn ? "Push reminders on ✓" : pushBusy ? "Setting up…" : "Turn on push reminders"}
            </Button>
            <Button size="sm" variant="outline" onClick={() => { onCloseGuide?.(); navigate("/reminders"); }} className="text-xs gap-1">
              Open Reminders <ExternalLink className="w-3 h-3" />
            </Button>
          </div>
          {/* The SAME persistent-notification toggles as Settings →
              Notifications (one component, not a copy) — Android-only,
              like there. */}
          {isNative() && (
            <div className="border-t border-border/40 pt-3">
              <PersistentNotificationsSection />
            </div>
          )}
        </div>
      ),
    },
    {
      id: "backup",
      icon: ShieldAlert,
      title: "Backups & optional encryption",
      description: "Local means no cloud copy — please don't skip. Set up automatic backups, and optionally lock everything behind a password.",
      highlight: true,
      content: (
        <div className="space-y-4">
          <AutoBackupSettings />
          <div className="border-t border-border/40 pt-3">
            <InlineEncryptionSetup />
          </div>
          <Button size="sm" variant="outline" onClick={() => { onCloseGuide?.(); navigate("/settings#data"); }} className="text-xs gap-1">
            Open Data &amp; privacy for more <ExternalLink className="w-3 h-3" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        Pick what fits — check items off as you go. Everything's editable later in Settings, and
        you can leave and come back to this guide from the dashboard.
      </p>
      <div className="flex items-center justify-between px-1">
        <span className="text-xs text-muted-foreground">
          {progress.done} of {progress.total} done
        </span>
        <div className="h-1.5 flex-1 mx-3 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-primary transition-all"
            style={{ width: `${(progress.done / progress.total) * 100}%` }}
          />
        </div>
      </div>
      <div className="space-y-2">
        {items.map((item) => (
          <ChecklistItem
            key={item.id}
            id={item.id}
            icon={item.icon}
            title={item.title}
            description={item.description}
            done={!!state[item.id]}
            expanded={expanded === item.id}
            highlight={!!item.highlight && !state[item.id]}
            onToggleExpand={() => setExpanded((cur) => (cur === item.id ? null : item.id))}
            onToggleDone={() => toggle(item.id)}
          >
            {item.content}
          </ChecklistItem>
        ))}
      </div>
    </div>
  );
}
