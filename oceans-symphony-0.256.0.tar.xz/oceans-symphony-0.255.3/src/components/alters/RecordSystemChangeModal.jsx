import React, { useState, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { localEntities, base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import MentionTextarea from "@/components/shared/MentionTextarea";
import { prepareAuthoredText, recordAuthoredText, isLogCommandError } from "@/lib/authoredText";
import { toast } from "sonner";
import { Loader2, GitMerge, Split, MoonStar, Sunrise, ChevronRight, ChevronLeft, Check, X, Search, Sparkles, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import AlterTreeSelect from "@/components/shared/AlterTreeSelect";
import { useTerms } from "@/lib/useTerms";

// ─── AlterChip ────────────────────────────────────────────────────────────────

function AlterAvatar({ alter, size = 7 }) {
  const resolved = useResolvedAvatarUrl(alter?.avatar_url);
  const [errFor, setErr] = useState(null);
  const err = !!errFor && errFor === resolved;
  const cls = `w-${size} h-${size} rounded-full flex-shrink-0`;
  if (resolved && !err) {
    return <img src={resolved} alt={alter?.name} className={`${cls} object-cover`} onError={() => setErr(resolved)} />;
  }
  return (
    <div className={`${cls} flex items-center justify-center text-xs font-bold text-white`}
      style={{ backgroundColor: alter?.color || "#9333ea" }}>
      {alter?.name?.charAt(0)?.toUpperCase()}
    </div>
  );
}

function AlterChip({ alter, selected, onClick, disabled }) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex items-center gap-2 px-3 py-2 rounded-xl border text-sm transition-all",
        selected
          ? "border-primary bg-primary/10 text-primary"
          : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-muted/50",
        disabled && "opacity-40 cursor-not-allowed"
      )}
    >
      <AlterAvatar alter={alter} size={6} />
      <span className="font-medium truncate max-w-[110px]">{alter.name}</span>
      {selected && <Check className="w-3.5 h-3.5 flex-shrink-0" />}
    </button>
  );
}

// ─── Type config ──────────────────────────────────────────────────────────────

const getTypes = (t) => [
  {
    id: "fusion",
    label: "Fusion",
    icon: GitMerge,
    color: "text-violet-500",
    bg: "bg-violet-500/10 border-violet-500/30",
    description: `Two or more ${t.alters} merge into one or form a new ${t.alter}.`,
  },
  {
    id: "split",
    label: "Split",
    icon: Split,
    color: "text-blue-500",
    bg: "bg-blue-500/10 border-blue-500/30",
    description: `One ${t.alter} splits into two or more distinct ${t.alters}.`,
  },
  {
    id: "dormancy",
    label: "Dormancy",
    icon: MoonStar,
    color: "text-indigo-500",
    bg: "bg-indigo-500/10 border-indigo-500/30",
    description: `One or more ${t.alters} go dormant / become less active.`,
  },
  {
    id: "return",
    label: "Return",
    icon: Sunrise,
    color: "text-amber-500",
    bg: "bg-amber-500/10 border-amber-500/30",
    description: `One or more ${t.alters} return from dormancy.`,
  },
  {
    id: "emergence",
    label: "Emergence",
    icon: Sparkles,
    color: "text-emerald-500",
    bg: "bg-emerald-500/10 border-emerald-500/30",
    description: `One or more ${t.alters} emerge or are first recognized in the ${t.system}.`,
  },
  {
    id: "reformation",
    label: "Reformation",
    icon: RefreshCw,
    color: "text-teal-500",
    bg: "bg-teal-500/10 border-teal-500/30",
    description: `One or more ${t.alters} take a new form but are still the same ${t.alter} — not a new ${t.alter}, not a fusion.`,
  },
];

// ─── Step components ──────────────────────────────────────────────────────────

function StepType({ value, onChange }) {
  const terms = useTerms();
  const TYPES = getTypes(terms);
  return (
    <div className="grid grid-cols-2 gap-3">
      {TYPES.map((t) => {
        const Icon = t.icon;
        const selected = value === t.id;
        return (
          <button
            key={t.id}
            type="button"
            onClick={() => onChange(t.id)}
            className={cn(
              "flex flex-col items-start gap-2 p-3 rounded-xl border-2 text-left transition-all",
              selected ? t.bg + " border-current" : "border-border bg-card hover:border-border/80 hover:bg-muted/30"
            )}
          >
            <Icon className={cn("w-5 h-5", selected ? t.color : "text-muted-foreground")} />
            <div>
              <p className={cn("text-sm font-semibold", selected ? t.color : "text-foreground")}>{t.label}</p>
              <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{t.description}</p>
            </div>
          </button>
        );
      })}
    </div>
  );
}

function StepSourceAlters({ type, alters, selected, onToggle, fusionType, onFusionTypeChange }) {
  const terms = useTerms();
  const isSingle = type === "split"; // locks to one selection
  // Fusion needs 2+ source alters; every other event type needs at least one.
  const requiresOne = type !== "fusion";

  const label = type === "fusion" ? `${terms.Alters} involved in the fusion (select 2+)`
    : type === "split" ? `Which ${terms.alter} is splitting?`
    : type === "dormancy" ? `Which ${terms.alters} are going dormant?`
    : type === "emergence" ? `Which ${terms.alters} emerged or were first recognized?`
    : type === "reformation" ? `Which ${terms.alters} were reformed (changed form but are still the same ${terms.alter})?`
    : `Which ${terms.alters} are returning?`;

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">{label}</p>

      <AlterTreeSelect
        selectionMode={isSingle ? "single" : "multi"}
        isSelected={(id) => selected.includes(id)}
        onToggle={(a) => onToggle(a.id, isSingle)}
        maxHeight="40vh"
      />

      {/* Selected pills */}
      {selected.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {selected.map(id => {
            const a = alters.find(x => x.id === id);
            if (!a) return null;
            return (
              <span key={id}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border text-foreground"
                style={{ borderColor: a.color || "hsl(var(--primary))", backgroundColor: (a.color || "#9333ea") + "22" }}>
                <span className="w-2 h-2 rounded-full ring-1 ring-background flex-shrink-0" style={{ backgroundColor: a.color || "hsl(var(--primary))" }} />
                {a.name}
                <button type="button" onClick={() => onToggle(a.id, false)} className="ml-0.5 opacity-70 hover:opacity-100">
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            );
          })}
        </div>
      )}

      {/* Validation */}
      {selected.length === 0 && (
        <p className="text-xs text-destructive">Select at least {requiresOne ? "one alter" : "two alters"}.</p>
      )}
      {type === "fusion" && selected.length === 1 && (
        <p className="text-xs text-destructive">Select at least two alters for a fusion.</p>
      )}

      {/* Fusion type picker */}
      {type === "fusion" && (
        <div>
          <p className="text-xs text-muted-foreground mb-2">Type of fusion</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onFusionTypeChange("absorption")}
              className={cn(
                "p-3 rounded-xl border-2 text-left transition-all",
                fusionType === "absorption"
                  ? "border-violet-500/60 bg-violet-500/10"
                  : "border-border bg-card hover:border-border/80"
              )}
            >
              <p className="text-sm font-semibold text-foreground">Absorption</p>
              <p className="text-xs text-muted-foreground mt-0.5">One alter absorbs the others and remains active.</p>
            </button>
            <button
              type="button"
              onClick={() => onFusionTypeChange("new_formation")}
              className={cn(
                "p-3 rounded-xl border-2 text-left transition-all",
                fusionType === "new_formation"
                  ? "border-violet-500/60 bg-violet-500/10"
                  : "border-border bg-card hover:border-border/80"
              )}
            >
              <p className="text-sm font-semibold text-foreground">New Formation</p>
              <p className="text-xs text-muted-foreground mt-0.5">All source alters become dormant; a new alter emerges.</p>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StepResult({ type, fusionType, sourceAlterIds, alters, absorptionTarget, onAbsorptionTarget, newAlterName, onNewAlterName, newAlterColor, onNewAlterColor, splitResults, onSplitResults }) {
  const terms = useTerms();
  const sourceAlters = alters.filter(a => sourceAlterIds.includes(a.id));
  const nonSourceAlters = alters.filter(a => !sourceAlterIds.includes(a.id));
  const [newSplitName, setNewSplitName] = useState("");
  const [search, setSearch] = useState("");

  if (type === "fusion" && fusionType === "absorption") {
    const filtered = sourceAlters.filter(a => a.name?.toLowerCase().includes(search.toLowerCase()));
    return (
      <div className="space-y-3">
        <p className="text-xs text-muted-foreground">Which {terms.alter} persists and remains active after the fusion?</p>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder={`Search ${terms.alters}...`} className="pl-8 text-sm h-8" />
        </div>
        <div className="max-h-52 overflow-y-auto space-y-1 rounded-lg border border-border/50 p-1.5 bg-muted/10">
          {filtered.map(a => {
            const isSelected = absorptionTarget === a.id;
            return (
              <button key={a.id} type="button" onClick={() => onAbsorptionTarget(a.id)}
                className={cn("w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg border text-left transition-all",
                  isSelected ? "border-primary/50 bg-primary/10" : "border-transparent hover:border-border/60 hover:bg-muted/40"
                )}>
                <AlterAvatar alter={a} size={6} />
                <span className="text-sm font-medium flex-1 truncate min-w-0" style={{ color: isSelected ? (a.color || "hsl(var(--primary))") : undefined }}>{a.name}</span>
                {isSelected && <Check className="w-3.5 h-3.5 flex-shrink-0" style={{ color: a.color || "hsl(var(--primary))" }} />}
              </button>
            );
          })}
          {filtered.length === 0 && <p className="text-xs text-muted-foreground italic px-2.5 py-2">No alters found</p>}
        </div>
        {!absorptionTarget && <p className="text-xs text-destructive">Select the alter that persists.</p>}
      </div>
    );
  }

  if (type === "fusion" && fusionType === "new_formation") {
    return (
      <div className="space-y-3">
        <div>
          <p className="text-xs text-muted-foreground mb-1">Name of the new {terms.alter} that emerges</p>
          <Input value={newAlterName} onChange={e => onNewAlterName(e.target.value)} placeholder={`New ${terms.alter} name`} className="text-sm" />
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Color (optional)</p>
          <div className="flex items-center gap-2">
            <input type="color" value={newAlterColor || "#9333ea"} onChange={e => onNewAlterColor(e.target.value)}
              className="w-9 h-9 rounded cursor-pointer border border-border" />
            <span className="text-xs text-muted-foreground">{newAlterColor || "#9333ea"}</span>
          </div>
        </div>
        {!newAlterName.trim() && <p className="text-xs text-destructive">Enter a name for the new alter.</p>}
      </div>
    );
  }

  if (type === "split") {
    const filteredNonSource = nonSourceAlters.filter(a => a.name?.toLowerCase().includes(search.toLowerCase()));
    const selectedExisting = splitResults.filter(r => r.type === "existing");

    const addNewSplit = () => {
      const trimmed = newSplitName.trim();
      if (!trimmed || splitResults.some(r => r.type === "new" && r.name === trimmed)) return;
      onSplitResults([...splitResults, { type: "new", name: trimmed, color: "#9333ea" }]);
      setNewSplitName("");
    };

    return (
      <div className="space-y-3">
        <div>
          <p className="text-xs text-muted-foreground mb-2">Which existing alters emerge from this split?</p>
          <div className="relative mb-2">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder={`Search ${terms.alters}...`} className="pl-8 text-sm h-8" />
          </div>
          <div className="max-h-44 overflow-y-auto space-y-1 rounded-lg border border-border/50 p-1.5 bg-muted/10">
            {filteredNonSource.map(a => {
              const isSelected = splitResults.some(r => r.type === "existing" && r.id === a.id);
              return (
                <button key={a.id} type="button"
                  onClick={() => onSplitResults(isSelected
                    ? splitResults.filter(r => !(r.type === "existing" && r.id === a.id))
                    : [...splitResults, { type: "existing", id: a.id, name: a.name }]
                  )}
                  className={cn("w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg border text-left transition-all",
                    isSelected ? "border-primary/50 bg-primary/10" : "border-transparent hover:border-border/60 hover:bg-muted/40"
                  )}>
                  <AlterAvatar alter={a} size={6} />
                  <span className="text-sm font-medium flex-1 truncate min-w-0" style={{ color: isSelected ? (a.color || "hsl(var(--primary))") : undefined }}>{a.name}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 flex-shrink-0" style={{ color: a.color || "hsl(var(--primary))" }} />}
                </button>
              );
            })}
            {filteredNonSource.length === 0 && <p className="text-xs text-muted-foreground italic px-2.5 py-2">No alters found</p>}
          </div>
          {selectedExisting.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {selectedExisting.map(r => {
                const a = nonSourceAlters.find(x => x.id === r.id);
                return (
                  <span key={r.id} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border text-foreground"
                    style={{ borderColor: a?.color || "hsl(var(--primary))", backgroundColor: (a?.color || "#9333ea") + "22" }}>
                    <span className="w-2 h-2 rounded-full ring-1 ring-background flex-shrink-0" style={{ backgroundColor: a?.color || "hsl(var(--primary))" }} />
                    {r.name}
                    <button type="button" onClick={() => onSplitResults(splitResults.filter(x => !(x.type === "existing" && x.id === r.id)))} className="ml-0.5 opacity-70 hover:opacity-100">
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                );
              })}
            </div>
          )}
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Or create new {terms.alters} from this split</p>
          <div className="flex gap-2">
            <Input value={newSplitName} onChange={e => setNewSplitName(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addNewSplit()} placeholder={`New ${terms.alter} name`} className="text-sm" />
            <Button type="button" size="sm" variant="outline" onClick={addNewSplit}>Add</Button>
          </div>
          {splitResults.filter(r => r.type === "new").map((r, i) => (
            <div key={i} className="flex items-center gap-2 mt-1.5 text-xs text-muted-foreground">
              <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">{r.name} (new)</span>
              <button type="button" onClick={() => onSplitResults(splitResults.filter((_, idx) => idx !== splitResults.indexOf(r)))}>
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
        {splitResults.length === 0 && <p className="text-xs text-destructive">Add at least one result {terms.alter}.</p>}
      </div>
    );
  }

  return null;
}

const MERGE_FIELDS = [
  { key: "description", label: "Description" },
  { key: "pronouns", label: "Pronouns" },
  { key: "role", label: "Role" },
];

function StepApply({
  type, fusionType, sourceAlterIds, absorptionTarget, alters,
  mergeSelections, onMergeSelections,
  archiveAbsorbed, onArchiveAbsorbed,
  archiveSource, onArchiveSource,
}) {
  const persistentAlter = alters.find(a => a.id === absorptionTarget);
  const absorbedAlters = alters.filter(a => sourceAlterIds.includes(a.id) && a.id !== absorptionTarget);
  const sourceAltersList = alters.filter(a => sourceAlterIds.includes(a.id));
  const sourceAlter = sourceAltersList[0];

  if (type === "fusion" && fusionType === "absorption") {
    const anyFieldToMerge = MERGE_FIELDS.some(f =>
      absorbedAlters.some(a => a[f.key]?.trim())
    );

    return (
      <div className="space-y-4">
        <label className="flex items-start gap-2.5 cursor-pointer">
          <input
            type="checkbox"
            checked={archiveAbsorbed}
            onChange={e => onArchiveAbsorbed(e.target.checked)}
            className="mt-0.5 w-4 h-4 accent-primary"
          />
          <div>
            <p className="text-sm font-medium">Archive absorbed alters</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {absorbedAlters.map(a => a.name).join(", ")} will be hidden from the active roster. Front history and data are preserved.
            </p>
          </div>
        </label>

        {anyFieldToMerge && (
          <div className="space-y-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              Merge into {persistentAlter?.name}
            </p>
            {MERGE_FIELDS.map(({ key, label }) => {
              const candidates = absorbedAlters
                .filter(a => a[key]?.trim())
                .map(a => ({ alterId: a.id, value: a[key], name: a.name }));
              if (candidates.length === 0) return null;
              const persistentValue = persistentAlter?.[key]?.trim();
              return (
                <div key={key} className="rounded-lg border border-border/60 p-2.5 space-y-1.5">
                  <p className="text-xs font-medium text-foreground">{label}</p>
                  {persistentValue && (
                    <p className="text-xs text-muted-foreground bg-muted/40 rounded px-2 py-1 break-words">
                      Current: {persistentValue}
                    </p>
                  )}
                  {candidates.map(({ alterId, value, name }) => {
                    const isSelected = (mergeSelections[key] || []).some(s => s.alterId === alterId);
                    return (
                      <label key={alterId} className="flex items-start gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          className="mt-0.5 w-3.5 h-3.5 accent-primary"
                          checked={isSelected}
                          onChange={e => {
                            if (e.target.checked) {
                              onMergeSelections(prev => ({ ...prev, [key]: [...(prev[key] || []), { alterId, value, name }] }));
                            } else {
                              onMergeSelections(prev => ({ ...prev, [key]: (prev[key] || []).filter(s => s.alterId !== alterId) }));
                            }
                          }}
                        />
                        <span className="text-xs break-words">
                          <span className="text-muted-foreground">From {name}:</span> {value}
                        </span>
                      </label>
                    );
                  })}
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  if (type === "fusion" && fusionType === "new_formation") {
    return (
      <div className="space-y-3">
        <div className="rounded-lg border border-border/60 p-3 space-y-2">
          <p className="text-sm font-medium">Alters to archive</p>
          <div className="space-y-1.5">
            {sourceAltersList.map(a => (
              <div key={a.id} className="flex items-center gap-2">
                <AlterAvatar alter={a} size={5} />
                <span className="text-sm text-foreground">{a.name}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            These alters will be hidden from the active roster. Their front history and data are fully preserved.
          </p>
        </div>
      </div>
    );
  }

  if (type === "split") {
    return (
      <div className="space-y-3">
        <label className="flex items-start gap-2.5 cursor-pointer">
          <input
            type="checkbox"
            checked={archiveSource}
            onChange={e => onArchiveSource(e.target.checked)}
            className="mt-0.5 w-4 h-4 accent-primary"
          />
          <div>
            <p className="text-sm font-medium">Archive {sourceAlter?.name} after split</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Check this if {sourceAlter?.name} no longer exists as a distinct part. Their front history is preserved and will appear in the result alters' history.
            </p>
          </div>
        </label>
      </div>
    );
  }

  return null;
}

function StepDetails({ year, onYear, cause, onCause, notes, onNotes, alters = [] }) {
  const currentYear = new Date().getFullYear();
  return (
    <div className="space-y-3">
      <div>
        <p className="text-xs text-muted-foreground mb-1">Year this occurred</p>
        <Input
          type="number"
          min={1900}
          max={currentYear}
          value={year}
          onChange={e => onYear(e.target.value)}
          placeholder={String(currentYear)}
          className="text-sm"
        />
      </div>
      <div>
        <p className="text-xs text-muted-foreground mb-1">Cause / trigger (optional)</p>
        <Input
          value={cause}
          onChange={e => onCause(e.target.value)}
          placeholder="e.g. Prolonged stress, trauma processing..."
          className="text-sm"
        />
      </div>
      <div>
        <p className="text-xs text-muted-foreground mb-1">Notes (optional)</p>
        <MentionTextarea
          value={notes}
          onChange={onNotes}
          alters={alters}
          signposts
          placeholder="Any additional context..."
          rows={3}
          className="text-sm resize-none"
        />
      </div>
    </div>
  );
}

// ─── Reformation "Changes" step ────────────────────────────────────────────────
// Reformation = the SAME alter in a new form. So instead of the generic
// year/cause/notes step it asks what changed, whether they have a new name,
// and whether there was a trigger.

function YesNo({ value, onChange, labelYes = "Yes", labelNo = "No" }) {
  return (
    <div className="inline-flex rounded-lg border border-border overflow-hidden" role="group">
      {[[true, labelYes], [false, labelNo]].map(([v, label]) => (
        <button
          key={label}
          type="button"
          aria-pressed={value === v}
          onClick={() => onChange(v)}
          className={cn(
            "px-4 py-1.5 text-xs font-medium transition-colors",
            value === v ? "bg-primary text-primary-foreground" : "bg-muted/30 text-muted-foreground hover:bg-muted/60"
          )}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

function StepReformation({
  alterName, canRename, year, onYear,
  whatChanged, onWhatChanged,
  hasNewName, onHasNewName, newName, onNewName, applyRename, onApplyRename,
  hasTrigger, onHasTrigger, trigger, onTrigger,
  notes, onNotes, alters = [],
}) {
  const currentYear = new Date().getFullYear();
  return (
    <div className="space-y-4">
      <div>
        <p className="text-xs text-muted-foreground mb-1">Year this occurred</p>
        <Input
          type="number" min={1900} max={currentYear}
          value={year} onChange={e => onYear(e.target.value)}
          placeholder={String(currentYear)} className="text-sm"
        />
      </div>

      <div>
        <p className="text-xs font-medium mb-1">What changes happened{alterName ? ` to ${alterName}` : ""}?</p>
        <p className="text-[0.6875rem] text-muted-foreground mb-1.5">Appearance, age, personality, role, abilities — whatever is different now.</p>
        <textarea
          value={whatChanged}
          onChange={e => onWhatChanged(e.target.value)}
          rows={3}
          placeholder="e.g. Looks older, calmer, took on a protector role…"
          className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm resize-none"
        />
      </div>

      {canRename && (
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-medium">New name?</p>
            <YesNo value={hasNewName} onChange={onHasNewName} />
          </div>
          {hasNewName && (
            <div className="space-y-2 pl-1">
              <Input
                value={newName} onChange={e => onNewName(e.target.value)}
                placeholder={alterName ? `New name (was ${alterName})` : "New name"} className="text-sm"
              />
              <label className="flex items-start gap-2 text-xs text-muted-foreground cursor-pointer">
                <input type="checkbox" checked={applyRename} onChange={e => onApplyRename(e.target.checked)} className="mt-0.5" />
                <span>Also change their profile name. The old name is kept in this event.</span>
              </label>
            </div>
          )}
        </div>
      )}

      <div className="space-y-2">
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs font-medium">Is there a trigger?</p>
          <YesNo value={hasTrigger} onChange={onHasTrigger} />
        </div>
        {hasTrigger && (
          <Input
            value={trigger} onChange={e => onTrigger(e.target.value)}
            placeholder="What set this off? e.g. a stressful event, a memory, a milestone…"
            className="text-sm"
          />
        )}
      </div>

      <div>
        <p className="text-xs text-muted-foreground mb-1">Notes (optional)</p>
        <MentionTextarea
          value={notes} onChange={onNotes} alters={alters} signposts
          placeholder="Any additional context..." rows={3} className="text-sm resize-none"
        />
      </div>
    </div>
  );
}

// ─── Main modal ───────────────────────────────────────────────────────────────

export default function RecordSystemChangeModal({ open, onClose, preselectedAlterIds = [] }) {
  const queryClient = useQueryClient();
  const terms = useTerms();
  const { data: alters = [] } = useQuery({
    queryKey: ["alters"],
    queryFn: () => localEntities.Alter.list(),
  });

  const sortedAlters = useMemo(() =>
    [...alters].filter(a => !a.is_archived).sort((a, b) => a.name.localeCompare(b.name)),
    [alters]
  );

  const [step, setStep] = useState(0);
  const [type, setType] = useState("fusion");
  const [sourceAlterIds, setSourceAlterIds] = useState(preselectedAlterIds);
  const [fusionType, setFusionType] = useState("absorption");
  const [absorptionTarget, setAbsorptionTarget] = useState(null);
  const [newAlterName, setNewAlterName] = useState("");
  const [newAlterColor, setNewAlterColor] = useState("#9333ea");
  const [splitResults, setSplitResults] = useState([]);
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [cause, setCause] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [mergeSelections, setMergeSelections] = useState({});
  const [archiveAbsorbed, setArchiveAbsorbed] = useState(true);
  const [archiveSource, setArchiveSource] = useState(false);
  // Reformation-only answers
  const [whatChanged, setWhatChanged] = useState("");
  const [hasNewName, setHasNewName] = useState(false);
  const [newName, setNewName] = useState("");
  const [applyRename, setApplyRename] = useState(true);
  const [hasTrigger, setHasTrigger] = useState(false);
  const [trigger, setTrigger] = useState("");

  const noResultStep = type === "dormancy" || type === "return" || type === "emergence" || type === "reformation";
  const steps = noResultStep
    ? ["Type", terms.Alters, type === "reformation" ? "Changes" : "Details"]
    : ["Type", terms.Alters, "Result", "Details", "Apply"];
  const totalSteps = steps.length;

  function toggleSource(id, single) {
    if (single) {
      setSourceAlterIds([id]);
    } else {
      setSourceAlterIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    }
  }

  function canAdvance() {
    if (step === 0) return !!type;
    if (step === 1) {
      if (type === "fusion") return sourceAlterIds.length >= 2 && !!fusionType;
      return sourceAlterIds.length >= 1;
    }
    if (step === 2 && type === "reformation") {
      if (sourceAlterIds.length === 1 && hasNewName) {
        const nn = newName.trim();
        const old = (alters.find(a => a.id === sourceAlterIds[0])?.name || "").trim();
        return !!nn && nn !== old;
      }
      return true;
    }
    if (step === 2 && !noResultStep) {
      if (type === "fusion" && fusionType === "absorption") return !!absorptionTarget;
      if (type === "fusion" && fusionType === "new_formation") return !!newAlterName.trim();
      if (type === "split") return splitResults.length > 0;
    }
    return true;
  }

  async function handleSave() {
    // Event notes render as plain text, so ~commands become "icon label" tokens.
    let prepared;
    try {
      prepared = await prepareAuthoredText(notes.trim(), { alters, terms, surfaceLabel: "lineage event note", chips: false });
    } catch (e) { if (isLogCommandError(e)) { toast.error(e.message); return; } throw e; }
    if (prepared === null) return; // user backed out of the whisper warning
    setSaving(true);
    try {
      let resultAlterIds = [];
      const reformOldName = (alters.find(a => a.id === sourceAlterIds[0])?.name || "").trim();
      const reformRename = type === "reformation" && sourceAlterIds.length === 1 && hasNewName && !!newName.trim();

      if (type === "fusion" && fusionType === "absorption") {
        resultAlterIds = [absorptionTarget];
      } else if (type === "fusion" && fusionType === "new_formation") {
        const created = await localEntities.Alter.create({
          name: newAlterName.trim(),
          color: newAlterColor,
          pronouns: "",
          description: "",
          is_archived: false,
        });
        resultAlterIds = [created.id];
      } else if (type === "split") {
        const existing = splitResults.filter(r => r.type === "existing").map(r => r.id);
        const created = await Promise.all(
          splitResults.filter(r => r.type === "new").map(r =>
            localEntities.Alter.create({ name: r.name, color: r.color || "#9333ea", is_archived: false })
          )
        );
        resultAlterIds = [...existing, ...created.map(c => c.id)];
      } else {
        // dormancy / return / reformation — result = same as source (same alter, no new one created)
        resultAlterIds = [...sourceAlterIds];
      }

      const yearNum = parseInt(year, 10) || new Date().getFullYear();
      const event = await localEntities.SystemChangeEvent.create({
        type,
        date: new Date(yearNum, 0, 1).toISOString(),
        year_only: true,
        source_alter_ids: sourceAlterIds,
        result_alter_ids: resultAlterIds,
        fusion_type: type === "fusion" ? fusionType : null,
        absorbed_into_alter_id: (type === "fusion" && fusionType === "absorption") ? absorptionTarget : null,
        cause: (type === "reformation" ? (hasTrigger ? trigger.trim() : "") : cause.trim()),
        notes: prepared.content,
        author_alter_ids: prepared.authorIds,
        ...(type === "reformation" ? {
          what_changed: whatChanged.trim() || null,
          renamed: reformRename,
          previous_name: reformRename ? reformOldName : null,
          new_name: reformRename ? newName.trim() : null,
        } : {}),
      });
      await recordAuthoredText({ ...prepared, alters, sourceType: "lineage", sourceId: event.id, sourceLabel: "Lineage event note", navigatePath: "/system-history" });

      // Reformation: the alter stays the same person — only optionally take the new name.
      if (reformRename && applyRename) {
        await localEntities.Alter.update(sourceAlterIds[0], { name: newName.trim() });
      }

      // Auto-create "Split from" relationships when a split event is recorded
      if (type === "split") {
        for (const resultId of resultAlterIds) {
          for (const sourceId of sourceAlterIds) {
            if (resultId !== sourceId) {
              await base44.entities.AlterRelationship.create({
                alter_id_a: resultId,
                alter_id_b: sourceId,
                relationship_type: "Split from",
                direction: "a_to_b",
                color: "#a855f7",
                notes: `Auto-created from split event (${yearNum})`,
                strength: 3,
              });
            }
          }
        }
        queryClient.invalidateQueries({ queryKey: ["alterRelationships"] });
      }

      // Apply profile changes from Apply step
      if (type === "fusion" && fusionType === "absorption") {
        if (archiveAbsorbed) {
          for (const id of sourceAlterIds.filter(id => id !== absorptionTarget)) {
            await localEntities.Alter.update(id, { is_archived: true });
          }
        }
        const hasSelections = Object.values(mergeSelections).some(arr => arr?.length > 0);
        if (hasSelections) {
          const persistentAlter = alters.find(a => a.id === absorptionTarget);
          const mergeData = {};
          for (const [key, selections] of Object.entries(mergeSelections)) {
            if (!Array.isArray(selections) || selections.length === 0) continue;
            const existingVal = persistentAlter?.[key]?.trim() || "";
            const appended = selections.map(s => `From ${s.name}: ${s.value}`).join("\n\n");
            mergeData[key] = existingVal ? `${existingVal}\n\n${appended}` : appended;
          }
          if (Object.keys(mergeData).length > 0) {
            await localEntities.Alter.update(absorptionTarget, mergeData);
          }
        }
      }
      if (type === "fusion" && fusionType === "new_formation") {
        for (const id of sourceAlterIds) {
          await localEntities.Alter.update(id, { is_archived: true });
        }
      }
      if (type === "split" && archiveSource) {
        for (const id of sourceAlterIds) {
          await localEntities.Alter.update(id, { is_archived: true });
        }
      }

      queryClient.invalidateQueries({ queryKey: ["systemChangeEvents"] });
      queryClient.invalidateQueries({ queryKey: ["alters"] });
      onClose();
    } finally {
      setSaving(false);
    }
  }

  const isLastStep = step === totalSteps - 1;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent onPointerDownOutside={(e) => e.preventDefault()} onInteractOutside={(e) => e.preventDefault()} className="w-[calc(100vw-2rem)] max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Record {terms.System} Event</DialogTitle>
        </DialogHeader>

        {/* Step indicator */}
        <div className="flex items-center gap-1 mb-1">
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <div className={cn(
                "flex items-center justify-center w-5 h-5 rounded-full text-[0.625rem] font-bold transition-colors",
                i < step ? "bg-primary text-primary-foreground"
                  : i === step ? "bg-primary/20 text-primary border border-primary/40"
                  : "bg-muted text-muted-foreground"
              )}>
                {i < step ? <Check className="w-3 h-3" /> : i + 1}
              </div>
              {i < steps.length - 1 && (
                <div className={cn("flex-1 h-px", i < step ? "bg-primary/40" : "bg-border")} />
              )}
            </React.Fragment>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mb-3">{steps[step]}</p>

        {/* Step content */}
        {step === 0 && <StepType value={type} onChange={v => { setType(v); setSourceAlterIds([]); setAbsorptionTarget(null); }} />}
        {step === 1 && (
          <StepSourceAlters
            type={type}
            alters={sortedAlters}
            selected={sourceAlterIds}
            onToggle={toggleSource}
            fusionType={fusionType}
            onFusionTypeChange={setFusionType}
          />
        )}
        {step === 2 && !noResultStep && (
          <StepResult
            type={type}
            fusionType={fusionType}
            sourceAlterIds={sourceAlterIds}
            alters={sortedAlters}
            absorptionTarget={absorptionTarget}
            onAbsorptionTarget={setAbsorptionTarget}
            newAlterName={newAlterName}
            onNewAlterName={setNewAlterName}
            newAlterColor={newAlterColor}
            onNewAlterColor={setNewAlterColor}
            splitResults={splitResults}
            onSplitResults={setSplitResults}
          />
        )}
        {step === 2 && type === "reformation" && (
          <StepReformation
            alterName={sourceAlterIds.length === 1 ? (alters.find(a => a.id === sourceAlterIds[0])?.name || "") : ""}
            canRename={sourceAlterIds.length === 1}
            year={year} onYear={setYear}
            whatChanged={whatChanged} onWhatChanged={setWhatChanged}
            hasNewName={hasNewName} onHasNewName={setHasNewName}
            newName={newName} onNewName={setNewName}
            applyRename={applyRename} onApplyRename={setApplyRename}
            hasTrigger={hasTrigger} onHasTrigger={setHasTrigger}
            trigger={trigger} onTrigger={setTrigger}
            notes={notes} onNotes={setNotes}
            alters={alters}
          />
        )}
        {((step === 2 && noResultStep && type !== "reformation") || (step === 3 && !noResultStep)) && (
          <StepDetails
            year={year} onYear={setYear}
            cause={cause} onCause={setCause}
            notes={notes} onNotes={setNotes}
            alters={alters}
          />
        )}
        {step === 4 && !noResultStep && (
          <StepApply
            type={type}
            fusionType={fusionType}
            sourceAlterIds={sourceAlterIds}
            absorptionTarget={absorptionTarget}
            alters={sortedAlters}
            mergeSelections={mergeSelections}
            onMergeSelections={setMergeSelections}
            archiveAbsorbed={archiveAbsorbed}
            onArchiveAbsorbed={setArchiveAbsorbed}
            archiveSource={archiveSource}
            onArchiveSource={setArchiveSource}
          />
        )}

        {/* Nav buttons */}
        <div className="flex gap-2 mt-4">
          {step > 0 && (
            <Button variant="outline" size="sm" className="flex-1" onClick={() => setStep(s => s - 1)}>
              <ChevronLeft className="w-4 h-4 mr-1" /> Back
            </Button>
          )}
          {!isLastStep && (
            <Button size="sm" className="flex-1" disabled={!canAdvance()} onClick={() => setStep(s => s + 1)}>
              Next <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          )}
          {isLastStep && (
            <Button size="sm" className="flex-1" disabled={saving || !canAdvance()} onClick={handleSave}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Event"}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
