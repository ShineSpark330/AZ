import React, { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { confirm } from "@/components/shared/ConfirmDialog";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { isLocalMode } from "@/lib/storageMode";
import { useTerms } from "@/lib/useTerms";
import { resolveImageUrl } from "@/lib/imageUrlResolver";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import { localEntities } from "@/api/base44Client";
import LocalImageFixer from "@/components/shared/LocalImageFixer";
import { toast } from "sonner";
import {
  ZoomIn, ZoomOut, RotateCcw, Plus, Grid, Eye, EyeOff, Users, X, Upload, Edit
} from "lucide-react";
import { Button } from "@/components/ui/button";
import ColorPicker from "@/components/shared/ColorPicker";
import LocationNode from "./LocationNode";
import CreateRelationshipModal, { RELATIONSHIP_PRESETS } from "./CreateRelationshipModal";

const localMode = isLocalMode ? isLocalMode() : false;
const db = localMode ? localEntities : base44.entities;

const SNAP = 20;
const NODE_RADIUS = 28;

function snapVal(v) { return Math.round(v / SNAP) * SNAP; }

// Resolve legacy local-image:// avatars before rendering (raw <img src> on
// those renders broken). Used in the unplaced-alters list (a .map()).
function UnplacedAlterAvatar({ alter }) {
  const resolved = useResolvedAvatarUrl(alter?.avatar_url);
  return resolved ? (
    <img src={resolved} className="w-6 h-6 rounded-full object-cover flex-shrink-0" onError={e => { e.currentTarget.style.display = "none"; }} />
  ) : (
    <div className="w-6 h-6 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
      style={{ backgroundColor: alter.color || "#8b5cf6", fontSize: 10 }}>
      {alter.name?.charAt(0)?.toUpperCase()}
    </div>
  );
}

// Selected-alter popover avatar — resolves legacy local-image:// the same way.
function SelectedAlterAvatar({ alter }) {
  const resolved = useResolvedAvatarUrl(alter?.avatar_url);
  return resolved ? (
    <img src={resolved} className="w-8 h-8 rounded-full object-cover" onError={e => { e.currentTarget.style.display = "none"; }} />
  ) : (
    <div className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold"
      style={{ backgroundColor: alter.color || "#8b5cf6", fontSize: 12 }}>
      {alter.name?.charAt(0)?.toUpperCase()}
    </div>
  );
}

function AlterNode({ alter, isSelected, isRelMode, viewOnly, onTap, onDoubleTap, onDragEnd, zoom }) {
  // Resolve legacy local-image:// avatars — a raw href on those renders broken.
  const resolvedAvatar = useResolvedAvatarUrl(alter?.avatar_url);
  const dragRef = useRef(null);
  const tapRef = useRef({ time: 0, timer: null });
  // Separate touch-tap detector to avoid interference with mouse events
  const touchTapRef = useRef({ time: 0, timer: null });

  const handleMouseDown = (e) => {
    e.stopPropagation();
    dragRef.current = { startMx: e.clientX, startMy: e.clientY, startX: alter.inner_world_x, startY: alter.inner_world_y, moved: false };

    const onMove = (ev) => {
      if (!dragRef.current) return;
      const dx = (ev.clientX - dragRef.current.startMx) / zoom;
      const dy = (ev.clientY - dragRef.current.startMy) / zoom;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) dragRef.current.moved = true;
    };
    const onUp = (ev) => {
      if (!dragRef.current) return;
      if (dragRef.current.moved) {
        if (!alter.inner_world_locked) {
          const dx = (ev.clientX - dragRef.current.startMx) / zoom;
          const dy = (ev.clientY - dragRef.current.startMy) / zoom;
          onDragEnd(dragRef.current.startX + dx, dragRef.current.startY + dy);
        }
      } else {
        // Mouse single/double tap
        const now = Date.now();
        if (now - tapRef.current.time < 300) {
          clearTimeout(tapRef.current.timer);
          tapRef.current.time = 0;
          onDoubleTap();
        } else {
          tapRef.current.time = now;
          tapRef.current.timer = setTimeout(() => { onTap(); }, 310);
        }
      }
      dragRef.current = null;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const handleTouchStart = (e) => {
    e.stopPropagation();
    e.preventDefault();
    const t = e.touches[0];
    dragRef.current = { startMx: t.clientX, startMy: t.clientY, startX: alter.inner_world_x, startY: alter.inner_world_y, moved: false, startTime: Date.now() };
  };

  const handleTouchMove = (e) => {
    e.stopPropagation();
    e.preventDefault();
    if (!dragRef.current) return;
    const t = e.touches[0];
    const dx = (t.clientX - dragRef.current.startMx) / zoom;
    const dy = (t.clientY - dragRef.current.startMy) / zoom;
    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
      dragRef.current.moved = true;
      // Live drag feedback — update position without saving
      if (!alter.inner_world_locked) {
        // Just mark as moved; save on touchEnd
      }
    }
  };

  const handleTouchEnd = (e) => {
    e.stopPropagation();
    e.preventDefault();
    if (!dragRef.current) return;
    const touch = e.changedTouches[0];
    const elapsed = Date.now() - dragRef.current.startTime;

    if (dragRef.current.moved) {
      if (!alter.inner_world_locked) {
        const dx = (touch.clientX - dragRef.current.startMx) / zoom;
        const dy = (touch.clientY - dragRef.current.startMy) / zoom;
        onDragEnd(dragRef.current.startX + dx, dragRef.current.startY + dy);
      }
      dragRef.current = null;
    } else if (elapsed < 500) {
      dragRef.current = null;
      // Double-tap detection
      const now = Date.now();
      if (now - touchTapRef.current.time < 300) {
        clearTimeout(touchTapRef.current.timer);
        touchTapRef.current.time = 0;
        onDoubleTap();
      } else {
        touchTapRef.current.time = now;
        touchTapRef.current.timer = setTimeout(() => { onTap(); }, 310);
      }
    } else {
      dragRef.current = null;
    }
  };

  const cx = alter.inner_world_x ?? 0;
  const cy = alter.inner_world_y ?? 0;
  const ringColor = isRelMode ? "#f59e0b" : isSelected ? "#3b82f6" : "transparent";

  return (
    <g onMouseDown={handleMouseDown} onTouchStart={handleTouchStart} onTouchMove={handleTouchMove} onTouchEnd={handleTouchEnd} style={{ cursor: alter.inner_world_locked ? "default" : "grab", touchAction: "none" }}>
      {/* Larger invisible touch target */}
      <circle cx={cx} cy={cy} r={NODE_RADIUS + 18} fill="transparent" />
      {(isSelected || isRelMode) && (
        <circle cx={cx} cy={cy} r={NODE_RADIUS + 5} fill="none" stroke={ringColor} strokeWidth={2.5} opacity={0.8} />
      )}
      <circle cx={cx} cy={cy} r={NODE_RADIUS} fill={alter.color || "#8b5cf6"} opacity={0.9} />
      {resolvedAvatar ? (
        <image x={cx - NODE_RADIUS + 2} y={cy - NODE_RADIUS + 2}
          width={(NODE_RADIUS - 2) * 2} height={(NODE_RADIUS - 2) * 2}
          href={resolvedAvatar} preserveAspectRatio="xMidYMid slice"
          style={{ borderRadius: NODE_RADIUS, clipPath: `circle(${NODE_RADIUS - 2}px)` }} />
      ) : (
        <text x={cx} y={cy + 5} textAnchor="middle" fontSize={14} fontWeight="bold" fill="white" pointerEvents="none">
          {alter.name?.charAt(0)?.toUpperCase()}
        </text>
      )}
      <text x={cx} y={cy + NODE_RADIUS + 13} textAnchor="middle" fontSize={10} fill="var(--color-text-primary)" pointerEvents="none"
        style={{ userSelect: "none" }}>
        {alter.name?.length > 14 ? alter.name.slice(0, 12) + "…" : alter.name}
      </text>
      {alter.inner_world_locked && !viewOnly && (
        <text x={cx + NODE_RADIUS - 4} y={cy + NODE_RADIUS - 4} textAnchor="middle" fontSize={10} pointerEvents="none">🔒</text>
      )}
    </g>
  );
}

function RelationshipLines({ relationships, alters, relMode, selectedAlter, onRelClick }) {
  if (relMode === 'none') return null;

  const visibleRels = relMode === 'selected'
    ? relationships.filter(r => r.alter_id_a === selectedAlter?.id || r.alter_id_b === selectedAlter?.id)
    : relationships;

  const alterMap = Object.fromEntries(alters.map(a => [a.id, a]));

  // Group by pair key for offset calculation
  const pairGroups = {};
  visibleRels.forEach(rel => {
    const key = [rel.alter_id_a, rel.alter_id_b].sort().join("-");
    if (!pairGroups[key]) pairGroups[key] = [];
    pairGroups[key].push(rel);
  });

  const lines = [];

  visibleRels.forEach(rel => {
    const a = alterMap[rel.alter_id_a];
    const b = alterMap[rel.alter_id_b];
    if (!a?.inner_world_x || !b?.inner_world_x) return;

    const pairKey = [rel.alter_id_a, rel.alter_id_b].sort().join("-");
    const pairRels = pairGroups[pairKey] || [rel];
    const relIndex = pairRels.findIndex(r => r.id === rel.id);
    const baseOffset = (relIndex - (pairRels.length - 1) / 2) * 10;

    const ax = a.inner_world_x, ay = a.inner_world_y;
    const bx = b.inner_world_x, by = b.inner_world_y;
    const dx = bx - ax, dy = by - ay;
    const len = Math.sqrt(dx * dx + dy * dy) || 1;
    const perpX = (-dy / len);
    const perpY = (dx / len);

    const color = rel.color || "#6b7280";
    const title = rel.relationship_type === "Custom" ? rel.custom_label : rel.relationship_type;
    const markerId = `iwarrow-${rel.id}`;

    const handleClick = (e) => { e.stopPropagation(); onRelClick?.(rel, e); };

    const renderLine = (key, lx1, ly1, lx2, ly2, mId) => (
      <g key={key} style={{ cursor: "pointer" }} onClick={handleClick}>
        {/* Wide transparent hit area */}
        <line x1={lx1} y1={ly1} x2={lx2} y2={ly2} stroke="transparent" strokeWidth={12} />
        {/* Visible line */}
        <line x1={lx1} y1={ly1} x2={lx2} y2={ly2}
          stroke={color} strokeWidth={2} opacity={0.75}
          markerEnd={`url(#${mId})`}>
          <title>{title}</title>
        </line>
      </g>
    );

    if (rel.direction === "a_to_b") {
      const ox = perpX * baseOffset, oy = perpY * baseOffset;
      lines.push(renderLine(`${rel.id}-atob`, ax + ox, ay + oy, bx + ox, by + oy, markerId));
    } else if (rel.direction === "b_to_a") {
      const ox = perpX * baseOffset, oy = perpY * baseOffset;
      lines.push(renderLine(`${rel.id}-btoa`, bx + ox, by + oy, ax + ox, ay + oy, markerId));
    } else {
      // bidirectional: single line with arrowheads on both ends
      const ox = perpX * baseOffset, oy = perpY * baseOffset;
      const markerStartId = `iwarrow-${rel.id}-start`;
      lines.push(
        <React.Fragment key={`${rel.id}-bi`}>
          <defs>
            <marker id={markerStartId} markerWidth="8" markerHeight="6" refX={NODE_RADIUS + 6} refY="3" orient="auto-start-reverse">
              <path d="M0,0 L0,6 L8,3 z" fill={color} opacity={0.9} />
            </marker>
          </defs>
          <g style={{ cursor: "pointer" }} onClick={handleClick}>
            <line x1={ax + ox} y1={ay + oy} x2={bx + ox} y2={by + oy} stroke="transparent" strokeWidth={12} />
            <line x1={ax + ox} y1={ay + oy} x2={bx + ox} y2={by + oy}
              stroke={color} strokeWidth={2} opacity={0.75}
              markerStart={`url(#${markerStartId})`}
              markerEnd={`url(#${markerId})`}>
              <title>{title}</title>
            </line>
          </g>
        </React.Fragment>
      );
    }
  });

  return (
    <g>
      <defs>
        {visibleRels.map(rel => (
          <marker key={`arr-${rel.id}`} id={`iwarrow-${rel.id}`} markerWidth="8" markerHeight="6"
            refX={NODE_RADIUS + 6} refY="3" orient="auto">
            <path d="M0,0 L0,6 L8,3 z" fill={rel.color || "#6b7280"} opacity={0.9} />
          </marker>
        ))}
      </defs>
      {lines}
    </g>
  );
}

function AlterRelationshipsSection({ alter, relationships, alterMap }) {
  const myRels = relationships.filter(r => r.alter_id_a === alter.id || r.alter_id_b === alter.id);

  return (
    <div className="mt-2 pt-2 border-t border-border/50 space-y-1">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Relationships</p>
      {myRels.length === 0 && (
        <p className="text-xs text-muted-foreground italic">No relationships defined</p>
      )}
      {myRels.map(rel => {
        const isA = rel.alter_id_a === alter.id;
        const otherId = isA ? rel.alter_id_b : rel.alter_id_a;
        const other = alterMap[otherId];
        const arrow = rel.direction === "bidirectional" ? "↔"
          : (isA && rel.direction === "a_to_b") || (!isA && rel.direction === "b_to_a") ? "→" : "←";
        const label = rel.relationship_type === "Custom" ? (rel.custom_label || "Custom") : rel.relationship_type;
        return (
          <div key={rel.id} className="flex items-center gap-1.5 text-xs">
            <span className="text-muted-foreground">{arrow}</span>
            <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: rel.color || "#6b7280" }} />
            <span className="text-foreground font-medium truncate">{other?.name || "?"}</span>
            <span className="text-muted-foreground truncate">({label})</span>
          </div>
        );
      })}
    </div>
  );
}

export default function InnerWorldMap({ alters: allAlters, relationships, onRefreshRelationships }) {
  const terms = useTerms();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const svgRef = useRef(null);
  const mapContainerRef = useRef(null);
  const bgFileRef = useRef(null);
  const lastPinchRef = useRef(null);
  const touchStartPos = useRef(null);
  const justSelectedRef = useRef(false);
  const hasAutoFit = useRef(false);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const panMovedRef = useRef(false);
  const [placingAlter, setPlacingAlter] = useState(null);
  const [panelOpen, setPanelOpen] = useState(() => {
    try { return JSON.parse(localStorage.getItem("iw_panel_open") ?? "true"); }
    catch { return true; }
  });

  const [snapToGrid, setSnapToGrid] = useState(false);
  const [relMode, setRelMode] = useState('all'); // 'all' | 'selected' | 'none'
  const [showAll, setShowAll] = useState(true);
  const [viewOnly, setViewOnly] = useState(false);

  const [selectedAlter, setSelectedAlter] = useState(null);
  const [relModeAlter, setRelModeAlter] = useState(null);
  const [createRelModal, setCreateRelModal] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [editingLocation, setEditingLocation] = useState(null);
  const [viewingLocation, setViewingLocation] = useState(null);
  const [resolvedEditBgUrl, setResolvedEditBgUrl] = useState(null);
  const [resolvedViewBgUrl, setResolvedViewBgUrl] = useState(null);
  const [relPopover, setRelPopover] = useState(null); // { rel, x, y }
  const [editingRelFromPopover, setEditingRelFromPopover] = useState(null);
  const [showCreateRelModal, setShowCreateRelModal] = useState(false);

  const { data: locations = [], refetch: refetchLocations } = useQuery({
    queryKey: ["innerWorldLocations"],
    queryFn: () => db.InnerWorldLocation.list(),
  });

  const placedAlters = useMemo(() => allAlters.filter(a => !a.is_archived && a.inner_world_x != null), [allAlters]);
  const unplacedAlters = useMemo(() => allAlters.filter(a => !a.is_archived && a.inner_world_x == null), [allAlters]);
  const alterMap = useMemo(() => Object.fromEntries(allAlters.map(a => [a.id, a])), [allAlters]);

  // Touch handlers
  const handleTouchStart = (e) => {
    if (e.touches.length === 1) {
      panMovedRef.current = false;
      touchStartPos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      setIsDragging(true);
      setDragStart({ x: e.touches[0].clientX - transform.x, y: e.touches[0].clientY - transform.y });
    }
  };

  const handleTouchMove = (e) => {
    e.preventDefault();
    if (e.touches.length === 2) {
      // Pinch zoom
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      if (lastPinchRef.current !== null) {
        const delta = dist / lastPinchRef.current;
        setTransform(t => ({ 
          ...t, 
          scale: Math.max(0.2, Math.min(4, t.scale * delta)) 
        }));
      }
      lastPinchRef.current = dist;
    } else if (e.touches.length === 1 && isDragging) {
      const dx = Math.abs(e.touches[0].clientX - (dragStart.x + transform.x));
      const dy = Math.abs(e.touches[0].clientY - (dragStart.y + transform.y));
      if (dx > 5 || dy > 5) panMovedRef.current = true;
      setTransform(t => ({ 
        ...t, 
        x: e.touches[0].clientX - dragStart.x, 
        y: e.touches[0].clientY - dragStart.y 
      }));
    }
  };

  const handleTouchEnd = (e) => {
    lastPinchRef.current = null;
    // Only treat as pan if touch moved more than 8px
    if (touchStartPos.current && e.changedTouches.length > 0) {
      const touch = e.changedTouches[0];
      const dx = Math.abs(touch.clientX - touchStartPos.current.x);
      const dy = Math.abs(touch.clientY - touchStartPos.current.y);
      if (dx <= 8 && dy <= 8) {
        // Treat as canvas tap (for placing alters)
        if (placingAlter && e.target === svgRef.current) {
          const rect = svgRef.current.getBoundingClientRect();
          const nx = (touch.clientX - rect.left - transform.x) / transform.scale;
          const ny = (touch.clientY - rect.top - transform.y) / transform.scale;
          saveAlterPosition(placingAlter, nx, ny, snapToGrid);
          setPlacingAlter(null);
        } else {
          setRelPopover(null);
        }
      }
    }
    setIsDragging(false);
    touchStartPos.current = null;
  };

  // Pan handlers
  const handleMouseDown = (e) => {
    if (e.button !== 0) return;
    panMovedRef.current = false;
    setIsDragging(true);
    setDragStart({ x: e.clientX - transform.x, y: e.clientY - transform.y });
  };
  const handleMouseMove = (e) => {
    if (!isDragging) return;
    const dx = Math.abs(e.clientX - (dragStart.x + transform.x));
    const dy = Math.abs(e.clientY - (dragStart.y + transform.y));
    if (dx > 5 || dy > 5) panMovedRef.current = true;
    setTransform(t => ({ ...t, x: e.clientX - dragStart.x, y: e.clientY - dragStart.y }));
  };
  const handleMouseUp = () => setIsDragging(false);
  const handleWheel = (e) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setTransform(t => ({ ...t, scale: Math.max(0.2, Math.min(4, t.scale * delta)) }));
  };

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    svg.addEventListener("wheel", handleWheel, { passive: false });
    return () => svg.removeEventListener("wheel", handleWheel);
  }, []);

  // Prevent page scroll and browser pinch-zoom inside the map container
  useEffect(() => {
    const el = mapContainerRef.current;
    if (!el) return;
    const preventScroll = (e) => e.preventDefault();
    el.addEventListener("wheel", preventScroll, { passive: false });
    el.addEventListener("touchmove", preventScroll, { passive: false });
    return () => {
      el.removeEventListener("wheel", preventScroll);
      el.removeEventListener("touchmove", preventScroll);
    };
  }, []);

  // Prevent browser-level pinch zoom while map is mounted
  useEffect(() => {
    const prevent = (e) => { if (e.touches?.length > 1) e.preventDefault(); };
    document.addEventListener("touchstart", prevent, { passive: false });
    return () => document.removeEventListener("touchstart", prevent);
  }, []);

  useEffect(() => {
    localStorage.setItem("iw_panel_open", JSON.stringify(panelOpen));
  }, [panelOpen]);

  const handleZoom = (dir) => setTransform(t => ({
    ...t, scale: Math.max(0.2, Math.min(4, t.scale * (dir === "in" ? 1.2 : 0.85)))
  }));

  const fitToPlacedAlters = useCallback((altersToFit) => {
    if (!altersToFit.length || !svgRef.current) return;
    const padding = 60;
    const svgWidth = svgRef.current.clientWidth || 600;
    const svgHeight = svgRef.current.clientHeight || 400;
    const xs = altersToFit.map(a => a.inner_world_x);
    const ys = altersToFit.map(a => a.inner_world_y);
    const minX = Math.min(...xs) - NODE_RADIUS;
    const maxX = Math.max(...xs) + NODE_RADIUS;
    const minY = Math.min(...ys) - NODE_RADIUS;
    const maxY = Math.max(...ys) + NODE_RADIUS + 16; // extra for label
    const contentWidth = maxX - minX;
    const contentHeight = maxY - minY;
    if (contentWidth <= 0 || contentHeight <= 0) return;
    const scaleX = (svgWidth - padding * 2) / contentWidth;
    const scaleY = (svgHeight - padding * 2) / contentHeight;
    const scale = Math.min(scaleX, scaleY, 1);
    const x = (svgWidth - contentWidth * scale) / 2 - minX * scale;
    const y = (svgHeight - contentHeight * scale) / 2 - minY * scale;
    setTransform({ x, y, scale });
  }, []);

  const handleReset = () => {
    if (placedAlters.length) fitToPlacedAlters(placedAlters);
    else setTransform({ x: 0, y: 0, scale: 1 });
  };

  // Auto-fit once on first load when placed alters are available
  useEffect(() => {
    if (hasAutoFit.current || placedAlters.length === 0) return;
    hasAutoFit.current = true;
    requestAnimationFrame(() => fitToPlacedAlters(placedAlters));
  }, [placedAlters, fitToPlacedAlters]);

  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") setRelModeAlter(null); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Resolve local-image:// URL for the editing location's background
  useEffect(() => {
    const url = editingLocation?.background_image_url;
    if (!url) { setResolvedEditBgUrl(null); return; }
    resolveImageUrl(url).then(setResolvedEditBgUrl);
  }, [editingLocation?.background_image_url]);

  // Resolve local-image:// URL for the viewing location's background
  useEffect(() => {
    const url = viewingLocation?.background_image_url;
    if (!url) { setResolvedViewBgUrl(null); return; }
    resolveImageUrl(url).then(setResolvedViewBgUrl);
  }, [viewingLocation?.background_image_url]);

  const saveAlterPosition = useCallback(async (alter, nx, ny, snap) => {
    let fx = nx, fy = ny;
    if (snap) { fx = snapVal(nx); fy = snapVal(ny); }

    const sortedLocs = [...locations].sort((a, b) => (b.order || 0) - (a.order || 0));
    let locationId = null;
    for (const loc of sortedLocs) {
      if (fx >= loc.x && fx <= loc.x + (loc.width || 200) && fy >= loc.y && fy <= loc.y + (loc.height || 150)) {
        locationId = loc.id;
        break;
      }
    }

    await db.Alter.update(alter.id, { inner_world_x: fx, inner_world_y: fy, inner_world_location_id: locationId });
    queryClient.invalidateQueries({ queryKey: ["alters"] });
  }, [locations, queryClient]);

  const removeAlterFromCanvas = async (alter) => {
    await db.Alter.update(alter.id, { inner_world_x: null, inner_world_y: null, inner_world_location_id: null });
    queryClient.invalidateQueries({ queryKey: ["alters"] });
    if (selectedAlter?.id === alter.id) setSelectedAlter(null);
  };

  const addLocation = async () => {
    const cx = (-transform.x / transform.scale) + 200;
    const cy = (-transform.y / transform.scale) + 200;
    const loc = await db.InnerWorldLocation.create({
      name: "New Location", shape: "rectangle", color: "#6366f1",
      x: cx, y: cy, width: 200, height: 150, order: locations.length
    });
    refetchLocations();
    setSelectedLocation(loc);
    setEditingLocation(loc);
  };

  const updateLocation = useCallback(async (loc, fields) => {
    await db.InnerWorldLocation.update(loc.id, fields);
    refetchLocations();
  }, [refetchLocations]);

  const deleteLocation = async (loc) => {
    await db.InnerWorldLocation.delete(loc.id);
    refetchLocations();
    setSelectedLocation(null);
    setEditingLocation(null);
  };

  const handleAlterTap = (alter) => {
    justSelectedRef.current = true;
    setTimeout(() => { justSelectedRef.current = false; }, 50);
    
    if (relModeAlter) {
      if (relModeAlter.id === alter.id) { setRelModeAlter(null); return; }
      setCreateRelModal({ alterA: relModeAlter, alterB: alter });
      setRelModeAlter(null);
    } else {
      setSelectedAlter(prev => prev?.id === alter.id ? null : alter);
    }
  };

  const handleAlterDoubleTap = (alter) => {
    setRelModeAlter(prev => prev?.id === alter.id ? null : alter);
    setSelectedAlter(null);
  };

  const handleSaveRelationship = async (data) => {
    await base44.entities.AlterRelationship.create(data);
    queryClient.invalidateQueries({ queryKey: ["alterRelationships"] });
    onRefreshRelationships?.();
    setCreateRelModal(null);
  };

  const handleSvgDrop = (e) => {
    e.preventDefault();
    const alterId = e.dataTransfer.getData("alterId");
    if (!alterId) return;
    const alter = allAlters.find(a => a.id === alterId);
    if (!alter) return;
    const rect = svgRef.current.getBoundingClientRect();
    const nx = (e.clientX - rect.left - transform.x) / transform.scale;
    const ny = (e.clientY - rect.top - transform.y) / transform.scale;
    saveAlterPosition(alter, nx, ny, snapToGrid);
  };

  const handleBgImageFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !editingLocation) return;
    e.target.value = "";
    // Shared helper preserves animated GIFs (stores them untouched) and only
    // recompresses static JPEG/PNG — the old inline canvas froze GIFs.
    const { processUploadedImage, saveLocalImage: save, createLocalImageUrl: makeUrl } = await import("@/lib/localImageStorage");
    const { dataUrl } = await processUploadedImage(file, 1200, 0.8);
    let imageUrl = dataUrl;
    if (isLocalMode()) {
      const imageId = `location-bg-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      await save(imageId, dataUrl);
      imageUrl = makeUrl(imageId);
    }
    setEditingLocation(l => ({ ...l, background_image_url: imageUrl }));
    updateLocation(editingLocation, { background_image_url: imageUrl });
  };

  const sortedLocations = useMemo(() => [...locations].sort((a, b) => (a.order || 0) - (b.order || 0)), [locations]);

  return (
    <div className="relative w-full h-full flex" style={{ touchAction: 'none' }}>
      {/* Unplaced alters panel — toggleable, with tap-to-place on mobile and drag-drop on desktop */}
      {showAll && unplacedAlters.length > 0 && (
        <>
          {panelOpen ? (
            <div className="w-40 flex-shrink-0 bg-card border-r border-border overflow-y-auto flex flex-col z-10">
              <div className="flex items-center justify-between px-2 py-1.5 border-b border-border/50 flex-shrink-0">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Unplaced</p>
                <button onClick={() => setPanelOpen(false)} className="text-muted-foreground hover:text-foreground" title="Collapse panel">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
                {unplacedAlters.map(alter => (
                  <div
                    key={alter.id}
                    draggable
                    onDragStart={e => e.dataTransfer.setData("alterId", alter.id)}
                    onClick={() => setPlacingAlter(alter)}
                    className={`flex items-center gap-2 px-2 py-1.5 rounded-lg border transition-colors cursor-pointer ${
                      placingAlter?.id === alter.id
                        ? "border-primary/60 bg-primary/15 animate-pulse"
                        : "border-border/50 bg-muted/20 hover:bg-muted/40 active:cursor-grabbing"
                    }`}>
                    <UnplacedAlterAvatar alter={alter} />
                    <span className="text-xs text-foreground truncate">{alter.name}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <button
              onClick={() => setPanelOpen(true)}
              title={`Expand unplaced ${terms.alters}`}
              className="flex-shrink-0 w-8 h-32 bg-card border-r border-border flex items-center justify-center hover:bg-muted/50 transition-colors z-10">
              <div className="flex flex-col items-center gap-1 rotate-180 text-muted-foreground hover:text-foreground">
                <span className="text-xs font-bold">U</span>
              </div>
            </button>
          )}
        </>
      )}

      {/* Tap-to-place banner */}
      {placingAlter && !viewOnly && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-primary/90 text-white text-xs font-semibold px-4 py-2 rounded-full shadow-lg z-20 flex items-center gap-2">
          <span>Tap map to place {placingAlter.name}</span>
          <button onClick={() => setPlacingAlter(null)} className="ml-1 hover:opacity-70">
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* SVG Canvas */}
      <div ref={mapContainerRef} className="relative flex-1 min-w-0 h-full bg-card overflow-hidden"
        style={{ touchAction: "none" }}
        style={{ backgroundImage: "radial-gradient(circle, var(--color-muted) 1px, transparent 1px)", backgroundSize: "24px 24px" }}>
        <svg
          ref={svgRef}
          className="w-full h-full"
          style={{ cursor: isDragging ? "grabbing" : relModeAlter ? "crosshair" : placingAlter ? "crosshair" : "grab", touchAction: 'none' }}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onDrop={handleSvgDrop}
          onDragOver={e => e.preventDefault()}
          onClick={(e) => {
            // Don't close anything if we just selected an alter
            if (justSelectedRef.current) return;
            // Only close popovers if clicking directly on canvas background (SVG root)
            const isSvgRoot = e.target.tagName === 'svg' && e.target === svgRef.current;
            if (isSvgRoot) {
              if (placingAlter) {
                const rect = svgRef.current.getBoundingClientRect();
                const nx = (e.clientX - rect.left - transform.x) / transform.scale;
                const ny = (e.clientY - rect.top - transform.y) / transform.scale;
                saveAlterPosition(placingAlter, nx, ny, snapToGrid);
                setPlacingAlter(null);
              } else {
                setRelPopover(null);
              }
            }
          }}
        >
          <g style={{ transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.scale})` }}>
            {sortedLocations.map(loc => (
              <LocationNode
                key={loc.id}
                location={loc}
                isSelected={selectedLocation?.id === loc.id}
                zoom={transform.scale}
                viewOnly={viewOnly}
                onSelect={() => { if (!panMovedRef.current) { setSelectedLocation(loc); if (viewOnly) setViewingLocation(loc); } }}
                onDoubleSelect={() => { if (!panMovedRef.current && !viewOnly) { setSelectedLocation(loc); setEditingLocation(loc); } }}
                onLongPress={() => { if (viewOnly) { setViewingLocation(loc); } else { setSelectedLocation(loc); setEditingLocation(loc); } }}
                onEdit={() => { if (!viewOnly) { setSelectedLocation(loc); setEditingLocation(loc); } }}
                onUpdate={(fields) => { if (!viewOnly) updateLocation(loc, fields); }}
                onDelete={() => deleteLocation(loc)}
              />
            ))}

            <RelationshipLines
              relationships={relationships}
              alters={placedAlters}
              relMode={relMode}
              selectedAlter={selectedAlter}
              onRelClick={(rel, e) => {
                const rect = svgRef.current?.getBoundingClientRect();
                setRelPopover({ rel, x: e.clientX - (rect?.left || 0), y: e.clientY - (rect?.top || 0) });
              }}
            />

            {placedAlters.map(alter => (
              <g key={alter.id}>
                <AlterNode
                  alter={{ ...alter, inner_world_locked: alter.inner_world_locked || viewOnly }}
                  isSelected={selectedAlter?.id === alter.id}
                  isRelMode={relModeAlter?.id === alter.id}
                  viewOnly={viewOnly}
                  zoom={transform.scale}
                  onTap={() => handleAlterTap(alter)}
                  onDoubleTap={() => handleAlterDoubleTap(alter)}
                  onDragEnd={(nx, ny) => saveAlterPosition(alter, nx, ny, snapToGrid)}
                />
                {!viewOnly && (
                  <g onClick={() => removeAlterFromCanvas(alter)} style={{ cursor: "pointer" }}>
                    <circle
                      cx={(alter.inner_world_x ?? 0) + NODE_RADIUS}
                      cy={(alter.inner_world_y ?? 0) - NODE_RADIUS}
                      r={12} fill="#ef4444" opacity={0.85} />
                    <text
                      x={(alter.inner_world_x ?? 0) + NODE_RADIUS}
                      y={(alter.inner_world_y ?? 0) - NODE_RADIUS + 4}
                      textAnchor="middle" fontSize={10} fill="white" pointerEvents="none">×</text>
                  </g>
                )}
              </g>
            ))}
          </g>
        </svg>

        {/* Rel mode banner */}
        {relModeAlter && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-amber-500/90 text-white text-xs font-semibold px-4 py-1.5 rounded-full shadow-lg z-20">
            Relationship mode: click another alter — Esc to cancel
          </div>
        )}

        {/* View mode toggle */}
        <button onClick={() => setViewOnly(v => !v)}
          className={`absolute top-3 right-3 flex items-center gap-1 px-2 py-1 rounded-lg text-xs border transition-colors bg-card/90 backdrop-blur-sm ${viewOnly ? "bg-primary/20 text-primary border-primary/40" : "border-border text-muted-foreground hover:border-primary/30"}`}
          title={viewOnly ? "Exit view mode" : "Enter view mode"}>
          {viewOnly ? <Eye className="w-3 h-3" /> : <Edit className="w-3 h-3" />}
          {viewOnly ? "View" : "Edit"}
        </button>

        {/* Toolbar — top right (below view toggle) */}
        <div className="absolute top-11 right-3 flex flex-col gap-1 z-20">
          {!viewOnly && (
            <Button size="sm" variant="outline" className="text-xs h-7 gap-1 px-2 bg-card/90 backdrop-blur-sm" onClick={addLocation}>
              <Plus className="w-3 h-3" /> Location
            </Button>
          )}
          <button onClick={() => setSnapToGrid(v => !v)}
            className={`flex items-center gap-1 ${viewOnly ? 'px-1.5' : 'px-2'} py-1 rounded-lg text-xs border transition-colors bg-card/90 backdrop-blur-sm ${snapToGrid ? "bg-primary/20 text-primary border-primary/40" : "border-border text-muted-foreground hover:border-primary/30"}`}>
            <Grid className="w-3 h-3" /> {!viewOnly && 'Snap'}
          </button>
          <button onClick={() => setRelMode(m => m === 'all' ? 'selected' : m === 'selected' ? 'none' : 'all')}
            className={`flex items-center gap-1 ${viewOnly ? 'px-1.5' : 'px-2'} py-1 rounded-lg text-xs border transition-colors bg-card/90 backdrop-blur-sm ${relMode !== 'none' ? "bg-primary/20 text-primary border-primary/40" : "border-border text-muted-foreground"}`}>
            {relMode === 'all' ? <Eye className="w-3 h-3" /> : relMode === 'selected' ? <Users className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            {!viewOnly && (relMode === 'all' ? 'Rels: All' : relMode === 'selected' ? 'Rels: Selected' : 'Rels: Hidden')}
          </button>
          <button onClick={() => setShowAll(v => !v)}
            className={`flex items-center gap-1 ${viewOnly ? 'px-1.5' : 'px-2'} py-1 rounded-lg text-xs border transition-colors bg-card/90 backdrop-blur-sm ${showAll ? "bg-primary/20 text-primary border-primary/40" : "border-border text-muted-foreground"}`}>
            <Users className="w-3 h-3" />
            {!viewOnly && (showAll ? 'Hide panel' : 'Unplaced')}
          </button>
        </div>

        {/* Zoom controls — bottom right */}
        <div className="absolute bottom-4 right-3 flex flex-col gap-1 z-20">
          <Button size="icon" variant="outline" className="h-8 w-8 bg-card/90 backdrop-blur-sm" onClick={() => handleZoom('in')}>
            <ZoomIn className="w-3.5 h-3.5" />
          </Button>
          <Button size="icon" variant="outline" className="h-8 w-8 bg-card/90 backdrop-blur-sm" onClick={() => handleZoom('out')}>
            <ZoomOut className="w-3.5 h-3.5" />
          </Button>
          <Button size="icon" variant="outline" className="h-8 w-8 bg-card/90 backdrop-blur-sm" onClick={handleReset}>
            <RotateCcw className="w-3.5 h-3.5" />
          </Button>
        </div>

        {/* Location view modal (view mode) */}
        {viewingLocation && viewOnly && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={() => setViewingLocation(null)}>
            <div className="bg-card border border-border rounded-xl p-5 shadow-xl w-full max-w-sm mx-4 space-y-3" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-foreground text-sm">{viewingLocation.name}</h3>
                <button onClick={() => setViewingLocation(null)}><X className="w-4 h-4 text-muted-foreground" /></button>
              </div>
              {viewingLocation.description && (
                <p className="text-xs text-muted-foreground">{viewingLocation.description}</p>
              )}
              <div className="space-y-1">
                <p className="text-xs font-semibold text-muted-foreground uppercase">Shape</p>
                <p className="text-xs text-foreground capitalize">{viewingLocation.shape || "rectangle"}</p>
              </div>
              {viewingLocation.background_image_url && (
                <img src={resolvedViewBgUrl || viewingLocation.background_image_url} alt="location" className="w-full h-24 object-cover rounded border border-border" />
              )}
            </div>
          </div>
        )}

        {/* Location edit sidebar */}
        {editingLocation && !viewOnly && (
          <div className="absolute right-3 top-56 bg-card border border-border rounded-xl p-3 space-y-2 w-56 z-20 shadow-lg max-h-[calc(100%-220px)] overflow-y-auto">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-foreground">Edit Location</p>
              <button onClick={() => setEditingLocation(null)}><X className="w-3 h-3 text-muted-foreground" /></button>
            </div>
            <div className="flex gap-2 items-center">
              <input value={editingLocation.name || ""} onChange={e => {
                const v = e.target.value;
                setEditingLocation(l => ({ ...l, name: v }));
                updateLocation(editingLocation, { name: v });
              }} placeholder="Name" className="flex-1 h-7 px-2 text-xs border border-border rounded bg-background" />
              <button
                onClick={() => {
                  const locked = !editingLocation.is_locked;
                  setEditingLocation(l => ({ ...l, is_locked: locked }));
                  updateLocation(editingLocation, { is_locked: locked });
                }}
                className={`h-7 px-2.5 rounded text-xs font-medium transition-colors ${
                  editingLocation.is_locked
                    ? "bg-amber-100/30 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border border-amber-200/50 dark:border-amber-800/50"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted/80 border border-border/50"
                }`}
                title={editingLocation.is_locked ? "Unlock location" : "Lock location"}
              >
                🔒
              </button>
            </div>

            <select value={editingLocation.shape || "rectangle"} onChange={e => {
              const v = e.target.value;
              setEditingLocation(l => ({ ...l, shape: v }));
              updateLocation(editingLocation, { shape: v });
            }} className="w-full h-7 px-2 text-xs border border-border rounded bg-background">
              <option value="rectangle">Rectangle</option>
              <option value="oval">Oval</option>
            </select>

            {/* Color picker */}
             <div className="space-y-1">
               <p className="text-xs text-muted-foreground">Color</p>
               <ColorPicker 
                 value={editingLocation.color || "#6366f1"} 
                 onChange={v => {
                   setEditingLocation(l => ({ ...l, color: v }));
                   if (/^#[0-9a-fA-F]{6}$/.test(v)) updateLocation(editingLocation, { color: v });
                 }}
                 className="justify-between"
               />
             </div>

            {/* Background image */}
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Background image URL</p>
              <input value={editingLocation.background_image_url || ""} onChange={e => {
                const v = e.target.value;
                setEditingLocation(l => ({ ...l, background_image_url: v }));
                updateLocation(editingLocation, { background_image_url: v });
              }} placeholder="https://..." className="w-full h-7 px-2 text-xs border border-border rounded bg-background" />
              <button
                onClick={() => bgFileRef.current?.click()}
                className="w-full flex items-center justify-center gap-1 h-7 text-xs border border-dashed border-border rounded hover:border-primary/50 hover:bg-muted/30 transition-colors text-muted-foreground">
                <Upload className="w-3 h-3" /> Upload image file
              </button>
              <input ref={bgFileRef} type="file" accept="image/*" hidden onChange={handleBgImageFile} />
              {editingLocation.background_image_url && (
                <div className="relative">
                  <img src={resolvedEditBgUrl || editingLocation.background_image_url} alt="bg preview"
                    className="w-full h-16 object-cover rounded border border-border" />
                  <div className="absolute bottom-1 left-1">
                    <LocalImageFixer
                      value={editingLocation.background_image_url}
                      maxWidth={1200}
                      quality={0.8}
                      onFixed={(url) => {
                        setEditingLocation(l => ({ ...l, background_image_url: url }));
                        updateLocation(editingLocation, { background_image_url: url });
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Background image opacity */}
            {editingLocation.background_image_url && (
              <div className='space-y-1'>
                <div className='flex items-center justify-between'>
                  <p className='text-xs text-muted-foreground'>Image opacity</p>
                  <span className='text-xs text-muted-foreground font-mono'>
                    {Math.round((editingLocation.background_opacity ?? 0.7) * 100)}%
                  </span>
                </div>
                <input
                  type='range'
                  min={0.05}
                  max={1}
                  step={0.05}
                  value={editingLocation.background_opacity ?? 0.7}
                  onChange={e => {
                    const v = parseFloat(e.target.value);
                    setEditingLocation(l => ({ ...l, background_opacity: v }));
                    updateLocation(editingLocation, { background_opacity: v });
                  }}
                  className='w-full accent-primary'
                />
              </div>
            )}

            {/* Layer order */}
            <div className='space-y-1'>
              <p className='text-xs text-muted-foreground'>Layer order</p>
              <div className='flex gap-1'>
                <button
                  onClick={() => {
                    const newOrder = (editingLocation.order || 0) + 1;
                    setEditingLocation(l => ({ ...l, order: newOrder }));
                    updateLocation(editingLocation, { order: newOrder });
                  }}
                  className='flex-1 h-7 text-xs border border-border rounded hover:bg-muted/50 transition-colors'
                >
                  ↑ Bring forward
                </button>
                <button
                  onClick={() => {
                    const newOrder = Math.max(0, (editingLocation.order || 0) - 1);
                    setEditingLocation(l => ({ ...l, order: newOrder }));
                    updateLocation(editingLocation, { order: newOrder });
                  }}
                  className='flex-1 h-7 text-xs border border-border rounded hover:bg-muted/50 transition-colors'
                >
                  ↓ Send back
                </button>
              </div>
              <p className='text-xs text-muted-foreground text-center'>Layer: {editingLocation.order || 0}</p>
            </div>

            <textarea value={editingLocation.description || ""} onChange={e => {
              const v = e.target.value;
              setEditingLocation(l => ({ ...l, description: v }));
              updateLocation(editingLocation, { description: v });
            }} placeholder="Description..." rows={2}
              className="w-full px-2 py-1 text-xs border border-border rounded bg-background resize-none" />

            <Button size="sm" variant="destructive" className="w-full h-7 text-xs"
              onClick={async () => { if ((await confirm("Delete this location?"))) deleteLocation(editingLocation); }}>
              Delete Location
            </Button>
          </div>
        )}

        {/* Relationship line popover */}
         {relPopover && (() => {
           const left = relPopover.x + 8;
           const top = relPopover.y + 8;
          const rel = relPopover.rel;
          const label = rel.relationship_type === "Custom" ? rel.custom_label : rel.relationship_type;
          return (
            <div
              className="absolute z-30 bg-card border border-border rounded-xl p-3 shadow-lg space-y-1.5 min-w-[160px]"
              style={{ left, top }}
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-foreground">{label}</span>
                <button onClick={() => setRelPopover(null)}><X className="w-3 h-3 text-muted-foreground" /></button>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: rel.color || "#6b7280" }} />
                {rel.direction === "bidirectional" ? "↔" : "→"}
              </div>
              {rel.notes && <p className="text-xs text-muted-foreground italic">{rel.notes}</p>}
              <button
                onClick={() => { setEditingRelFromPopover(rel); setRelPopover(null); }}
                className="text-xs text-primary hover:underline block">
                Edit relationship
              </button>
            </div>
          );
        })()}

        {/* Alter detail panel */}
        {selectedAlter && !relModeAlter && (
          <div className="absolute bottom-3 left-3 bg-card border border-border rounded-xl p-3 space-y-1.5 w-52 z-20 shadow-lg max-h-80 overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onTouchStart={e => e.stopPropagation()}
            onTouchEnd={e => e.stopPropagation()}
            onTouchMove={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SelectedAlterAvatar alter={selectedAlter} />
                <p className="text-sm font-semibold">{selectedAlter.name}</p>
              </div>
              <button onClick={() => setSelectedAlter(null)}><X className="w-3 h-3 text-muted-foreground" /></button>
            </div>
            {selectedAlter.pronouns && <p className="text-xs text-muted-foreground">{selectedAlter.pronouns}</p>}
            {selectedAlter.role && <p className="text-xs text-muted-foreground capitalize">{selectedAlter.role}</p>}
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={() => navigate(`/alter/${selectedAlter.id}`)}
                className="text-xs text-primary hover:underline">View full profile →</button>
              <button onClick={async () => {
                const newLocked = !selectedAlter.inner_world_locked;
                await db.Alter.update(selectedAlter.id, { inner_world_locked: newLocked });
                queryClient.invalidateQueries({ queryKey: ["alters"] });
                setSelectedAlter({ ...selectedAlter, inner_world_locked: newLocked });
                toast(newLocked ? "Position locked" : "Position unlocked");
              }}
                className={`h-7 px-2.5 rounded text-xs font-medium transition-colors ${
                  selectedAlter.inner_world_locked
                    ? "bg-amber-100/30 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border border-amber-200/50 dark:border-amber-800/50"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted/80 border border-border/50"
                }`}>
                🔒 {selectedAlter.inner_world_locked ? "Locked" : "Lock position"}
              </button>
            </div>
            {/* Relationships for this alter */}
            <AlterRelationshipsSection
              alter={selectedAlter}
              relationships={relationships}
              alterMap={alterMap}
            />
          </div>
        )}
      </div>

      {showCreateRelModal && selectedAlter && (
        <CreateRelationshipModal
          alterA={selectedAlter}
          allAlters={allAlters}
          alterB={null}
          onSave={handleSaveRelationship}
          onClose={() => setShowCreateRelModal(false)}
        />
      )}

      {createRelModal && (
        <CreateRelationshipModal
          alterA={createRelModal.alterA}
          allAlters={allAlters}
          alterB={createRelModal.alterB}
          onSave={handleSaveRelationship}
          onClose={() => setCreateRelModal(null)}
        />
      )}

      {editingRelFromPopover && (
        <EditRelFromPopover
          rel={editingRelFromPopover}
          alterMap={alterMap}
          onClose={() => setEditingRelFromPopover(null)}
          onSaved={() => {
            queryClient.invalidateQueries({ queryKey: ["alterRelationships"] });
            onRefreshRelationships?.();
            setEditingRelFromPopover(null);
          }}
        />
      )}
    </div>
  );
}

// Minimal inline edit modal for relationships opened from popover
function EditRelFromPopover({ rel, alterMap, onClose, onSaved }) {
  const [direction, setDirection] = useState(rel.direction);
  const [relType, setRelType] = useState(rel.relationship_type);
  const [customLabel, setCustomLabel] = useState(rel.custom_label || "");
  const [color, setColor] = useState(rel.color || "#6b7280");
  const [notes, setNotes] = useState(rel.notes || "");
  const [saving, setSaving] = useState(false);
  const alterA = alterMap[rel.alter_id_a];
  const alterB = alterMap[rel.alter_id_b];

  const handleSave = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await base44.entities.AlterRelationship.update(rel.id, { direction, relationship_type: relType, custom_label: customLabel, color, notes });
      toast.success("Relationship updated");
      onSaved();
    } catch (err) {
      toast.error(err.message || "Failed to update");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={onClose}>
      <div className="bg-card border border-border rounded-xl p-5 shadow-xl w-full max-w-sm mx-4 space-y-4" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-foreground text-sm">Edit Relationship</h3>
          <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Direction</p>
          <button
            onClick={() => {
              const cycle = ["a_to_b", "b_to_a", "bidirectional"];
              const idx = cycle.indexOf(direction);
              setDirection(cycle[(idx + 1) % cycle.length]);
            }}
            className="w-full px-4 py-3 rounded-xl border-2 border-primary/40 bg-primary/5 text-primary font-semibold text-sm text-center hover:bg-primary/10 transition-colors select-none"
          >
            {direction === "a_to_b" ? `${alterA?.name} → ${alterB?.name}` : direction === "b_to_a" ? `${alterB?.name} → ${alterA?.name}` : `${alterA?.name} ↔ ${alterB?.name}`}
            <span className="block text-xs text-primary/60 font-normal mt-0.5">tap to change direction</span>
          </button>
        </div>
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Type</p>
          <select value={relType} onChange={e => setRelType(e.target.value)}
            className="w-full h-9 px-3 rounded-md border border-border bg-background text-sm">
            {RELATIONSHIP_PRESETS.map(p => <option key={p.type} value={p.type}>{p.type}</option>)}
          </select>
          {relType === "Custom" && (
            <input value={customLabel} onChange={e => setCustomLabel(e.target.value)}
              placeholder="Custom label..." className="mt-2 w-full h-9 px-3 rounded-md border border-border bg-background text-sm" />
          )}
        </div>
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Color</p>
          <ColorPicker value={color} onChange={setColor} />
        </div>
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Notes</p>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2}
            className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm resize-none" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button className="flex-1" onClick={handleSave} loading={saving} disabled={saving}>Save</Button>
        </div>
      </div>
    </div>
  );
}