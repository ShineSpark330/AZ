import React, { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { HexColorPicker } from "react-colorful";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { DEFAULT_RELATIONSHIP_TYPES, flattenTypeTree } from "@/lib/relationshipTypes";
import { useTerms } from "@/lib/useTerms";
import AlterTreeSelect from "@/components/shared/AlterTreeSelect";
import MentionTextarea from "@/components/shared/MentionTextarea";

// Kept for backward compat with RelationshipsPanel import
export const RELATIONSHIP_PRESETS = DEFAULT_RELATIONSHIP_TYPES.map(t => ({ type: t.label, color: t.color }));

function useRelationshipTypes() {
  const { data = [] } = useQuery({
    queryKey: ["relationshipTypes"],
    queryFn: async () => {
      const all = await base44.entities.RelationshipType.list();
      if (all.length === 0) return DEFAULT_RELATIONSHIP_TYPES.map((t, i) => ({ ...t, id: i, order: i }));
      return all.filter(t => !t.is_archived).sort((a, b) => (a.order || 0) - (b.order || 0));
    },
  });
  return data;
}

// Cycle-safe, depth-tagged render order for a <select> of relationship types,
// so children appear indented under their parent. The OPTION value stays the
// type's label — `relationship_type` on AlterRelationship has always stored
// the label, never the id, so nesting must not change what's saved.
function TypeOptions({ types }) {
  const tree = flattenTypeTree(types);
  // (removed) const NBSP = "  ";
  const NB = String.fromCharCode(160); // U+00A0 survives in <option>; ASCII spaces collapse
  const indent = (d) => (d > 0 ? NB.repeat(d * 2) + "↳ " : "");
  return tree.map(t => (
    <option key={t.id ?? t.label} value={t.label} data-depth={t._depth || 0}>
      {indent(t._depth || 0)}{t.label}{false && `${"  ".repeat(t._depth || 0)}${t.label}`}
    </option>
  ));
}

// Cycles: a_to_b → b_to_a → bidirectional → a_to_b
const DIRECTION_CYCLE = ["a_to_b", "b_to_a", "bidirectional"];

function directionLabel(direction, nameA, nameB) {
  if (!nameA || !nameB) return "↔";
  if (direction === "a_to_b") return `${nameA} → ${nameB}`;
  if (direction === "b_to_a") return `${nameB} → ${nameA}`;
  return `${nameA} ↔ ${nameB}`;
}

// Resolve legacy local-image:// avatars before rendering (raw <img src> on
// those renders broken). Rendered inside a .map(), so it must be a child.

function AlterPickerDropdown({ label, selected, excludeId, onSelect }) {
  const terms = useTerms();
  const [open, setOpen] = useState(false);
  const selectedResolvedUrl = useResolvedAvatarUrl(selected?.avatar_url);
  const [selectedImgErrorFor, setSelectedImgError] = useState(null);
  const selectedImgError = !!selectedImgErrorFor && selectedImgErrorFor === selectedResolvedUrl;

  return (
    <div className="space-y-1 relative">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</p>
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-background hover:bg-muted/30 transition-colors text-left">
        {selected ? (
          <>
            {selectedResolvedUrl && !selectedImgError ? (
              <img src={selectedResolvedUrl} className="w-5 h-5 rounded-full object-cover flex-shrink-0" onError={() => setSelectedImgError(selectedResolvedUrl)} />
            ) : (
              <div className="w-5 h-5 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0 text-xs"
                style={{ backgroundColor: selected.color || "#8b5cf6" }}>
                {selected.name?.charAt(0)?.toUpperCase()}
              </div>
            )}
            <p className="text-sm font-medium text-foreground truncate">{selected.name}</p>
          </>
        ) : (
          <span className="text-sm text-muted-foreground">Select an {terms.alter}...</span>
        )}
      </button>

      {open && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-50 p-2">
          <AlterTreeSelect
            selectionMode="single"
            excludeIds={excludeId ? [excludeId] : []}
            isSelected={(id) => selected?.id === id}
            onToggle={(a) => { onSelect(a); setOpen(false); }}
            maxHeight="42vh"
          />
        </div>
      )}
    </div>
  );
}

// Searchable, nesting-aware picker for the relationship TYPE — mirrors the
// AlterPickerDropdown pattern above (and the app's other nested pickers) so a
// type's parent→child hierarchy shows with real indentation, not a flat native
// <select>. The saved value stays the type's LABEL (relationship_type on
// AlterRelationship has always stored the label, never the id), so nesting
// never changes what's persisted. (Supersedes the old TypeOptions <select>.)
function TypePickerDropdown({ types, value, onChange }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const tree = flattenTypeTree(types);
  const selected = types.find((t) => t.label === value);
  const q = search.trim().toLowerCase();
  const rows = q
    ? tree.filter((t) => (t.label || "").toLowerCase().includes(q)).map((t) => ({ ...t, _depth: 0 }))
    : tree;
  return (
    <div className="relative">
      <button type="button" onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-background text-sm text-left">
        {selected && <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: selected.color || "#6b7280" }} />}
        <span className="flex-1 truncate">{value || "Select a type…"}</span>
        <span className="text-muted-foreground text-xs">▾</span>
      </button>
      {open && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-50">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search types…"
            className="w-full px-3 py-2 border-b border-border/50 bg-background rounded-t-lg text-sm focus:outline-none focus:ring-1 focus:ring-primary" />
          <div className="max-h-52 overflow-y-auto">
            {rows.length === 0 ? (
              <p className="px-3 py-2 text-xs text-muted-foreground">No types found</p>
            ) : rows.map((t) => (
              <button key={t.id ?? t.label} type="button"
                onClick={() => { onChange(t.label); setOpen(false); setSearch(""); }}
                className={`w-full flex items-center gap-2 py-1.5 pr-3 text-left text-sm hover:bg-muted/40 ${t.label === value ? "bg-primary/10" : ""}`}
                style={{ paddingLeft: 12 + (t._depth || 0) * 16 }}>
                {(t._depth || 0) > 0 && <span className="text-muted-foreground/50 flex-shrink-0">↳</span>}
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: t.color || "#6b7280" }} />
                <span className="truncate">{t.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function CreateRelationshipModal({ alterA: initialAlterA, allAlters = [], alterB: initialAlterB, onSave, onClose }) {
  const relTypes = useRelationshipTypes();
  const [selectedAlterA, setSelectedAlterA] = useState(initialAlterA || null);
  const [selectedAlterB, setSelectedAlterB] = useState(initialAlterB || null);
  const [direction, setDirection] = useState("bidirectional");
  const [relType, setRelType] = useState("");
  const [color, setColor] = useState("#3b82f6");
  const [notes, setNotes] = useState("");
  const [strength, setStrength] = useState(3);
  const [showColorPicker, setShowColorPicker] = useState(false);

  // Set default type once loaded
  useEffect(() => {
    if (relTypes.length > 0 && !relType) {
      setRelType(relTypes[0].label);
      setColor(relTypes[0].color || "#3b82f6");
    }
  }, [relTypes]);

  const handleTypeChange = (label) => {
    setRelType(label);
    const found = relTypes.find(t => t.label === label);
    if (found) setColor(found.color || "#6b7280");
  };

  const cycleDirection = () => {
    const idx = DIRECTION_CYCLE.indexOf(direction);
    setDirection(DIRECTION_CYCLE[(idx + 1) % DIRECTION_CYCLE.length]);
  };

  const handleSave = () => {
    if (!selectedAlterA || !selectedAlterB) return;
    onSave({
      alter_id_a: selectedAlterA.id,
      alter_id_b: selectedAlterB.id,
      relationship_type: relType,
      custom_label: "",
      direction,
      color,
      notes,
      strength,
    });
  };

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 pb-16 sm:pb-0" onClick={onClose}>
      <div className="bg-card border border-border rounded-xl p-5 shadow-xl w-full max-w-sm mx-4 space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-foreground">Create Relationship</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
        </div>

        {/* Alter A */}
        <AlterPickerDropdown
          label="Alter A"
          selected={selectedAlterA}
          allAlters={allAlters}
          excludeId={selectedAlterB?.id}
          onSelect={setSelectedAlterA}
        />

        {/* Alter B */}
        <AlterPickerDropdown
          label="Alter B"
          selected={selectedAlterB}
          allAlters={allAlters}
          excludeId={selectedAlterA?.id}
          onSelect={setSelectedAlterB}
        />

        {/* Direction — tap arrow to cycle */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Direction</p>
          <button
            onClick={cycleDirection}
            className="w-full px-4 py-3 rounded-xl border-2 border-primary/40 bg-primary/5 text-primary font-semibold text-sm text-center hover:bg-primary/10 transition-colors select-none"
          >
            {directionLabel(direction, selectedAlterA?.name, selectedAlterB?.name)}
            <span className="block text-xs text-primary/60 font-normal mt-0.5">tap to change direction</span>
          </button>
        </div>

        {/* Type — searchable, nesting-aware picker */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Type</p>
          <TypePickerDropdown types={relTypes} value={relType} onChange={handleTypeChange} />
        </div>

        {/* Strength */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">
            Strength <span className="font-normal normal-case text-muted-foreground/70">{["", "Very Weak", "Weak", "Moderate", "Strong", "Very Strong"][strength]}</span>
          </p>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map(v => (
              <button key={v} onClick={() => setStrength(v)}
                className={`flex-1 h-8 rounded-lg border-2 text-xs font-bold transition-all ${
                  v <= strength ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover:border-primary/50"
                }`}>
                {v}
              </button>
            ))}
          </div>
        </div>

        {/* Color */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Color</p>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowColorPicker(v => !v)}
              className="w-9 h-9 rounded-lg border-2 border-border cursor-pointer hover:ring-2 hover:ring-primary transition-all flex-shrink-0"
              style={{ backgroundColor: color }}
            />
            <span className="text-xs text-muted-foreground font-mono">{color}</span>
          </div>
          {showColorPicker && (
            <div className="mt-2 p-3 bg-card border border-border rounded-xl shadow-lg space-y-2">
              <HexColorPicker color={color} onChange={setColor} style={{ width: "100%" }} />
              <input
                type="text"
                value={color}
                onChange={e => { if (/^#?[0-9A-F]{0,6}$/i.test(e.target.value)) setColor(e.target.value); }}
                className="w-full h-8 px-2 rounded border border-border bg-background text-xs font-mono"
              />
            </div>
          )}
        </div>

        {/* Notes */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Notes (optional)</p>
          <MentionTextarea value={notes} onChange={setNotes} alters={allAlters} signposts
            placeholder="Add context..."
            rows={2}
            className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm resize-none" />
        </div>

        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
          <Button className="flex-1" onClick={handleSave}
            disabled={!selectedAlterA || !selectedAlterB || !relType}>
            Save
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}