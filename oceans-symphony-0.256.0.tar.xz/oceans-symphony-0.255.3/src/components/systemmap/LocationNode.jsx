import React, { useRef, useState, useEffect } from "react";

const MIN_SIZE = 80;

export default function LocationNode({ location, isSelected, onSelect, onDoubleSelect, onLongPress, onUpdate, onDelete, onEdit, onInteractStart, viewOnly = false, zoom = 1 }) {
  const [dragging, setDragging] = useState(false);
  const [pressingId, setPressingId] = useState(false);
  const dragStart = useRef(null);
  const tapRef = useRef({ time: 0, timer: null });
  const longPressRef = useRef(null);

  const { x: px, y: py, width: pw = 200, height: ph = 150, color = "#6366f1", shape = "rectangle", name, background_image_url, background_opacity, is_locked, opacity = 1, rotation = 0 } = location;

  // Drag/resize are staged locally and written ONCE on release. Every
  // pointer-move used to call onUpdate → an IndexedDB write (and a full
  // re-encrypt when the vault is locked) per pixel.
  const [live, setLive] = useState(null);
  const liveRef = useRef(null);
  const stage = (fields) => { liveRef.current = { ...(liveRef.current || {}), ...fields }; setLive(liveRef.current); };
  const commitLive = () => {
    const pending = liveRef.current;
    liveRef.current = null;
    setLive(null);
    if (pending) onUpdate(pending);
  };
  const x = live?.x ?? px, y = live?.y ?? py, width = live?.width ?? pw, height = live?.height ?? ph;

  const [resolvedBgUrl, setResolvedBgUrl] = useState(background_image_url || null);
  useEffect(() => {
    if (!background_image_url) { setResolvedBgUrl(null); return; }
    // Both local forms need resolving — the /local-image/ SW path 404s on
    // iOS native (no service worker there), so never render it raw.
    if (!background_image_url.startsWith("local-image://") && !background_image_url.startsWith("/local-image/")) { setResolvedBgUrl(background_image_url); return; }
    import("@/lib/imageUrlResolver").then(({ resolveImageUrl }) => {
      resolveImageUrl(background_image_url).then(url => setResolvedBgUrl(url || background_image_url));
    });
  }, [background_image_url]);

  const fireTap = () => {
    const now = Date.now();
    if (now - tapRef.current.time < 300) {
      clearTimeout(tapRef.current.timer);
      tapRef.current.time = 0;
      onDoubleSelect?.();
    } else {
      tapRef.current.time = now;
      tapRef.current.timer = setTimeout(() => { onSelect(); }, 310);
    }
  };

  const handleMouseDown = (e) => {
    e.stopPropagation();
    // Clear the canvas pan-moved flag so a fresh tap on a location is never
    // mistaken for the tail end of a previous map pan (that stale flag is what
    // made the editor/popup fail to open after panning around).
    onInteractStart?.();
    if (viewOnly) {
      // In view mode, just allow tap/double-tap
      fireTap();
      return;
    }
    setDragging(true);
    dragStart.current = { mx: e.clientX, my: e.clientY, x, y, moved: false, startTime: Date.now() };
    setPressingId(true);

    // Start long-press timer
    longPressRef.current = setTimeout(() => {
      if (dragStart.current && !dragStart.current.moved && onLongPress) {
        onLongPress();
        if (navigator.vibrate) navigator.vibrate(50);
      }
    }, 1000);

    const onMove = (ev) => {
      if (!dragStart.current || is_locked) return;
      const dx = (ev.clientX - dragStart.current.mx) / zoom;
      const dy = (ev.clientY - dragStart.current.my) / zoom;
      if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
        dragStart.current.moved = true;
        clearTimeout(longPressRef.current);
        setPressingId(false);
      }
      stage({ x: dragStart.current.x + dx, y: dragStart.current.y + dy });
    };
    const onUp = () => {
      commitLive();
      clearTimeout(longPressRef.current);
      setPressingId(false);
      if (dragStart.current && !dragStart.current.moved) fireTap();
      setDragging(false);
      dragStart.current = null;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const handleTouchStart = (e) => {
    e.stopPropagation();
    onInteractStart?.();
    if (viewOnly) {
      // In view mode, just allow tap/double-tap
      fireTap();
      return;
    }
    setDragging(true);
    dragStart.current = { mx: e.touches[0].clientX, my: e.touches[0].clientY, x, y, moved: false, startTime: Date.now() };
    setPressingId(true);

    // Start long-press timer
    longPressRef.current = setTimeout(() => {
      if (dragStart.current && !dragStart.current.moved && onLongPress) {
        onLongPress();
        if (navigator.vibrate) navigator.vibrate(50);
      }
    }, 1000);
  };

  const handleTouchMove = (e) => {
    if (!dragStart.current || is_locked || viewOnly) return;
    e.stopPropagation();
    const dx = (e.touches[0].clientX - dragStart.current.mx) / zoom;
    const dy = (e.touches[0].clientY - dragStart.current.my) / zoom;
    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
      dragStart.current.moved = true;
      clearTimeout(longPressRef.current);
      setPressingId(false);
    }
    if (!viewOnly) {
      stage({ x: dragStart.current.x + dx, y: dragStart.current.y + dy });
    }
  };

  const handleTouchEnd = (e) => {
    if (!dragStart.current) return;
    e.stopPropagation();
    commitLive();
    clearTimeout(longPressRef.current);
    setPressingId(false);
    const elapsed = Date.now() - dragStart.current.startTime;
    if (!dragStart.current.moved && elapsed < 500) fireTap();
    setDragging(false);
    dragStart.current = null;
  };

  const handleResizeDown = (e) => {
    if (is_locked || viewOnly) {
      e.stopPropagation();
      return;
    }
    e.stopPropagation();
    const startMx = e.clientX;
    const startMy = e.clientY;
    const startW = width;
    const startH = height;

    const onMove = (ev) => {
      const dw = (ev.clientX - startMx) / zoom;
      const dh = (ev.clientY - startMy) / zoom;
      stage({ width: Math.max(MIN_SIZE, startW + dw), height: Math.max(MIN_SIZE, startH + dh) });
    };
    const onUp = () => {
      commitLive();
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const handleResizeTouchStart = (e) => {
    if (is_locked || viewOnly) {
      e.stopPropagation();
      return;
    }
    e.stopPropagation();
    const startMx = e.touches[0].clientX;
    const startMy = e.touches[0].clientY;
    const startW = width;
    const startH = height;

    const onMove = (ev) => {
      const dw = (ev.touches[0].clientX - startMx) / zoom;
      const dh = (ev.touches[0].clientY - startMy) / zoom;
      stage({ width: Math.max(MIN_SIZE, startW + dw), height: Math.max(MIN_SIZE, startH + dh) });
    };
    const onUp = () => {
      commitLive();
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("touchend", onUp);
    };
    window.addEventListener("touchmove", onMove);
    window.addEventListener("touchend", onUp);
  };

  const fill = color + "26"; // 15% opacity
  const borderColor = color;
  const isOval = shape === "oval";
  const rx = isOval ? width / 2 : 8;
  const ry = isOval ? height / 2 : 8;

  return (
    <g opacity={opacity} transform={rotation ? `rotate(${rotation} ${x + width / 2} ${y + height / 2})` : undefined}
      style={{ cursor: is_locked ? "default" : dragging ? "grabbing" : "grab", touchAction: "none" }}
      onMouseDown={(is_locked || viewOnly) ? handleMouseDown : undefined} onTouchStart={(is_locked || viewOnly) ? handleTouchStart : undefined}>
      {/* Base fill + hit target (no stroke — the border is drawn on top so the
          background image never covers it). Keep it hit-testable in view mode +
          for locked locations so taps bubble to the <g>. */}
      <rect
        x={x} y={y} width={width} height={height}
        rx={rx} ry={ry}
        fill={resolvedBgUrl ? "transparent" : fill}
        pointerEvents={is_locked && !viewOnly ? "none" : "auto"}
        onMouseDown={!is_locked && !viewOnly ? handleMouseDown : undefined}
        onTouchStart={!is_locked && !viewOnly ? handleTouchStart : undefined}
        onTouchMove={!is_locked && !viewOnly ? handleTouchMove : undefined}
        onTouchEnd={!is_locked && !viewOnly ? handleTouchEnd : undefined}
      />

      {/* Background image — HTML <img> in a foreignObject (not an SVG <image>)
          so animated GIFs actually play. pointerEvents none so taps fall
          through to the fill rect below; clipped to the box shape. */}
      {resolvedBgUrl && (
        <foreignObject x={x} y={y} width={width} height={height} style={{ pointerEvents: "none" }}>
          <div style={{ width: "100%", height: "100%", borderRadius: isOval ? "50%" : 8, overflow: "hidden" }}>
            <img src={resolvedBgUrl} alt="" draggable={false}
              style={{ width: "100%", height: "100%", objectFit: "cover", opacity: background_opacity ?? 0.7, display: "block" }} />
          </div>
        </foreignObject>
      )}

      {/* Border on top of the fill + image */}
      <rect
        x={x} y={y} width={width} height={height}
        rx={rx} ry={ry}
        fill="none"
        stroke={borderColor}
        strokeWidth={isSelected ? 2.5 : 1.5}
        strokeDasharray={isSelected ? "6,3" : "none"}
        pointerEvents="none"
      />

      {/* Name label */}
      <text
        x={x + width / 2} y={y + 18}
        textAnchor="middle"
        fontSize={12}
        fontWeight="600"
        fill={color}
        pointerEvents="none"
        style={{ userSelect: "none" }}
      >
        {name?.length > 20 ? name.slice(0, 18) + "…" : name}
      </text>

      {/* Tap the name to open the editor — a large, reliable target (fires on
          press, like the ✏️ button) so you don't have to hit the small pencil.
          Sits to the left of the ✏️ so it never overlaps it. Edit mode only. */}
      {!viewOnly && (
        <rect
          x={x} y={y} width={Math.max(10, width - 36)} height={28}
          fill="transparent"
          onMouseDown={(e) => { e.stopPropagation(); onEdit?.(); }}
          onTouchStart={(e) => { e.stopPropagation(); onEdit?.(); }}
          style={{ cursor: "pointer", pointerEvents: "auto" }}
        />
      )}

      {/* Resize handle (bottom-right) */}
      {!is_locked && !viewOnly && (
        <rect
          x={x + width - 20} y={y + height - 20}
          width={20} height={20}
          fill={borderColor}
          opacity={0.4}
          rx={2}
          style={{ cursor: "se-resize", touchAction: "none" }}
          onMouseDown={handleResizeDown}
          onTouchStart={handleResizeTouchStart}
        />
      )}

      {/* Lock indicator */}
      {is_locked && !viewOnly && (
        <text
          x={x + width - 12} y={y + 14}
          fontSize={12}
          fill={color}
          pointerEvents="none"
          style={{ userSelect: "none" }}
        >
          🔒
        </text>
      )}

      {/* Edit button */}
      {!viewOnly && (
        <>
          <rect
            x={x + width - 32} y={y + 6}
            width={24} height={24}
            rx={4}
            fill={color}
            opacity={0.15}
            onMouseDown={(e) => { e.stopPropagation(); onEdit?.(); }}
            onTouchStart={(e) => { e.stopPropagation(); onEdit?.(); }}
            style={{ cursor: "pointer", pointerEvents: "auto" }}
          />
          <text
            x={x + width - 20} y={y + 22}
            textAnchor="middle"
            fontSize={12}
            fill={color}
            pointerEvents="none"
            style={{ userSelect: "none" }}
          >
            ✏️
          </text>
        </>
      )}
    </g>
  );
}