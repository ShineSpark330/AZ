import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import AlterAvatarInline from "@/components/shared/AlterAvatar";
import { format, differenceInMinutes, startOfDay } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useTerms } from "@/lib/useTerms";
import { useFrontLevels, getSessionLevel, frontLevelLabel } from "@/lib/frontLevels";
import { recomputePrimaryFromLevels } from "@/lib/setFront";
import SearchableSelect from "@/components/shared/SearchableSelect";
import SetFrontModal from "@/components/fronting/SetFrontModal";
import { useAlterLabel } from "@/lib/useAlterLabel";
import { useFrontLook } from "@/lib/frontLook";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import DailyTallyPanel from "@/components/timeline/DailyTallyPanel";
import { parseDate, activityDate } from "@/lib/dateUtils";
import { ChevronDown, ChevronUp, BarChart3, Heart, Activity, Users, BookOpen } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { AlterSessionInfo, AlterSessionEdit } from "@/components/timeline/AlterSessionPopover";
import { SymptomBar, SymptomDetailModal } from "@/components/timeline/SymptomBar";
import { SymptomSessionPopup } from "@/components/timeline/SymptomSessionPopup";
import QuickCheckInModal from "@/components/emotions/QuickCheckInModal";
import { getCategoryMeta } from "@/lib/locationCategories";
import { effectiveSeverity, formatSeverityForSymptom } from "@/lib/trackingModel";
import { journalEntryDate } from "@/lib/journalDate";

const LABEL_WIDTH = 44;
const DEFAULT_COL_WIDTHS = { activity: 52, eventCol: 56, emotionCol: 52, symptom: 48, alter: 32, locationCol: 44 };
const EVENT_DETAIL_MIN_WIDTH = 72;
const LS_TIMELINE_ROW_H = "symphony_timeline_row_h";

function lsGet(key, fallback) {
  try { const v = localStorage.getItem(key); return v !== null ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}
function lsSet(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

const EMOTION_COLORS = [
  "#f43f5e","#ec4899","#a855f7","#3b82f6","#14b8a6",
  "#22c55e","#f59e0b","#ef4444","#8b5cf6","#06b6d4",
  "#f97316","#84cc16","#e11d48","#7c3aed","#0891b2",
];
function emotionColor(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return EMOTION_COLORS[h % EMOTION_COLORS.length];
}
function minutesInDay(date, dayStart) {
  return differenceInMinutes(date, dayStart);
}
function formatMins(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  const period = h < 12 ? "am" : "pm";
  const h12 = h % 12 || 12;
  return `${h12}:${String(m).padStart(2, "0")}${period}`;
}

function useDoubleTap(onSingleTap, onDoubleTap, ms = 280) {
  const lastRef = useRef({ time: 0 });
  return useCallback((e) => {
    const now = Date.now();
    if (now - lastRef.current.time < ms) {
      lastRef.current.time = 0;
      onDoubleTap?.(e);
    } else {
      lastRef.current.time = now;
      setTimeout(() => {
        if (lastRef.current.time !== 0 && Date.now() - lastRef.current.time >= ms - 30) {
          lastRef.current.time = 0;
          onSingleTap?.(e);
        }
      }, ms);
    }
  }, [onSingleTap, onDoubleTap, ms]);
}

function ResizeHandle({ onDrag }) {
  const dragging = useRef(false);
  const startX = useRef(0);
  const onMouseDown = (e) => { dragging.current = true; startX.current = e.clientX; e.preventDefault(); };
  const onTouchStart = (e) => { dragging.current = true; startX.current = e.touches[0].clientX; e.preventDefault(); };
  useEffect(() => {
    const move = (e) => {
      if (!dragging.current) return;
      const x = e.clientX ?? e.touches?.[0]?.clientX;
      if (x == null) return;
      onDrag(x - startX.current);
      startX.current = x;
    };
    const up = () => { dragging.current = false; };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
    window.addEventListener("touchmove", move, { passive: false });
    window.addEventListener("touchend", up);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
      window.removeEventListener("touchmove", move);
      window.removeEventListener("touchend", up);
    };
  }, [onDrag]);
  return (
    <div className="absolute top-0 bottom-0 z-20 flex items-center justify-center cursor-col-resize"
      style={{ width: 10, right: -5, userSelect: "none" }}
      onMouseDown={onMouseDown} onTouchStart={onTouchStart}>
      <div className="w-0.5 h-full bg-border/60 hover:bg-primary/60 transition-colors" />
    </div>
  );
}

function StatusNoteBadge({ note, topPx, id }) {
  const [open, setOpen] = React.useState(false);
  return (
    <>
      <div className="absolute z-10 flex items-start pointer-events-none" style={{ top: topPx, left: LABEL_WIDTH - 22, userSelect: "none" }} data-status-id={id}>
        <div className="mx-1 flex items-center gap-1" style={{ fontSize: 9 }}>
          {/* Only the icon is clickable — rest is pointer-events-none so alters behind are tappable */}
          <button
            className="flex-shrink-0 w-5 h-5 flex items-center justify-center rounded bg-muted/90 border border-border/60 hover:bg-muted transition-colors cursor-pointer pointer-events-auto"
            style={{ fontSize: 10 }}
            onClick={(e) => { e.stopPropagation(); setOpen(true); }}
          >
            💬
          </button>
          <span className="text-muted-foreground truncate pointer-events-none opacity-70 leading-tight"
            style={{ maxWidth: 60 }}>
            {note}
          </span>
        </div>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setOpen(false)}>
          <div className="bg-card border border-border rounded-xl p-4 shadow-xl max-w-xs w-full mx-4" onClick={e => e.stopPropagation()}>
            <p className="text-xs text-muted-foreground mb-2">💬 Custom Status</p>
            <p className="text-sm text-foreground whitespace-pre-wrap">{note}</p>
            <button onClick={() => setOpen(false)} className="mt-4 w-full text-xs text-muted-foreground hover:text-foreground transition-colors">
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}

// color = the session's fronting-level colour (or the alter's own), ringW =
// the level's ring width when it sets one. No gold "primary" — fronting
// levels replaced the primary/co-front split (owner, v0.244.0).
function AlterBar({ alter, color, ringW = null, topPx, heightPx, onTap, onDoubleTap, isPrimary, rowH, onLongPress, hasNote, highlight }) {
  const sz = Math.max(18, Math.min(26, rowH * 0.45));
  const tap = useDoubleTap(onTap, onDoubleTap);
  const resolvedUrl = useResolvedAvatarUrl(alter?.avatar_url);
  const [imgErrorFor, setImgError] = useState(null);
  const imgError = !!imgErrorFor && imgErrorFor === resolvedUrl;
  const lpRef = useRef(null);
  const touchFiredRef = useRef(false);
  const pressStart = useRef({ x: 0, y: 0, moved: false });
  // 3-second "you just jumped to this session" halo — fades out so it
  // doesn't permanently distract from the rest of the day. The parent
  // sets `highlight` once and we drive the visible pulse here so we
  // can decay it locally without needing the parent to clear the prop.
  const [haloOn, setHaloOn] = useState(false);
  const haloRef = useRef(null);
  useEffect(() => {
    if (!highlight) return;
    setHaloOn(true);
    if (haloRef.current) clearTimeout(haloRef.current);
    haloRef.current = setTimeout(() => setHaloOn(false), 3000);
    // Bring this bar into view if it's offscreen.
    return () => { if (haloRef.current) clearTimeout(haloRef.current); };
  }, [highlight]);

  const startPress = (e) => {
    e.stopPropagation();
    touchFiredRef.current = false;
    if (e.touches && e.touches.length > 1) return;
    const clientX = e.touches?.[0]?.clientX ?? e.clientX;
    const clientY = e.touches?.[0]?.clientY ?? e.clientY;
    pressStart.current = { x: clientX, y: clientY, moved: false };
    const barTop = e.currentTarget.getBoundingClientRect().top;
    lpRef.current = setTimeout(() => { lpRef.current = null; onLongPress?.({ clientY, barTop }); }, 500);
  };
  const movePress = (e) => {
    if (!lpRef.current) return;
    const clientX = e.touches?.[0]?.clientX ?? e.clientX;
    const clientY = e.touches?.[0]?.clientY ?? e.clientY;
    const dx = clientX - pressStart.current.x;
    const dy = clientY - pressStart.current.y;
    if (dx * dx + dy * dy > 100) {
      pressStart.current.moved = true;
      clearTimeout(lpRef.current);
      lpRef.current = null;
    }
  };
  const cancelPress = (e) => {
    e?.stopPropagation();
    if (lpRef.current) { clearTimeout(lpRef.current); lpRef.current = null; }
  };
  const handleTouchEnd = (e) => {
    cancelPress(e);
    if (pressStart.current.moved) return; // user was scrolling, not tapping
    if (lpRef.current === null && !touchFiredRef.current) return; // long press fired, skip
    touchFiredRef.current = true;
    onTap?.();
  };

  return (
    <div className="absolute flex flex-col items-center cursor-pointer"
      role="button"
      tabIndex={0}
      aria-label={`${alter?.name}${isPrimary ? " (primary)" : ""} — tap to view session details`}
      style={{ top: topPx, left: 0, right: 0, userSelect: "none" }}
      onClick={(e) => { if (touchFiredRef.current) { touchFiredRef.current = false; return; } tap(e); }}
      onKeyDown={e => e.key === "Enter" || e.key === " " ? onTap?.() : undefined}
      onMouseDown={startPress} onMouseMove={movePress} onMouseUp={cancelPress} onMouseLeave={cancelPress}
      onTouchStart={startPress} onTouchMove={movePress} onTouchEnd={handleTouchEnd} onTouchCancel={cancelPress}>
      <div className="relative flex-shrink-0">
        <div
          className={`rounded-full overflow-hidden flex items-center justify-center hover:ring-2 hover:ring-primary/60 transition-all ${haloOn ? "alter-bar-jump-halo" : ""}`}
          style={{
            width: sz, height: sz,
            backgroundColor: color,
            border: ringW != null ? `${ringW}px solid ${color}` : "2px solid var(--background)",
            boxShadow: ringW != null ? "0 0 0 1px var(--background)" : "none"
          }}
          aria-hidden="true">
          {resolvedUrl && !imgError
            ? <img src={resolvedUrl} alt={alter?.name} className="w-full h-full object-cover" onError={() => setImgError(resolvedUrl)} />
            : <span className="font-bold text-white" style={{ fontSize: Math.max(7, sz * 0.4) }}>{alter?.name?.charAt(0)?.toUpperCase() || "?"}</span>}
        </div>
        {hasNote && (
          <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-background border border-border/60 flex items-center justify-center" style={{ fontSize: 7, lineHeight: 1 }}>
            💬
          </div>
        )}
      </div>
      {heightPx > sz + 4 && (
        <div className="w-0.5 rounded-full mt-0.5" style={{
          height: Math.max(heightPx - sz - 2, 4),
          background: `linear-gradient(to bottom, ${color}, ${color}40)`,
        }} />
      )}
    </div>
  );
}

function SessionSplitPopup({ alter, session, splitMins, onClose, onSave }) {
  const terms = useTerms();
  const [adjustedMins, setAdjustedMins] = useState(splitMins);
  const splitResolvedUrl = useResolvedAvatarUrl(alter?.avatar_url);
  const [splitImgErrorFor, setSplitImgError] = useState(null);
  const splitImgError = !!splitImgErrorFor && splitImgErrorFor === splitResolvedUrl;
  // Splitting speaks fronting LEVELS now (v0.122.0): pick the level the
  // session continues at from the split point — promote/demote were just
  // the two-level special case of this.
  const levelCfg = useFrontLevels();
  const currentLevel = getSessionLevel(session?.alter_id ? session : { ...session, is_primary: session?.primary_alter_id === alter?.id }, levelCfg);
  const [newLevel, setNewLevel] = useState(null);

  const minsToTime = (mins) => {
    const h = Math.floor(Math.max(0, mins) / 60) % 24;
    const m = Math.max(0, mins) % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  };
  const timeToMins = (t) => {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-card border border-border rounded-xl p-4 shadow-xl max-w-xs w-full mx-4 space-y-3"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-2">
          {splitResolvedUrl && !splitImgError
            ? <img src={splitResolvedUrl} alt={alter?.name} className="w-7 h-7 rounded-full object-cover flex-shrink-0" onError={() => setSplitImgError(splitResolvedUrl)} />
            : <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                style={{ backgroundColor: alter?.color || "#9333ea" }}>
                {alter?.name?.charAt(0)?.toUpperCase()}
              </div>
          }
          <div className="flex-1">
            <p className="text-sm font-semibold">{alter?.name}</p>
            <p className="text-xs text-muted-foreground">Split session at:</p>
          </div>
        </div>
        <input
          type="time"
          value={minsToTime(adjustedMins)}
          onChange={e => setAdjustedMins(timeToMins(e.target.value))}
          className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm font-medium"
        />
        <div className="space-y-2">
          <div>
            <p className="text-xs text-muted-foreground mb-1">
              From {formatMins(adjustedMins)}, their {terms.fronting} level becomes:
            </p>
            <SearchableSelect
              value={newLevel || currentLevel?.id || levelCfg.levels[0]?.id}
              onChange={(v) => { if (v) setNewLevel(v); }}
              options={levelCfg.levels.map((l) => ({ id: l.id, label: frontLevelLabel(l, terms) }))}
              placeholder={`${terms.Front} level`}
              searchPlaceholder="Search levels..."
              zIndex={70}
            />
          </div>
          <button
            onClick={() => onSave("level", adjustedMins, newLevel || currentLevel?.id || levelCfg.levels[0]?.id)}
            className="w-full px-3 py-2 text-sm rounded-lg bg-primary/10 border border-primary/40 text-primary hover:bg-primary/20 transition-colors text-left">
            Split here with that level
          </button>
          <button onClick={() => onSave("end", adjustedMins)}
            className="w-full px-3 py-2 text-sm rounded-lg bg-destructive/10 border border-destructive/40 text-destructive hover:bg-destructive/20 transition-colors text-left">
            ✕ Remove from {terms.front} at {formatMins(adjustedMins)}
          </button>
        </div>
        <button onClick={onClose} className="w-full text-xs text-muted-foreground hover:text-foreground transition-colors pt-1">
          Cancel
        </button>
      </div>
    </div>
  );
}

function NewSessionPopup({ startMins, dayStart, alters, onClose, onSave }) {
  const terms = useTerms();
  const minsToTime = (mins) => {
    const h = Math.floor(Math.max(0, Math.min(1439, mins)) / 60);
    const m = Math.max(0, Math.min(1439, mins)) % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  };

  const [startTime, setStartTime] = useState(minsToTime(startMins));
  const [endTime, setEndTime] = useState("");
  const [stillFronting, setStillFronting] = useState(false);
  // WHO + LEVEL come from the standard Set Front picker (search, subsystem
  // / group tree with "add all", multi-select, a level per alter) — the
  // old single-select flat list here couldn't serve a large system.
  const levelCfg = useFrontLevels();
  const formatAlter = useAlterLabel();
  const [picked, setPicked] = useState({ ids: [], levels: {} });
  const [pickerOpen, setPickerOpen] = useState(false);
  const byId = useMemo(() => Object.fromEntries((alters || []).map((a) => [a.id, a])), [alters]);
  const levelName = (id) => {
    const l = levelCfg.levels.find((x) => x.id === id) || levelCfg.levels[0];
    return l ? frontLevelLabel(l, terms) : "";
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-card border border-border rounded-xl p-4 shadow-xl max-w-xs w-full mx-4 space-y-3"
        onClick={e => e.stopPropagation()}>
        <p className="text-sm font-semibold">New Fronting Session</p>

        <div className="flex gap-2 items-end">
          <div className="flex-1">
            <p className="text-xs text-muted-foreground mb-1">Start time</p>
            <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)}
              className="w-full h-8 px-2 rounded-md border border-input bg-background text-sm" />
          </div>
          <button
            onClick={() => { if (!stillFronting && endTime) { const t = startTime; setStartTime(endTime); setEndTime(t); } }}
            disabled={stillFronting || !endTime}
            className="flex-shrink-0 h-8 px-2 rounded-md border border-border text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors disabled:opacity-30 text-sm"
            aria-label="Swap start and end times">
            ⇄
          </button>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground mb-1">End time</p>
            <input type="time" value={stillFronting ? "" : endTime}
              onChange={e => setEndTime(e.target.value)}
              disabled={stillFronting}
              className="w-full h-8 px-2 rounded-md border border-input bg-background text-sm disabled:opacity-40" />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <input type="checkbox" id="still-fronting" checked={stillFronting}
            onChange={e => setStillFronting(e.target.checked)}
            className="w-4 h-4 accent-primary" />
          <label htmlFor="still-fronting" className="text-xs text-muted-foreground cursor-pointer select-none">
            Still {terms.fronting} (no end time)
          </label>
        </div>

        <div>
          <p className="text-xs text-muted-foreground mb-1">Who was {terms.fronting}?</p>
          {picked.ids.length > 0 && (
            <div className="space-y-1 mb-1.5 max-h-40 overflow-y-auto overscroll-contain">
              {picked.ids.map((id) => byId[id] && (
                <div key={id} className="flex items-center gap-2 px-2 py-1 rounded-md bg-muted/30 text-sm">
                  <AlterAvatarInline alter={byId[id]} size="xs" />
                  <span className="truncate flex-1">{formatAlter(byId[id])}</span>
                  {levelCfg.enabled && <span className="text-[0.6875rem] text-muted-foreground flex-shrink-0">{levelName(picked.levels[id])}</span>}
                </div>
              ))}
            </div>
          )}
          <button type="button" onClick={() => setPickerOpen(true)}
            className="w-full h-9 px-3 rounded-md border border-dashed border-border text-sm text-muted-foreground hover:text-foreground hover:bg-muted/40 flex items-center justify-center gap-1.5">
            <Users className="w-4 h-4" />
            {picked.ids.length ? `Change ${terms.alters} or levels` : `Choose ${terms.alters}`}
          </button>
        </div>

        <div className="flex gap-2">
          <button onClick={onClose}
            className="flex-1 px-3 py-2 text-sm rounded-lg border border-border text-muted-foreground hover:bg-muted/50 transition-colors">
            Cancel
          </button>
          <button disabled={!picked.ids.length}
            onClick={() => onSave({
              startTime,
              endTime: stillFronting ? null : endTime,
              selections: picked.ids.map((id) => ({ alterId: id, levelId: picked.levels[id] || levelCfg.levels[0]?.id })),
            })}
            className="flex-1 px-3 py-2 text-sm rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-40">
            Save
          </button>
        </div>
        <SetFrontModal
          open={pickerOpen}
          onClose={() => setPickerOpen(false)}
          selectionMode
          withLevels={levelCfg.enabled}
          preselectedIds={picked.ids}
          preselectedLevels={picked.levels}
          selectionTitle={`Who was ${terms.fronting}?`}
          selectionHint="Tap to add or remove."
          confirmLabel="Done"
          onConfirm={(ids, extra) => setPicked({ ids, levels: extra?.levels || {} })}
        />
      </div>
    </div>
  );
}

function RetroEntryPicker({ startMins, onFrontSession, onCheckIn, onClose }) {
  const terms = useTerms();
  const [adjustedMins, setAdjustedMins] = useState(startMins);
  const timeInputValue = `${String(Math.floor(adjustedMins / 60)).padStart(2, "0")}:${String(adjustedMins % 60).padStart(2, "0")}`;
  const h = Math.floor(adjustedMins / 60) % 12 || 12;
  const m = adjustedMins % 60;
  const period = Math.floor(adjustedMins / 60) < 12 ? "am" : "pm";
  const timeStr = `${h}:${String(m).padStart(2, "0")}${period}`;
  return (
    <div className="fixed inset-0 z-[200] flex items-end justify-center bg-black/40" onClick={onClose}>
      <div className="bg-card rounded-xl border border-border shadow-xl p-4 max-w-xs w-full mx-4 mb-24 space-y-3" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold">Add entry at</p>
          <input
            type="time"
            value={timeInputValue}
            onChange={e => {
              const [hh, mm] = e.target.value.split(":").map(Number);
              if (!isNaN(hh) && !isNaN(mm)) setAdjustedMins(hh * 60 + mm);
            }}
            className="h-7 text-sm border border-border/50 rounded-lg px-2 bg-background"
          />
        </div>
        <div className="space-y-2">
          <button onClick={() => onFrontSession(adjustedMins)} className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors text-left">
            <Users className="w-5 h-5 text-primary flex-shrink-0" />
            <div>
              <p className="text-sm font-medium">{terms.Front} Session</p>
              <p className="text-xs text-muted-foreground">Log who was {terms.fronting} at this time</p>
            </div>
          </button>
          <button onClick={() => onCheckIn(adjustedMins)} className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors text-left">
            <Heart className="w-5 h-5 text-rose-400 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium">Quick Check-In</p>
              <p className="text-xs text-muted-foreground">Log emotions, activities, symptoms, or a note</p>
            </div>
          </button>
        </div>
        <button onClick={onClose} className="w-full py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">Cancel</button>
      </div>
    </div>
  );
}

function DetailPopup({ title, icon, timeStr, onClose, children }) {
  const openedAt = useRef(Date.now());
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
      onClick={() => { if (Date.now() - openedAt.current > 350) onClose(); }}>
      <div className="bg-card border border-border rounded-xl p-4 shadow-xl max-w-xs w-full mx-4" onClick={e => e.stopPropagation()}>
        <p className="text-xs text-muted-foreground mb-2">{icon} {timeStr}</p>
        {children}
        <button onClick={onClose} className="mt-4 w-full text-xs text-muted-foreground hover:text-foreground transition-colors">
          Close
        </button>
      </div>
    </div>
  );
}

function ActivityBar({ activityName, color, mergedCount, topPx, heightPx, notes, onTap, onDoubleTap, timeStr }) {
  const sz = 26;
  const tap = useDoubleTap(onTap, onDoubleTap);
  const touchFiredRef = useRef(false);
  // Track touch start + movement so a vertical scroll over an
  // activity bar doesn't trigger the detail popover on touch release.
  // Without this guard, every scroll that ended with a finger over an
  // activity icon was opening the "1:00am sleep" / "1:00pm West
  // seattle" popovers spuriously.
  const pressStart = useRef({ x: 0, y: 0, moved: false });
  const handleTouchStart = (e) => {
    touchFiredRef.current = false;
    if (e.touches && e.touches.length > 1) return;
    const clientX = e.touches?.[0]?.clientX ?? 0;
    const clientY = e.touches?.[0]?.clientY ?? 0;
    pressStart.current = { x: clientX, y: clientY, moved: false };
  };
  const handleTouchMove = (e) => {
    const clientX = e.touches?.[0]?.clientX ?? 0;
    const clientY = e.touches?.[0]?.clientY ?? 0;
    const dx = clientX - pressStart.current.x;
    const dy = clientY - pressStart.current.y;
    // 10px slop matches the standard touch-vs-scroll threshold used
    // elsewhere in the app (AlterBar). Squared comparison avoids the
    // sqrt.
    if (dx * dx + dy * dy > 100) pressStart.current.moved = true;
  };
  const handleTouchEnd = (e) => {
    if (pressStart.current.moved) return; // scroll, not a tap
    touchFiredRef.current = true;
    onTap?.();
  };
  return (
    <div className="absolute cursor-pointer"
      role="button"
      tabIndex={0}
      aria-label={`${activityName || "Activity"} — tap to view details`}
      style={{ top: topPx, left: 0, right: 0, userSelect: "none" }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onKeyDown={e => e.key === "Enter" || e.key === " " ? onTap?.() : undefined}
      onClick={(e) => { if (touchFiredRef.current) { touchFiredRef.current = false; return; } tap(e); }}>
      {/* Duration line — absolutely positioned so its length tracks the real
          start→end span (not the variable label height). Its bottom lands
          exactly at the activity's end; the marker + label paint on top of it. */}
      {heightPx > sz + 6 && (
        <div className="absolute rounded-full" aria-hidden="true" style={{
          top: sz / 2,
          left: "50%",
          transform: "translateX(-50%)",
          width: 3,
          height: Math.max(heightPx - sz / 2, 4),
          // Mostly solid (only a faint taper) so the bottom — the activity's end
          // time — stays clearly visible rather than fading out early.
          background: `linear-gradient(to bottom, ${color}, ${color} 80%, ${color}cc)`,
        }} />
      )}
      <div className="relative flex flex-col items-center">
        <div className="rounded-full flex-shrink-0 border-2 border-background flex items-center justify-center"
          style={{ width: sz, height: sz, backgroundColor: color }} aria-hidden="true">
          <span className="text-xs font-bold text-white leading-none">
            {activityName?.charAt(0)?.toUpperCase() || "A"}
          </span>
        </div>
        <div className="text-center leading-tight mt-0.5 px-1 rounded"
          style={{ fontSize: 8, color, maxWidth: 54, wordBreak: "break-word", backgroundColor: "var(--color-bg)" }}>
          {activityName}
          {mergedCount > 1 && <span className="opacity-60"> ×{mergedCount}</span>}
        </div>
      </div>
    </div>
  );
}

const TYPE_META = {
  journal:         { icon: "📓" },
  checkin:         { icon: "✅" },
  bulletin:        { icon: "📌" },
  task:            { icon: "☑️" },
  task_done:       { icon: "✅" },
  mention:         { icon: "@" },
  symptom_checkin: { icon: "💊" },
  sleep:           { icon: "😴" },
  lineage:         { icon: "🧬" },
  diary:           { icon: "📔" },
  poll:            { icon: "🗳️" },
  reminder:        { icon: "🔔" },
  reflection:      { icon: "🪷" },
  alter_note:      { icon: "📝" },
  daily_tasks:     { icon: "🗓️" },
  daily_task:      { icon: "✅" },
};

function EmotionBubble({ entry, topPx, onTap, onDoubleTap, colWidth, tiedAlters = [] }) {
  const emotions = entry.data.emotions || [];
  const note = entry.data.note;
  const tap = useDoubleTap(onTap, onDoubleTap);
  return (
    <div className="absolute right-0 left-0 cursor-pointer z-10 px-1"
      role="button"
      tabIndex={0}
      aria-label={`Emotion check-in${emotions.length > 0 ? `: ${emotions.slice(0, 3).join(", ")}${emotions.length > 3 ? ` and ${emotions.length - 3} more` : ""}` : ""}${note ? " — has note" : ""} — tap to view`}
      style={{ top: topPx, userSelect: "none" }}
      onClick={tap}
      onKeyDown={e => e.key === "Enter" || e.key === " " ? onTap?.() : undefined}>
      <div className="relative">
        {tiedAlters.length > 0 && (
          <div className="absolute -top-1 -right-1 z-10 flex items-center -space-x-1">
            {tiedAlters.slice(0, 3).map(a => (
              <span key={a.id} className="w-2 h-2 rounded-full border border-background"
                style={{ backgroundColor: a.color || "#8b5cf6" }} title={a.alias || a.name} />
            ))}
          </div>
        )}
        {emotions.length > 0 ? (
          <div className="flex flex-col gap-px">
            {note && <span style={{ fontSize: 8 }} className="text-muted-foreground leading-none">💭</span>}
            {emotions.slice(0, 3).map((em) => (
              <div key={em} className="flex items-center gap-0.5 overflow-hidden" title={em}>
                <div className="rounded-full flex-shrink-0 border border-background"
                  style={{ width: 7, height: 7, backgroundColor: emotionColor(em) }} />
                <span className="font-medium truncate" style={{ fontSize: 9, color: emotionColor(em), maxWidth: "100%", lineHeight: "1.1" }}>
                  {em}
                </span>
              </div>
            ))}
            {emotions.length > 3 && (
              <span className="text-muted-foreground" style={{ fontSize: 8 }}>+{emotions.length - 3}</span>
            )}
          </div>
        ) : note ? (
          <div className="rounded border border-border/60 bg-card/90 flex items-center justify-center px-1"
            style={{ height: 16 }} title={note}>
            <span style={{ fontSize: 10 }}>💭</span>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function LocationBubble({ entry, topPx, colWidth, onTap }) {
  const cat = getCategoryMeta(entry.data.category);
  return (
    <div
      className="absolute right-0 left-0 cursor-pointer z-10 px-1"
      role="button"
      tabIndex={0}
      aria-label={`${entry.data.name || cat.label} — tap to view`}
      style={{ top: topPx, userSelect: "none" }}
      onClick={onTap}
      onKeyDown={e => e.key === "Enter" || e.key === " " ? onTap?.() : undefined}
    >
      <div className="flex items-center gap-0.5 overflow-hidden" title={entry.data.name || cat.label}>
        <div className="rounded-full flex-shrink-0 border border-background"
          style={{ width: 7, height: 7, backgroundColor: cat.color }} />
        <span className="font-medium truncate" style={{ fontSize: 9, color: cat.color, maxWidth: "100%", lineHeight: "1.1" }}>
          {entry.data.name || cat.label}
        </span>
      </div>
    </div>
  );
}

function EventEntry({ entry, topPx, onTap, onDoubleTap, colWidth, lane = 0, laneWidth = 24 }) {
  const tap = useDoubleTap(onTap, onDoubleTap);
  const meta = TYPE_META[entry.type] || { icon: "•" };
  const isTaskDone = entry.type === "task_done";
  // When more than one event shares a row, only show the icon (no label
  // chip) so the row stays compact horizontally. The full label is still
  // available in the detail popup.
  const showLabel = lane === 0 && colWidth >= EVENT_DETAIL_MIN_WIDTH;
  const leftPx = 1 + lane * laneWidth;

  // Special rendering for symptom check-ins: list up to 3 symptoms ranked by severity
  if (entry.type === "symptom_checkin") {
    const items = (entry.data.items || [])
      .slice()
      // Rank by effective severity: unrated counts as the scale midpoint
      // (owner-decided semantics), an explicit 0 ("none") ranks lowest.
      .sort((a, b) => (effectiveSeverity(b.checkIn, b.symptom) ?? -1) - (effectiveSeverity(a.checkIn, a.symptom) ?? -1))
      .slice(0, 3);
    return (
      <div className="absolute cursor-pointer z-10"
        role="button"
        tabIndex={0}
        aria-label={`Symptom check-in — tap to view`}
        style={{ top: topPx, left: leftPx, userSelect: "none" }}
        onClick={tap}
        onKeyDown={e => e.key === "Enter" || e.key === " " ? onTap?.() : undefined}>
        <div className="flex flex-col gap-px" style={{ maxWidth: colWidth - 8 }}>
          {items.map(({ symptom, checkIn }, i) => {
            const color = symptom?.color || "#8b5cf6";
            return (
              <div key={i} className="flex items-center gap-0.5 overflow-hidden" title={symptom?.label}>
                <div className="rounded-full flex-shrink-0 border border-background"
                  style={{ width: 7, height: 7, backgroundColor: color }} />
                <span className="font-medium truncate" style={{ fontSize: 9, color, lineHeight: "1.1", maxWidth: "100%" }}>
                  {symptom?.label || "?"}
                  {checkIn.severity != null ? <span style={{ opacity: 0.7 }}> {formatSeverityForSymptom(symptom, checkIn.severity)}</span> : null}
                </span>
              </div>
            );
          })}
          {(entry.data.items || []).length > 3 && (
            <span className="text-muted-foreground" style={{ fontSize: 8 }}>+{entry.data.items.length - 3}</span>
          )}
        </div>
      </div>
    );
  }

  const shortLabel =
    entry.type === 'checkin' ? 'Check-In' :
    entry.type === 'journal' ? (entry.label || 'Journal') :
    entry.type === 'bulletin' ? 'Bulletin' :
    (entry.label || 'Task');
  return (
    <div className="absolute cursor-pointer z-10"
      role="button"
      tabIndex={0}
      aria-label={`${shortLabel}${entry.label && entry.label !== shortLabel ? `: ${entry.label}` : ""} — tap to view`}
      style={{ top: topPx, left: leftPx, userSelect: "none" }}
      onClick={tap}
      onKeyDown={e => e.key === "Enter" || e.key === " " ? onTap?.() : undefined}>
      {showLabel ? (
        <div className="flex items-center gap-1 rounded-full border shadow-sm bg-card border-border/60 px-1.5 py-0.5 hover:scale-105 transition-transform"
          style={{ maxWidth: colWidth - 8 }} title={entry.label}>
          <span style={{ fontSize: 11 }}>{meta.icon}</span>
          <span className="text-muted-foreground truncate" style={{ fontSize: 9, maxWidth: colWidth - 32 }}>{shortLabel}</span>
        </div>
      ) : (
        <div className={`flex items-center justify-center rounded-full border shadow-sm hover:scale-110 transition-transform ${
          isTaskDone ? "bg-green-500/10 border-green-500/40" : "bg-card border-border/60"
        }`} style={{ width: 22, height: 22 }} title={entry.label}>
          <span style={{ fontSize: 12 }}>{meta.icon}</span>
        </div>
      )}
    </div>
  );
}

export default function InfiniteTimeline({
  day, sessions, activities, emotions, alters, hasData, isToday,
  journals = [], checkIns = [], bulletins = [], tasks = [],
  sleeps = [], lineageEvents = [], diaryCards = [], polls = [],
  reminderInstances = [], reflections = [], alterNotes = [], dailyProgress = null,
  dailyTaskTemplates = [],
  showActivities = true, showCheckIns = true, showEmotions = true,
  showSymptoms = true,
  symptomSessions = [], symptomCheckIns = [], symptoms = [],
  categories = [],
  locations = [], showLocations = true,
  statusNotes = [],
  importantDates = [],
  // Set when a dashboard fronter chip double-tap → "Jump to session"
  // brought the user here. The matching AlterBar pulses a 3s halo on
  // first render. If focusOpenEditor is also true, the session-edit
  // modal opens automatically.
  focusSessionId = null,
  focusOpenEditor = false,
}) {
  const queryClient = useQueryClient();

  const catMap = useMemo(() => {
    const m = {};
    categories.forEach(c => { m[c.id] = c; });
    return m;
  }, [categories]);

  // Fast lookup: alter id → alter object.
  const altersByIdMap = useMemo(
    () => Object.fromEntries((alters || []).map(a => [a.id, a])),
    [alters]
  );

  // Which alters were active at a given moment? Used to tag symptom and
  // emotion rows with the alter(s) tied to them — surfaced as a small
  // colored-dot stack on the row and a full chip list in the details popup.
  const altersAtTime = (timestamp) => {
    if (!timestamp) return [];
    const t = new Date(timestamp).getTime();
    if (Number.isNaN(t)) return [];
    const ids = new Set();
    for (const s of sessions || []) {
      const start = s.start_time ? new Date(s.start_time).getTime() : null;
      const end   = s.end_time   ? new Date(s.end_time).getTime()   : Date.now();
      if (start == null || Number.isNaN(start)) continue;
      if (t < start || t > end) continue;
      const aid = s.alter_id || s.primary_alter_id;
      if (aid) ids.add(aid);
      if (Array.isArray(s.co_fronter_ids)) s.co_fronter_ids.forEach(id => ids.add(id));
    }
    return [...ids].map(id => altersByIdMap[id]).filter(Boolean);
  };

  const [collapsed, setCollapsed] = useState(!hasData);
  // Days mount before their queries land on a cold cache (30 s staleTime,
  // no prefetch) and used to stay folded forever. Un-fold once, the first
  // time data appears; a fold the user made after that is respected.
  const hadDataRef = useRef(hasData);
  useEffect(() => {
    if (hasData && !hadDataRef.current) { hadDataRef.current = true; setCollapsed(false); }
  }, [hasData]);
  const [detailPopup, setDetailPopup] = useState(null); // { type, entry }
  const [colWidths, setColWidths] = useState({ ...DEFAULT_COL_WIDTHS });
  const [showTally, setShowTally] = useState(false);
  const [sessionPopover, setSessionPopover] = useState(null);
  const [editingSession, setEditingSession] = useState(null);

  // Auto-open the session editor when the parent passed
  // `?focusSessionId=…&edit=1`. Only fires once per focusSessionId so
  // a manual close doesn't re-pop the modal.
  const lastAutoOpenedRef = useRef(null);
  useEffect(() => {
    if (!focusSessionId || !focusOpenEditor) return;
    if (lastAutoOpenedRef.current === focusSessionId) return;
    const s = (sessions || []).find((x) => x.id === focusSessionId);
    if (!s) return;
    const alter = (alters || []).find((a) => a.id === s.alter_id) || null;
    lastAutoOpenedRef.current = focusSessionId;
    setEditingSession({ session: s, alter });
  }, [focusSessionId, focusOpenEditor, sessions, alters]);
  const levelCfgTimeline = useFrontLevels();
  const frontLook = useFrontLook();
  const [splitPopover, setSplitPopover] = useState(null); // { alter, session, splitMins }
  const [newSessionPopover, setNewSessionPopover] = useState(null);
  const [retroPickerState, setRetroPickerState] = useState(null); // { startMins } — type picker
  const [retroCheckIn, setRetroCheckIn] = useState(null); // { startMins } — QuickCheckInModal
  const [symptomSessionPopover, setSymptomSessionPopover] = useState(null); // { session, symptom, splitMins }
  const [symptomDetailModal, setSymptomDetailModal] = useState(null); // { session, symptom }
  const longPressTargetRef = useRef(null);

  const [rowH, setRowH] = useState(() => lsGet(LS_TIMELINE_ROW_H, 30));
  useEffect(() => { lsSet(LS_TIMELINE_ROW_H, rowH); }, [rowH]);

  const [nowMins, setNowMins] = useState(() => {
    const n = new Date();
    return n.getHours() * 60 + n.getMinutes();
  });
  useEffect(() => {
    if (!isToday) return;
    const interval = setInterval(() => {
      const n = new Date();
      setNowMins(n.getHours() * 60 + n.getMinutes());
    }, 60000);
    return () => clearInterval(interval);
  }, [isToday]);

  const navigate = useNavigate();
  const dayStart = useMemo(() => startOfDay(day), [day]);
  const HOURS = Array.from({ length: 24 }, (_, i) => i);

  const dragCol = useCallback((col, delta) => {
    setColWidths((prev) => ({ ...prev, [col]: Math.max(30, prev[col] + delta) }));
  }, []);

  const eventColWidth = colWidths.eventCol;
  const emotionColWidth = colWidths.emotionCol;

  const alterEntries = useMemo(() => {
    const byAlter = {};
    sessions.forEach((session) => {
      // Support both new (alter_id) and legacy (primary_alter_id) models
      let ids = [];
      if (session.alter_id) {
        ids = [session.alter_id];
      } else {
        ids = [session.primary_alter_id, ...(session.co_fronter_ids || [])].filter(Boolean);
      }
      ids.forEach((alterId) => {
        const startMins = Math.max(0, minutesInDay(parseDate(session.start_time), dayStart));
        // end_time fallback hierarchy:
        //  - explicit end_time wins
        //  - inactive session with no end_time → broken record (treat as
        //    zero-length so it doesn't draw a full-day bar)
        //  - active session on today → "now"
        //  - active session on a past day → end of that day
        const endTime = session.end_time
          ? parseDate(session.end_time)
          : !session.is_active
            ? parseDate(session.start_time)
            : isToday
              ? new Date()
              : new Date(dayStart.getTime() + 24 * 60 * 60000 - 1);
        const endMins = Math.min(24 * 60, minutesInDay(endTime, dayStart));
        if (!byAlter[alterId]) byAlter[alterId] = [];
        const isPrimary = session.alter_id
          ? (session.is_primary ?? false)
          : session.primary_alter_id === alterId;
        byAlter[alterId].push({
          startMins,
          endMins: Math.max(endMins, startMins + 8),
          sessionId: session.id,
          isPrimary,
        });
      });
    });

    const result = [];
    Object.entries(byAlter).forEach(([alterId, segs]) => {
      const sorted = [...segs].sort((a, b) => a.startMins - b.startMins);

      // Resolve overlaps
      const resolved = [];
      sorted.forEach((seg) => {
        if (resolved.length === 0) { resolved.push({ ...seg }); return; }
        const last = resolved[resolved.length - 1];
        if (seg.startMins < last.endMins) {
          if (seg.isPrimary && !last.isPrimary) {
            last.endMins = seg.startMins;
            resolved.push({ ...seg });
          } else if (!seg.isPrimary && last.isPrimary) {
            if (seg.endMins > last.endMins) resolved.push({ ...seg, startMins: last.endMins });
          } else {
            last.endMins = Math.max(last.endMins, seg.endMins);
          }
        } else {
          resolved.push({ ...seg });
        }
      });

      // Merge consecutive same-status segments
      const merged = [];
      resolved.forEach((seg) => {
        if (merged.length === 0) { merged.push({ ...seg }); return; }
        const last = merged[merged.length - 1];
        if (seg.startMins <= last.endMins + 1 && seg.isPrimary === last.isPrimary) {
          last.endMins = Math.max(last.endMins, seg.endMins);
          last.sessionId = seg.sessionId;
        } else {
          merged.push({ ...seg });
        }
      });

      merged.forEach((seg, i) => result.push({
        alterId,
        startMins: seg.startMins,
        endMins: seg.endMins,
        sessionId: seg.sessionId,
        isPrimary: seg.isPrimary,
        key: `alter-${alterId}-${seg.sessionId}-${i}`,
      }));
    });
    return result;
  }, [sessions, dayStart, isToday]);

  const statusNoteEntries = useMemo(() => {
    // New: proper timestamped StatusNote records (one entry per save, never overwritten)
    const fromRecords = statusNotes.map(n => ({
      id: n.id,
      note: n.note,
      startMins: Math.max(0, minutesInDay(activityDate(n), dayStart)),
    }));

    // Legacy: localStorage notes for old sessions that predate the new system
    const fromLS = [];
    const seen = new Set();
    for (const session of sessions) {
      const isPrimary = session.alter_id ? (session.is_primary ?? false) : true;
      if (!isPrimary || seen.has(session.id)) continue;
      seen.add(session.id);
      const note = localStorage.getItem(`symphony_status_${session.id}`) || "";
      if (!note) continue;
      const startMins = Math.max(0, minutesInDay(parseDate(session.start_time), dayStart));
      fromLS.push({ id: `ls-${session.id}`, note, startMins });
    }

    return [...fromRecords, ...fromLS].sort((a, b) => a.startMins - b.startMins);
  }, [statusNotes, sessions, dayStart]);

  const alterColumns = useMemo(() => {
    const cols = [];
    const alterIds = [...new Set(alterEntries.map(e => e.alterId))];
    alterIds.sort((a, b) => a.localeCompare(b));
    alterIds.forEach((alterId) => {
      const segs = alterEntries.filter(e => e.alterId === alterId);
      let placed = false;
      for (let colIdx = 0; colIdx < cols.length; colIdx++) {
        const col = cols[colIdx];
        const conflicts = segs.some(seg =>
          col.some(existing =>
            existing.alterId !== alterId &&
            seg.startMins < existing.endMins &&
            seg.endMins > existing.startMins
          )
        );
        if (!conflicts) {
          segs.forEach(seg => col.push(seg));
          placed = true;
          break;
        }
      }
      if (!placed) cols.push([...segs]);
    });
    return cols;
  }, [alterEntries]);

  const activityEntries = useMemo(() => {
    const raw = [];
    const dayStartMs = dayStart.getTime();
    const dayEndMs = dayStartMs + 24 * 60 * 60 * 1000;

    activities.forEach((act) => {
      const actStart = activityDate(act);
      const actStartMs = actStart.getTime();
      // Fall back to actual_duration_minutes for resolved plans that never got a
      // planned duration, so they still draw a bar for the time they ran.
      const duration = Math.max(act.duration_minutes || act.actual_duration_minutes || 0, 0);
      const actEndMs = duration > 0 ? actStartMs + duration * 60 * 1000 : actStartMs + 30 * 60 * 1000;

      // Skip if activity doesn't intersect this day at all
      if (actEndMs <= dayStartMs || actStartMs >= dayEndMs) return;

      // Clamp to this day's window
      const startMins = Math.max(0, Math.round((actStartMs - dayStartMs) / 60000));
      const endMins = Math.min(24 * 60, Math.round((actEndMs - dayStartMs) / 60000));

      const categoryIds = act.activity_category_ids && act.activity_category_ids.length > 0
        ? [...new Set(act.activity_category_ids)] : [null];
      categoryIds.forEach((catId) => {
        const cat = catId ? catMap[catId] : null;
        raw.push({
          startMins,
          endMins: Math.max(endMins, startMins + 5),
          activity: act,
          categoryId: catId,
          displayName: cat?.name || act.activity_name,
          categoryColor: cat?.color || act.color,
        });
      });
    });
    raw.sort((a, b) => a.startMins - b.startMins);
    // Collapse ONLY a tight cluster logged at essentially the same instant (a
    // batch of quick-tasks) into a single "×N" bar. Previously ANY overlap of
    // the same category merged — which silently hid a distinct activity (e.g. a
    // completed plan) that happened to fall inside a longer overlapping session.
    // Genuinely-overlapping distinct activities must stay separate so
    // activityColumns can lay them out side-by-side.
    const SAME_INSTANT_MERGE_MINS = 3;
    const merged = [];
    raw.forEach((entry) => {
      const last = merged[merged.length - 1];
      const sameInstant = last && Math.abs(entry.startMins - last.startMins) <= SAME_INSTANT_MERGE_MINS;
      if (last && last.categoryId === entry.categoryId && sameInstant) {
        last.endMins = Math.max(last.endMins, entry.endMins);
        last.mergedCount += 1;
      } else {
        merged.push({ ...entry, mergedCount: 1 });
      }
    });
    return merged.map((m, i) => ({ ...m, key: `act-${m.activity.id}-cat-${m.categoryId || i}` }));
  }, [activities, dayStart, catMap]);

  const activityColumns = useMemo(() => {
    const cols = [];
    [...activityEntries].sort((a, b) => a.startMins - b.startMins).forEach((entry) => {
      let placed = false;
      for (const col of cols) {
        if (col[col.length - 1].endMins <= entry.startMins + 2) { col.push(entry); placed = true; break; }
      }
      if (!placed) cols.push([entry]);
    });
    return cols;
  }, [activityEntries]);

  const symptomMap = useMemo(() => {
    const m = {};
    symptoms.forEach(s => { m[s.id] = s; });
    return m;
  }, [symptoms]);

  const emotionEntries = useMemo(() => {
    return emotions
      .map((e, i) => {
        const mins = minutesInDay(activityDate(e), dayStart);
        return { mins, type: "emotion", id: e.id, data: e, key: `em-${i}-${e.id}` };
      })
      .filter(e => e.mins >= 0 && e.mins < 24 * 60)
      .sort((a, b) => a.mins - b.mins);
  }, [emotions, dayStart]);

  const locationEntries = useMemo(() => {
    if (!showLocations) return [];
    return locations
      .map((loc, i) => {
        const mins = minutesInDay(activityDate(loc), dayStart);
        return { mins, type: "location", id: loc.id, data: loc, key: `loc-${i}-${loc.id}` };
      })
      .filter(e => e.mins >= 0 && e.mins < 24 * 60)
      .sort((a, b) => a.mins - b.mins);
  }, [locations, showLocations, dayStart]);

  const eventEntries = useMemo(() => {
    const inDay = (mins) => mins >= 0 && mins < 24 * 60;
    const entries = [];

    journals.forEach((j) => {
      const mins = minutesInDay(parseDate(journalEntryDate(j)), dayStart);
      if (inDay(mins)) entries.push({ mins, type: "journal", id: j.id, label: j.title || "Journal Entry", data: j });
    });
    checkIns.forEach((c) => {
      const mins = minutesInDay(parseDate(c.created_date), dayStart);
      if (inDay(mins)) entries.push({ mins, type: "checkin", id: c.id, label: "System Meeting", data: c });
    });
    bulletins.forEach((b) => {
      // Task-bulletins (`[task:ID] title`) get surfaced via the task entry
      // below — skip the duplicate bulletin entry so a single quick-task
      // doesn't show up twice on the timeline (📌 + ✓).
      if (typeof b.content === "string" && b.content.startsWith("[task:")) return;
      const mins = minutesInDay(parseDate(b.created_date), dayStart);
      if (inDay(mins)) entries.push({ mins, type: "bulletin", id: b.id, label: b.content?.slice(0, 40) || "Bulletin", data: b });
    });
    tasks.forEach((t) => {
      const createdMins = minutesInDay(parseDate(t.created_date), dayStart);
      if (inDay(createdMins)) {
        entries.push({ mins: createdMins, type: "task", id: t.id, label: t.title || "Task", data: t });
      }
      if (t.completed && t.completed_date) {
        const completedMins = minutesInDay(parseDate(t.completed_date), dayStart);
        if (inDay(completedMins)) {
          entries.push({ mins: completedMins, type: "task_done", id: `done-${t.id}`, label: `✓ ${t.title || "Task"}`, data: t });
        }
      }
    });

    // Sleep — positioned at bedtime; label shows the slept duration if ended.
    sleeps.forEach((s) => {
      const when = s.bedtime || (s.date ? `${s.date}T12:00:00` : null);
      if (!when) return;
      const mins = minutesInDay(parseDate(when), dayStart);
      if (!inDay(mins)) return;
      let label = "Sleep";
      if (s.bedtime && s.wake_time) {
        const dur = Math.max(0, Math.round((parseDate(s.wake_time) - parseDate(s.bedtime)) / 60000));
        label = `Slept ${Math.floor(dur / 60)}h ${dur % 60}m`;
      }
      entries.push({ mins, type: "sleep", id: s.id, label, data: s });
    });

    // System change / lineage events (fusion, split, dormancy, …).
    lineageEvents.forEach((ev) => {
      if (!ev.date) return;
      const mins = minutesInDay(parseDate(ev.date), dayStart);
      if (!inDay(mins)) return;
      const label = ev.type ? ev.type.charAt(0).toUpperCase() + ev.type.slice(1) : "System change";
      entries.push({ mins, type: "lineage", id: ev.id, label, data: ev });
    });

    // Diary cards — `date` is a day string, so fall back to noon when there's
    // no created_date time-of-day.
    diaryCards.forEach((d) => {
      const when = d.created_date || (d.date ? `${d.date}T12:00:00` : null);
      if (!when) return;
      const mins = minutesInDay(parseDate(when), dayStart);
      if (!inDay(mins)) return;
      entries.push({ mins, type: "diary", id: d.id, label: d.name || "Diary card", data: d });
    });

    // Polls (creation).
    polls.forEach((p) => {
      if (!p.created_date) return;
      const mins = minutesInDay(parseDate(p.created_date), dayStart);
      if (!inDay(mins)) return;
      entries.push({ mins, type: "poll", id: p.id, label: p.question || "Poll", data: p });
    });

    // Reminders that fired — positioned at when they actually fired/were due.
    reminderInstances.forEach((ri) => {
      const when = ri.fired_at || ri.scheduled_for;
      if (!when) return;
      const mins = minutesInDay(parseDate(when), dayStart);
      if (!inDay(mins)) return;
      entries.push({ mins, type: "reminder", id: ri.id, label: ri.title || ri.body || "Reminder", data: ri });
    });

    // Support / Learn reflections.
    reflections.forEach((r) => {
      if (!r.created_date) return;
      const mins = minutesInDay(parseDate(r.created_date), dayStart);
      if (!inDay(mins)) return;
      entries.push({ mins, type: "reflection", id: r.id, label: r.exercise_title || "Reflection", data: r });
    });

    // Per-alter notes.
    alterNotes.forEach((n) => {
      if (!n.created_date) return;
      const mins = minutesInDay(parseDate(n.created_date), dayStart);
      if (!inDay(mins)) return;
      const txt = (n.content || "").replace(/<[^>]+>/g, "").trim().slice(0, 40);
      entries.push({ mins, type: "alter_note", id: n.id, label: txt || "Note", data: n });
    });

    // Daily-task completions. Each task that has a checkoff time renders at that
    // time as its own event; tasks without one (AUTO triggers, or records from
    // before per-task times were captured) collapse into a single marker
    // anchored at the record's created_date.
    if (dailyProgress && Array.isArray(dailyProgress.completed_task_ids) && dailyProgress.completed_task_ids.length) {
      const times = dailyProgress.completion_times || {};
      const dtTitleById = {};
      for (const tpl of dailyTaskTemplates) { if (tpl?.id) dtTitleById[tpl.id] = tpl.title || "Task"; }
      const untimed = [];
      for (const taskId of dailyProgress.completed_task_ids) {
        const when = times[taskId];
        if (when) {
          const mins = minutesInDay(parseDate(when), dayStart);
          if (inDay(mins)) {
            entries.push({ mins, type: "daily_task", id: `dt-${dailyProgress.id}-${taskId}`, label: dtTitleById[taskId] || "Daily task", data: { title: dtTitleById[taskId] || "Daily task" } });
          }
        } else {
          untimed.push(taskId);
        }
      }
      if (untimed.length && dailyProgress.created_date) {
        const mins = minutesInDay(parseDate(dailyProgress.created_date), dayStart);
        if (inDay(mins)) {
          entries.push({ mins, type: "daily_tasks", id: `dp-${dailyProgress.id}`, label: `${untimed.length} daily task${untimed.length !== 1 ? "s" : ""} done`, data: { ...dailyProgress, completed_task_ids: untimed } });
        }
      }
    }

    // Group symptom check-ins by minute into single event entries
    const scByMinute = {};
    symptomCheckIns.forEach(sc => {
      const mins = minutesInDay(activityDate(sc), dayStart);
      if (!inDay(mins)) return;
      const bucket = Math.floor(mins);
      if (!scByMinute[bucket]) scByMinute[bucket] = { mins: bucket, items: [], id: sc.id };
      scByMinute[bucket].items.push({ symptom: symptomMap[sc.symptom_id], checkIn: sc });
    });
    Object.values(scByMinute).forEach(group => {
      entries.push({ mins: group.mins, type: "symptom_checkin", id: `sc-${group.id}`, label: "Symptom Check-In", data: group });
    });

    return entries.sort((a, b) => a.mins - b.mins).map((e, i) => ({ ...e, key: `ev-${i}-${e.id}` }));
  }, [journals, checkIns, bulletins, tasks, sleeps, lineageEvents, diaryCards, polls, reminderInstances, reflections, alterNotes, dailyProgress, symptomCheckIns, symptomMap, dayStart]);

  const getTopPx = useCallback((mins) => {
    return (mins / 60) * rowH;
  }, [rowH]);

  const getRangePx = useCallback((startMins, endMins) => {
    return getTopPx(endMins) - getTopPx(startMins);
  }, [getTopPx]);

  const totalHeight = 24 * rowH;

  const MIN_EMOTION_GAP = 22;
  const MIN_EVENT_GAP = 26;

  const emotionPositioned = useMemo(() => {
    let minNext = -Infinity;
    return emotionEntries.map((entry) => {
      const raw = getTopPx(entry.mins);
      const top = Math.max(raw, minNext);
      minNext = top + MIN_EMOTION_GAP;
      return { ...entry, adjustedTop: top };
    });
  }, [emotionEntries, getTopPx]);

  const locationPositioned = useMemo(() => {
    let minNext = -Infinity;
    return locationEntries.map((entry) => {
      const raw = getTopPx(entry.mins);
      const top = Math.max(raw, minNext);
      minNext = top + MIN_EMOTION_GAP;
      return { ...entry, adjustedTop: top };
    });
  }, [locationEntries, getTopPx]);

  // Pack events into rows. Multiple events that fall at the same minute (or
  // close enough that they'd otherwise overlap vertically) get assigned to
  // separate horizontal "lanes" within the events column. We only push a
  // new row down once every lane in the current row is occupied — so a
  // batch of quick-tasks logged within seconds shows up as a single row
  // of small icons rather than a tall vertical stack.
  const eventPositioned = useMemo(() => {
    const LANE_WIDTH = 24;
    const maxLanes = Math.max(1, Math.floor(eventColWidth / LANE_WIDTH));
    const rows = []; // { top, count }
    const out = [];
    for (const entry of eventEntries) {
      const raw = getTopPx(entry.mins);
      // Try to land in an existing row whose top is within MIN_EVENT_GAP
      // of where this entry wants to be AND that still has a free lane.
      let row = rows.find(r => raw < r.top + MIN_EVENT_GAP && r.count < maxLanes);
      if (!row) {
        const lastTop = rows.length > 0 ? rows[rows.length - 1].top : -Infinity;
        row = { top: Math.max(raw, lastTop + MIN_EVENT_GAP), count: 0 };
        rows.push(row);
      }
      const lane = row.count;
      row.count += 1;
      out.push({ ...entry, adjustedTop: row.top, lane, laneWidth: LANE_WIDTH });
    }
    return out;
  }, [eventEntries, getTopPx, eventColWidth]);

  const sortedSymptomSessions = useMemo(() => {
    return [...symptomSessions].sort((a, b) => {
      if (a.is_active && !b.is_active) return -1;
      if (!a.is_active && b.is_active) return 1;
      return new Date(b.start_time) - new Date(a.start_time);
    });
  }, [symptomSessions]);

  const symptomColumns = useMemo(() => {
    const cols = [];
    const symptomIds = [...new Set(sortedSymptomSessions.map(s => s.symptom_id))];
    symptomIds.forEach(symptomId => {
      const segs = sortedSymptomSessions
        .filter(s => s.symptom_id === symptomId)
        .map(s => {
          const startMins = Math.max(0, minutesInDay(parseDate(s.start_time), dayStart));
          const endTime = s.end_time
            ? parseDate(s.end_time)
            : !s.is_active
              ? parseDate(s.start_time)
              : isToday
                ? new Date()
                : new Date(dayStart.getTime() + 24 * 60 * 60000 - 1);
          const endMins = Math.min(24 * 60, minutesInDay(endTime, dayStart));
          return { symptomId, startMins, endMins: Math.max(endMins, startMins + 8), sessionId: s.id };
        });
      let placed = false;
      for (const col of cols) {
        const conflicts = segs.some(seg =>
          col.some(existing => seg.startMins < existing.endMins && seg.endMins > existing.startMins)
        );
        if (!conflicts) { segs.forEach(seg => col.push(seg)); placed = true; break; }
      }
      if (!placed) cols.push([...segs]);
    });
    return cols;
  }, [sortedSymptomSessions, dayStart, isToday]);

  const numAlterCols = Math.max(1, alterColumns.length);
  const alterAreaWidth = numAlterCols * colWidths.alter;

  // Collapse empty columns to zero width
  const numActivityCols = showActivities && activityEntries.length > 0 ? Math.max(1, activityColumns.length) : 0;
  const activityAreaWidth = numActivityCols * colWidths.activity;

  const numSymptomCols = showSymptoms && symptomSessions.length > 0 ? Math.max(1, symptomColumns.length) : 0;
  const symptomAreaWidth = numSymptomCols * colWidths.symptom;

  const eventColWidth_actual = showCheckIns && eventEntries.length > 0 ? eventColWidth : 0;
  const emotionColWidth_actual = showEmotions && emotionEntries.length > 0 ? emotionColWidth : 0;
  const locationColWidth_actual = showLocations && locationEntries.length > 0 ? colWidths.locationCol : 0;

  // Column order: [time label | alters | symptoms | events | emotions | locations | activities]
  const alterLeft = LABEL_WIDTH;
  const symptomLeft = alterLeft + alterAreaWidth;
  const eventColLeft = symptomLeft + symptomAreaWidth;
  const emotionColLeft = eventColLeft + eventColWidth_actual;
  const locationColLeft = emotionColLeft + emotionColWidth_actual;
  const activityLeft = locationColLeft + locationColWidth_actual;
  const totalWidth = activityLeft + activityAreaWidth;
  const dateLabel = isToday ? "Today"
    : day.getFullYear() !== new Date().getFullYear()
      ? format(day, "EEEE, MMM d, yyyy")
      : format(day, "EEEE, MMM d");

  const handleSplitSave = async (action, splitMins, levelId = null) => {
    if (!splitPopover) return;
    const { alter, session } = splitPopover;
    const splitTime = new Date(dayStart.getTime() + splitMins * 60 * 1000).toISOString();
    const isNewModel = !!session.alter_id;
    // Levels are the split vocabulary now; "promote"/"demote" survive only
    // for the legacy group-row model below (mapped from the level index).
    const levelIdx = levelId ? Math.max(0, levelCfgTimeline.levels.findIndex((l) => l.id === levelId)) : 0;

    try {
      if (isNewModel) {
        // New individual model — each record is one alter
        if (action === "end") {
          // Simply end this alter's session at split time
          await base44.entities.FrontingSession.update(session.id, {
            end_time: splitTime,
            is_active: false,
          });
        } else if (action === "level") {
          // End the current segment; the continuation carries the picked
          // level. is_primary follows the level (top level = the lead) and
          // — for still-active sessions — the shared recompute settles ties
          // exactly like every other write path.
          await base44.entities.FrontingSession.update(session.id, { end_time: splitTime, is_active: false });
          await base44.entities.FrontingSession.create({
            alter_id: alter.id,
            is_primary: levelIdx === 0,
            front_level: levelId,
            start_time: splitTime,
            end_time: session.end_time || null,
            is_active: !session.end_time,
          });
          // Active new sessions settle the lead through the shared recompute.
          if (!session.end_time) {
            await recomputePrimaryFromLevels({ cfg: levelCfgTimeline, queryClient: null });
          }
        }
      } else {
        // Legacy model fallback — a picked level maps onto the old binary:
        // top level = promote, anything else = demote.
        if (action === "level") action = levelIdx === 0 ? "promote" : "demote";
        if (action === "end") {
          await base44.entities.FrontingSession.update(session.id, { end_time: splitTime, is_active: false });
          const others = [session.primary_alter_id, ...(session.co_fronter_ids || [])].filter(id => id && id !== alter.id);
          if (others.length > 0) {
            await base44.entities.FrontingSession.create({
              primary_alter_id: others[0],
              co_fronter_ids: others.slice(1),
              start_time: splitTime,
              end_time: session.end_time || null,
              is_active: !session.end_time,
            });
          }
        } else {
          await base44.entities.FrontingSession.update(session.id, { end_time: splitTime, is_active: false });
          const newSession = {
            primary_alter_id: session.primary_alter_id,
            co_fronter_ids: session.co_fronter_ids || [],
            start_time: splitTime,
            end_time: session.end_time || null,
            is_active: !session.end_time,
          };
          if (action === "promote") {
            newSession.primary_alter_id = alter.id;
            newSession.co_fronter_ids = [session.primary_alter_id, ...(session.co_fronter_ids || [])].filter(id => id && id !== alter.id);
          } else if (action === "demote") {
            const others = [session.primary_alter_id, ...(session.co_fronter_ids || [])].filter(id => id && id !== alter.id);
            newSession.primary_alter_id = others[0] || null;
            newSession.co_fronter_ids = [...others.slice(1), alter.id];
          }
          await base44.entities.FrontingSession.create(newSession);
        }
      }

      queryClient.invalidateQueries({ queryKey: ["frontHistory"], refetchType: 'all' });
      queryClient.invalidateQueries({ queryKey: ["activeFront"], refetchType: 'all' });
    } catch (err) {
      console.error("Split session failed", err);
    }
    setSplitPopover(null);
  };

  // One session per chosen alter, each at its own level (the retroactive
  // picker is multi-select now).
  const handleNewSessionSave = async ({ startTime, endTime, selections = [] }) => {
    try {
      const startDate = new Date(dayStart);
      const [sh, sm] = startTime.split(":").map(Number);
      startDate.setHours(sh, sm, 0, 0);
      let endDate = null;
      if (endTime) {
        endDate = new Date(dayStart);
        const [eh, em] = endTime.split(":").map(Number);
        endDate.setHours(eh, em, 0, 0);
      }
      // The top occupied level leads (same rule as every other write path):
      // only alters at the highest picked level are marked primary.
      const idxOf = (levelId) => (levelId ? Math.max(0, levelCfgTimeline.levels.findIndex((l) => l.id === levelId)) : 0);
      const topIdx = Math.min(...selections.map((x) => idxOf(x.levelId)));
      await base44.entities.FrontingSession.bulkCreate(selections.map(({ alterId, levelId }) => ({
        alter_id: alterId,
        front_level: levelId,
        is_primary: idxOf(levelId) === topIdx && topIdx === 0,
        start_time: startDate.toISOString(),
        end_time: endDate?.toISOString() || null,
        is_active: !endDate,
      })));
      queryClient.invalidateQueries({ queryKey: ["frontHistory"], refetchType: 'all' });
      queryClient.invalidateQueries({ queryKey: ["activeFront"], refetchType: 'all' });
    } catch (err) {
      console.error("Create session failed", err);
      toast.error(err?.message || "Couldn't save that session");
    }
    setNewSessionPopover(null);
  };

  const longPressStartPos = useRef({ x: 0, y: 0 });
  const startAreaLongPress = (e) => {
    // Don't arm long-press for multi-touch (pinch gestures, etc.)
    if (e.touches && e.touches.length > 1) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clientX = e.touches?.[0]?.clientX ?? e.clientX;
    const clientY = e.touches?.[0]?.clientY ?? e.clientY;
    longPressStartPos.current = { x: clientX, y: clientY };
    // rect.top is already viewport-relative — accounts for whatever
    // scroll position the parent page is in — so `clientY - rect.top`
    // is the tap's position within the day grid. The previous code
    // added a separate `scrollTop` from the now-removed inner
    // `.overflow-y-auto` ancestor; that double-counted scroll
    // whenever the user wasn't at the top of the inner scroller.
    const y = clientY - rect.top;
    const mins = Math.round((y / totalHeight) * 24 * 60 / 15) * 15;
    longPressTargetRef.current = setTimeout(() => {
      longPressTargetRef.current = null;
      setRetroPickerState({ startMins: Math.min(Math.max(0, mins), 1439) });
    }, 500);
  };
  const moveAreaLongPress = (e) => {
    if (!longPressTargetRef.current) return;
    const clientX = e.touches?.[0]?.clientX ?? e.clientX;
    const clientY = e.touches?.[0]?.clientY ?? e.clientY;
    const dx = clientX - longPressStartPos.current.x;
    const dy = clientY - longPressStartPos.current.y;
    if (dx * dx + dy * dy > 100) {
      clearTimeout(longPressTargetRef.current);
      longPressTargetRef.current = null;
    }
  };
  const cancelAreaLongPress = () => {
    if (longPressTargetRef.current) { clearTimeout(longPressTargetRef.current); longPressTargetRef.current = null; }
  };

  // Pinch-to-zoom: two-finger pinch on the timeline scrolling area changes rowH.
  // Native listener with { passive: false } so we can preventDefault to stop the
  // browser from page-zooming or scrolling during the gesture.
  const timelineAreaRef = useRef(null);
  const rowHRef = useRef(rowH);
  useEffect(() => { rowHRef.current = rowH; }, [rowH]);
  useEffect(() => {
    const el = timelineAreaRef.current;
    if (!el) return;
    let pinch = null;
    const onTouchStart = (e) => {
      if (e.touches.length === 2) {
        const [a, b] = e.touches;
        pinch = {
          startDist: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY),
          startRowH: rowHRef.current,
        };
        cancelAreaLongPress();
      }
    };
    const onTouchMove = (e) => {
      if (e.touches.length === 2 && pinch) {
        const [a, b] = e.touches;
        const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
        const ratio = dist / pinch.startDist;
        const next = Math.round(Math.max(20, Math.min(200, pinch.startRowH * ratio)));
        if (next !== rowHRef.current) setRowH(next);
        e.preventDefault();
      }
    };
    const onTouchEnd = (e) => { if (e.touches.length < 2) pinch = null; };
    el.addEventListener("touchstart", onTouchStart, { passive: true });
    el.addEventListener("touchmove", onTouchMove, { passive: false });
    el.addEventListener("touchend", onTouchEnd);
    el.addEventListener("touchcancel", onTouchEnd);
    return () => {
      el.removeEventListener("touchstart", onTouchStart);
      el.removeEventListener("touchmove", onTouchMove);
      el.removeEventListener("touchend", onTouchEnd);
      el.removeEventListener("touchcancel", onTouchEnd);
    };
  }, []);

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-muted/30 transition-colors"
        style={{ userSelect: "none" }}
      >
        <div className="flex items-center gap-3 flex-wrap">
          <span className={`font-semibold text-sm ${isToday ? "text-primary" : "text-foreground"}`}>{dateLabel}</span>
          {!hasData && <span className="text-xs text-muted-foreground">No data</span>}
          {hasData && (
            <div className="flex gap-2 text-xs text-muted-foreground">
              {sessions.length > 0 && <span>{sessions.length} session{sessions.length !== 1 ? "s" : ""}</span>}
              {activities.length > 0 && <span>{activities.length} activit{activities.length !== 1 ? "ies" : "y"}</span>}
              {emotions.length > 0 && <span>{emotions.length} check-in{emotions.length !== 1 ? "s" : ""}</span>}
              {journals.length > 0 && <span>{journals.length} journal{journals.length !== 1 ? "s" : ""}</span>}
            </div>
          )}
          {importantDates.length > 0 && importantDates.map((x, i) => (
            <span
              key={i}
              className="inline-flex items-center gap-1 text-[0.6875rem] px-1.5 py-0.5 rounded-full border"
              style={{ borderColor: (x.color || "var(--color-primary, #6366f1)") + "66", color: x.color || "var(--color-text-primary, #e5e7eb)" }}
              title={`${x.alterName} — ${x.fieldName}`}
            >
              📅 <span className="font-medium">{x.alterName}</span>
              <span className="opacity-70">· {x.fieldName}</span>
            </span>
          ))}
        </div>
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          {!collapsed && (
            <button onClick={() => setShowTally(v => !v)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-colors ${showTally ? "bg-primary/20 text-primary border-primary/40" : "bg-muted/50 text-muted-foreground border-border/50 hover:border-primary/30"}`}>
              <BarChart3 className="w-3 h-3" />
              Tally
            </button>
          )}
          {collapsed ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronUp className="w-4 h-4 text-muted-foreground" />}
        </div>
      </button>

      {!collapsed && (
        <div className="overflow-x-auto border-t border-border">
          <div style={{ minWidth: totalWidth }}>
            <div className="flex border-b border-border/40 bg-muted/20 relative" style={{ minWidth: totalWidth }}>
              {/* Time label spacer */}
              <div style={{ width: LABEL_WIDTH }} className="flex-shrink-0" />
              {/* Alters — always shown */}
              <div className="text-center py-1 relative flex-shrink-0" style={{ width: alterAreaWidth }}>
                <Users className="w-3.5 h-3.5 inline" />
                <ResizeHandle onDrag={(d) => dragCol("alter", d / numAlterCols)} />
              </div>
              {/* Symptoms — only if data exists */}
              {numSymptomCols > 0 && (
                <div className="text-center py-1 relative flex-shrink-0" style={{ width: symptomAreaWidth }}>
                  <span className="text-xs text-muted-foreground opacity-60">⚡</span>
                  <ResizeHandle onDrag={(d) => dragCol("symptom", d / numSymptomCols)} />
                </div>
              )}
              {/* Events — only if data exists */}
              {eventColWidth_actual > 0 && (
                <div className="text-center py-1 relative flex-shrink-0" style={{ width: eventColWidth_actual }}>
                  <BookOpen className="w-3.5 h-3.5 inline" />
                  <ResizeHandle onDrag={(d) => dragCol("eventCol", d)} />
                </div>
              )}
              {/* Emotions — only if data exists */}
              {emotionColWidth_actual > 0 && (
                <div className="text-center py-1 relative flex-shrink-0" style={{ width: emotionColWidth_actual }}>
                  <Heart className="w-3.5 h-3.5 inline" />
                  <ResizeHandle onDrag={(d) => dragCol("emotionCol", d)} />
                </div>
              )}
              {/* Activities — only if data exists */}
              {numActivityCols > 0 && (
                <div className="text-center py-1 relative flex-shrink-0" style={{ width: activityAreaWidth }}>
                  <Activity className="w-3.5 h-3.5 inline" />
                  <ResizeHandle onDrag={(d) => dragCol("activity", d / numActivityCols)} />
                </div>
              )}
            </div>

            {/* Each day's grid now flows in the page scroll instead of
                its own capped scroller. The previous wrapper
                (`<div className="overflow-y-auto" style={{ maxHeight:
                "calc(100vh - 220px)" }}>`) trapped the user inside one
                day's 24-hour range — once they scrolled to the bottom
                of that day, the page scroll never engaged, so they
                couldn't reach the previous day's content without a
                clumsy outside-the-grid drag. Now the day renders
                full-height; the parent Timeline page's normal scroll
                handles moving between days and the IntersectionObserver
                sentinel lazy-loads more. */}
            <div>
              <div ref={timelineAreaRef} className="relative" style={{ height: totalHeight, minWidth: totalWidth, touchAction: "pan-x pan-y" }}
                onMouseDown={startAreaLongPress} onMouseMove={moveAreaLongPress} onMouseUp={cancelAreaLongPress} onMouseLeave={cancelAreaLongPress}
                onTouchStart={startAreaLongPress} onTouchMove={moveAreaLongPress} onTouchEnd={cancelAreaLongPress} onTouchCancel={cancelAreaLongPress}>

                {HOURS.map((h) => {
                  const top = getTopPx(h * 60);
                  const isCurrentHour = isToday && Math.floor(nowMins / 60) === h;
                  return (
                    <div key={h} className="absolute flex items-start"
                      style={{ top, height: rowH, left: 0, right: 0 }}>
                      {/* Current-hour highlight */}
                      {isCurrentHour && (
                        <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
                      )}
                      {/* The gridline sits at the TRUE hour position (no offset) so
                          it lines up with content placed by getTopPx — previously
                          an 8px (mt-2) push made the line sit below its hour, so an
                          activity looked ~15min short of its real end. The label is
                          centred on that line. */}
                      <div className="flex-shrink-0 text-xs text-muted-foreground pl-1 text-left" style={{ width: LABEL_WIDTH, transform: "translateY(-50%)" }}>
                        {format(new Date(dayStart.getTime() + h * 3600000), "h a")}
                      </div>
                      <div className="flex-1 border-t border-border/30" />
                    </div>
                  );
                })}

                {/* Now line — only on today */}
                {isToday && (() => {
                  const nowTop = getTopPx(nowMins);
                  return (
                    <div className="absolute pointer-events-none z-20"
                      style={{ top: nowTop, left: 0, right: 0 }}>
                      <div className="relative flex items-center">
                        <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 -ml-1" />
                        <div className="flex-1 h-px bg-primary opacity-70" />
                      </div>
                    </div>
                  );
                })()}

                {numActivityCols > 0 && activityColumns.map((col, colIdx) => (
                  <div key={`acol-${colIdx}`} className="absolute"
                    style={{ left: activityLeft + colIdx * colWidths.activity, top: 0, width: colWidths.activity, height: totalHeight }}>
                    {col.map((entry) => {
                     const topPx = getTopPx(entry.startMins);
                     const heightPx = getRangePx(entry.startMins, entry.endMins);
                     const dateStr = format(day, "yyyy-MM-dd");
                     const timeStr = formatMins(entry.startMins);
                     return (
                       <ActivityBar
                         key={entry.key}
                         activityName={entry.displayName}
                         color={entry.categoryColor || "#8b5cf6"}
                         mergedCount={entry.mergedCount}
                         topPx={topPx}
                         heightPx={heightPx}
                         notes={entry.activity.notes}
                         timeStr={timeStr}
                         onTap={() => setDetailPopup({ type: "activity", entry })}
                         onDoubleTap={() => navigate(`/activities?date=${dateStr}&highlight=${entry.activity.id}`)}
                       />
                     );
                    })}
                  </div>
                ))}

                {/* Divider: time label | alters */}
                <div className="absolute top-0 bottom-0 border-l border-border/40 pointer-events-none"
                  style={{ left: LABEL_WIDTH, height: totalHeight }} />
                {numSymptomCols > 0 && (
                  <div className="absolute top-0 bottom-0 border-l border-border/20 pointer-events-none"
                    style={{ left: symptomLeft, height: totalHeight }} />
                )}
                {eventColWidth_actual > 0 && (
                  <div className="absolute top-0 bottom-0 border-l border-border/30 pointer-events-none"
                    style={{ left: eventColLeft, height: totalHeight }} />
                )}
                {emotionColWidth_actual > 0 && (
                  <div className="absolute top-0 bottom-0 border-l border-border/20 pointer-events-none"
                    style={{ left: emotionColLeft, height: totalHeight }} />
                )}
                {locationColWidth_actual > 0 && (
                  <div className="absolute top-0 bottom-0 border-l border-border/20 pointer-events-none"
                    style={{ left: locationColLeft, height: totalHeight }} />
                )}
                {numActivityCols > 0 && (
                  <div className="absolute top-0 bottom-0 border-l border-border/20 pointer-events-none"
                    style={{ left: activityLeft, height: totalHeight }} />
                )}

                {showSymptoms && symptomColumns.map((col, colIdx) => (
                  <div key={`scol-${colIdx}`} className="absolute"
                    style={{ left: symptomLeft + colIdx * colWidths.symptom, top: 0, width: colWidths.symptom, height: totalHeight, zIndex: 5 }}>
                    {col.map((entry, i) => {
                       const session = symptomSessions.find(s => s.id === entry.sessionId);
                       const symptom = symptomMap[entry.symptomId];
                       const topPx = getTopPx(entry.startMins);
                       const heightPx = getRangePx(entry.startMins, entry.endMins);
                       const barKey = `sbar-${entry.sessionId}-${i}`;
                       return (
                         <SymptomBar
                           key={barKey}
                           symptom={symptom}
                           session={session}
                           topPx={topPx}
                           heightPx={heightPx}
                           rowH={rowH}
                           expanded={false}
                           tiedAlters={altersAtTime(session?.start_time)}
                           onTap={() => setSymptomDetailModal({ session, symptom, tiedAlters: altersAtTime(session?.start_time) })}
                           onLongPress={() => setSymptomSessionPopover({ session, symptom, splitMins: entry.startMins })}
                           onDoubleTap={() => setSymptomSessionPopover({ session, symptom, splitMins: entry.startMins })}
                         />
                       );
                     })}
                  </div>
                ))}



                {eventColWidth_actual > 0 && (
                  <div className="absolute" style={{ left: eventColLeft, top: 0, width: eventColWidth_actual, height: totalHeight }}>
                    {eventPositioned.map((entry) => (
                      <EventEntry
                        key={entry.key}
                        entry={entry}
                        topPx={entry.adjustedTop}
                        lane={entry.lane}
                        laneWidth={entry.laneWidth}
                        colWidth={eventColWidth}
                        onTap={() => setDetailPopup({ type: "event", entry })}
                        onDoubleTap={() => {
                          if (entry.type === "journal") navigate(`/journals?id=${entry.id}`);
                          else if (entry.type === "checkin") navigate(`/system-checkin?id=${entry.id}`);
                          else if (entry.type === "bulletin") navigate(`/`);
                          else if (entry.type === "task") navigate(`/todo`);
                          else if (entry.type === "task_done") navigate(`/todo`);
                          else if (entry.type === "symptom_checkin") navigate(`/checkin-log`);
                          else if (entry.type === "sleep") navigate(`/sleep`);
                          else if (entry.type === "lineage") navigate(`/system-history`);
                          else if (entry.type === "diary") navigate(`/diary`);
                          else if (entry.type === "poll") navigate(`/polls?id=${entry.id}`);
                          else if (entry.type === "reminder") navigate(`/reminders`);
                          else if (entry.type === "reflection") navigate(`/grounding`);
                          else if (entry.type === "alter_note") navigate(`/alter/${entry.data?.alter_id || ""}`);
                          else if (entry.type === "daily_tasks") navigate(`/tasks`);
                          else if (entry.type === "daily_task") navigate(`/tasks`);
                        }}
                      />
                    ))}
                  </div>
                )}

                {emotionColWidth_actual > 0 && (
                  <div className="absolute" style={{ left: emotionColLeft, top: 0, width: emotionColWidth_actual, height: totalHeight }}>
                    {emotionPositioned.map((entry) => (
                      <EmotionBubble
                        key={entry.key}
                        entry={entry}
                        topPx={entry.adjustedTop}
                        colWidth={emotionColWidth_actual}
                        tiedAlters={(entry.data.fronting_alter_ids || []).map(id => altersByIdMap[id]).filter(Boolean)}
                        onTap={() => setDetailPopup({ type: "emotion", entry })}
                        onDoubleTap={() => navigate(`/checkin-log?id=${entry.id}`)}
                      />
                    ))}
                  </div>
                )}

                {locationColWidth_actual > 0 && (
                  <div className="absolute" style={{ left: locationColLeft, top: 0, width: locationColWidth_actual, height: totalHeight }}>
                    {locationPositioned.map((entry) => (
                      <LocationBubble
                        key={entry.key}
                        entry={entry}
                        topPx={entry.adjustedTop}
                        colWidth={locationColWidth_actual}
                        onTap={() => setDetailPopup({ type: "location", entry })}
                      />
                    ))}
                  </div>
                )}

                <div
                  className="absolute"
                  style={{ left: alterLeft, top: 0, width: alterAreaWidth, height: totalHeight, zIndex: 1 }}
                >
                  {alterColumns.map((col, colIdx) => (
                    <div key={`col-${colIdx}`} className="absolute"
                      style={{ left: colIdx * colWidths.alter, top: 0, width: colWidths.alter, height: totalHeight }}>
                      {col.map((entry) => {
                        const alter = alters.find((a) => a.id === entry.alterId);
                        const topPx = getTopPx(entry.startMins);
                        const heightPx = getRangePx(entry.startMins, entry.endMins);
                        const entrySession = sessions.find(s => s.id === entry.sessionId);
                        const levelStyle = entrySession ? frontLook.styleFor(entrySession) : null;
                        const color = entrySession ? frontLook.activeColor(alter, entrySession) : (alter?.color || "#9333ea");
                        const isFocused = !!focusSessionId && entrySession?.id === focusSessionId;
                        return (
                          <AlterBar
                            key={entry.key}
                            alter={alter}
                            color={color}
                            ringW={Number.isFinite(levelStyle?.ringW) ? levelStyle.ringW : null}
                            topPx={topPx}
                            heightPx={heightPx}
                            isPrimary={entry.isPrimary}
                            rowH={rowH}
                            hasNote={!!entrySession?.note}
                            highlight={isFocused}
                            onTap={() => entrySession && setSessionPopover({ session: entrySession, alter })}
                            onDoubleTap={() => entrySession && setEditingSession({ session: entrySession, alter })}
                            onLongPress={({ clientY, barTop }) => {
                              if (!entrySession) return;
                              // barTop = viewport Y of the bar's top edge; topPx = bar's Y in the day grid
                              // gridOriginY = viewport Y of the day grid's 00:00 row
                              const gridOriginY = barTop - topPx;
                              const relY = clientY - gridOriginY;
                              const pressedMins = Math.round((relY / totalHeight) * 24 * 60 / 5) * 5;
                              const clampedMins = Math.min(Math.max(pressedMins, entry.startMins), entry.endMins);
                              setSplitPopover({ alter, session: entrySession, splitMins: clampedMins });
                            }}
                          />
                        );
                      })}
                    </div>
                  ))}
                </div>

                {statusNoteEntries.map(({ id, note, startMins }) => (
                  <StatusNoteBadge key={id} id={id} note={note} topPx={getTopPx(startMins)} />
                ))}

              </div>
            </div>
          </div>
        </div>
      )}

      {!collapsed && showTally && (
        <DailyTallyPanel
          day={day} sessions={sessions} activities={activities} emotions={emotions}
          journals={journals} checkIns={checkIns} tasks={tasks} alters={alters}
          symptoms={symptoms} symptomSessions={symptomSessions}
          bulletins={bulletins} categories={categories}
          statusNotes={statusNotes}
        />
      )}

      {sessionPopover && !editingSession && (
        <AlterSessionInfo
          session={sessionPopover.session}
          alter={sessionPopover.alter}
          onClose={() => setSessionPopover(null)}
          onEdit={() => { setEditingSession(sessionPopover); setSessionPopover(null); }}
        />
      )}

      {editingSession && (
        <AlterSessionEdit
          session={editingSession.session}
          alter={editingSession.alter}
          onClose={() => setEditingSession(null)}
        />
      )}

      {splitPopover && (
        <SessionSplitPopup
          alter={splitPopover.alter}
          session={splitPopover.session}
          splitMins={splitPopover.splitMins}
          onClose={() => setSplitPopover(null)}
          onSave={handleSplitSave}
        />
      )}

      {newSessionPopover && (
        <NewSessionPopup
          startMins={newSessionPopover.startMins}
          dayStart={dayStart}
          alters={alters}
          onClose={() => setNewSessionPopover(null)}
          onSave={handleNewSessionSave}
        />
      )}

      {symptomSessionPopover && (
        <SymptomSessionPopup
          symptom={symptomSessionPopover.symptom}
          session={symptomSessionPopover.session}
          onClose={() => setSymptomSessionPopover(null)}
          onSave={() => {}}
        />
      )}

      {symptomDetailModal && (
        <SymptomDetailModal
          symptom={symptomDetailModal.symptom}
          session={symptomDetailModal.session}
          tiedAlters={symptomDetailModal.tiedAlters || []}
          onClose={() => setSymptomDetailModal(null)}
          onEdit={() => {
            // Hand off from the read-only detail to the edit popup
            // (start/end times, severity, end/delete session) — same
            // affordance the alter session popover exposes.
            const target = symptomDetailModal;
            setSymptomDetailModal(null);
            setSymptomSessionPopover({
              session: target.session,
              symptom: target.symptom,
              splitMins: null,
            });
          }}
        />
      )}

      {retroPickerState && (
        <RetroEntryPicker
          startMins={retroPickerState.startMins}
          onFrontSession={(mins) => { setNewSessionPopover({ startMins: mins ?? retroPickerState.startMins }); setRetroPickerState(null); }}
          onCheckIn={(mins) => { setRetroCheckIn({ startMins: mins ?? retroPickerState.startMins }); setRetroPickerState(null); }}
          onClose={() => setRetroPickerState(null)}
        />
      )}

      {retroCheckIn && (() => {
        const d = new Date(dayStart);
        d.setHours(Math.floor(retroCheckIn.startMins / 60), retroCheckIn.startMins % 60, 0, 0);
        return (
          <QuickCheckInModal
            isOpen={true}
            onClose={() => setRetroCheckIn(null)}
            alters={alters}
            retroTimestamp={d.toISOString()}
          />
        );
      })()}

      {detailPopup?.type === "activity" && (() => {
        const { entry } = detailPopup;
        const color = entry.categoryColor || "#8b5cf6";
        return (
          <DetailPopup icon="🏃" timeStr={formatMins(entry.startMins)} onClose={() => setDetailPopup(null)}>
            <p className="text-sm font-semibold" style={{ color }}>{entry.displayName}</p>
            {(() => {
              const act = entry.activity;
              const start = activityDate(act);
              const durMin = Math.max(act.duration_minutes || act.actual_duration_minutes || 0, 0);
              const end = durMin > 0 ? new Date(start.getTime() + durMin * 60000) : null;
              const durLabel = durMin >= 60 ? `${Math.round((durMin / 60) * 10) / 10}h` : `${durMin}m`;
              return (
                <p className="text-xs text-muted-foreground mt-1">
                  {format(start, "h:mm a")}{end ? ` – ${format(end, "h:mm a")}` : ""}{durMin > 0 ? ` · ${durLabel}` : ""}
                </p>
              );
            })()}
            {entry.mergedCount > 1 && <p className="text-xs text-muted-foreground mt-1">{entry.mergedCount} instances</p>}
            {entry.activity.notes && <p className="text-sm text-foreground mt-2 whitespace-pre-wrap">{entry.activity.notes}</p>}
            {!entry.activity.notes && entry.mergedCount <= 1 && <p className="text-xs text-muted-foreground mt-1 italic">No notes</p>}
          </DetailPopup>
        );
      })()}

      {detailPopup?.type === "emotion" && (() => {
        const { entry } = detailPopup;
        const emotions = entry.data.emotions || [];
        const note = entry.data.note;
        const timeStr = `${String(Math.floor(entry.mins / 60)).padStart(2, '0')}:${String(entry.mins % 60).padStart(2, '0')}`;
        const tied = (entry.data.fronting_alter_ids || []).map(id => altersByIdMap[id]).filter(Boolean);
        return (
          <DetailPopup icon="💭" timeStr={timeStr} onClose={() => setDetailPopup(null)}>
            {emotions.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-2">
                {emotions.map((em) => (
                  <span key={em} className="px-2 py-0.5 rounded-full text-white text-xs font-medium"
                    style={{ backgroundColor: emotionColor(em) }}>{em}</span>
                ))}
              </div>
            )}
            {tied.length > 0 && (
              <div className="mb-2">
                <p className="text-[0.625rem] uppercase tracking-wider text-muted-foreground mb-1">Tied to</p>
                <div className="flex flex-wrap gap-1.5">
                  {tied.map((a) => (
                    <span key={a.id} className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                      style={{ backgroundColor: `${a.color || "#8b5cf6"}20`, color: a.color || "#8b5cf6", border: `1px solid ${a.color || "#8b5cf6"}40` }}>
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: a.color || "#8b5cf6" }} />
                      {a.alias || a.name}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {note && <p className="text-sm text-foreground whitespace-pre-wrap">{note}</p>}
            {emotions.length === 0 && !note && <p className="text-xs text-muted-foreground italic">No details</p>}
          </DetailPopup>
        );
      })()}

      {detailPopup?.type === "location" && (() => {
        const { entry } = detailPopup;
        const cat = getCategoryMeta(entry.data.category);
        const timeStr = `${String(Math.floor(entry.mins / 60)).padStart(2, '0')}:${String(entry.mins % 60).padStart(2, '0')}`;
        return (
          <DetailPopup icon={cat.emoji} timeStr={timeStr} onClose={() => setDetailPopup(null)}>
            <p className="text-sm font-semibold">{entry.data.name || cat.label}</p>
            <p className="text-xs mt-0.5" style={{ color: cat.color }}>{cat.label}</p>
            {entry.data.notes && <p className="text-sm text-foreground mt-2 whitespace-pre-wrap">{entry.data.notes}</p>}
            {entry.data.latitude != null && entry.data.longitude != null && (
              <div className="mt-2 space-y-1">
                <p className="text-xs text-muted-foreground font-mono">
                  {entry.data.latitude.toFixed(5)}, {entry.data.longitude.toFixed(5)}
                </p>
                <a
                  href={`https://www.google.com/maps?q=${entry.data.latitude},${entry.data.longitude}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-blue-400 hover:text-blue-300 underline"
                  onClick={e => e.stopPropagation()}
                >
                  Open in Maps ↗
                </a>
              </div>
            )}
          </DetailPopup>
        );
      })()}

      {detailPopup?.type === "event" && (() => {
        const { entry } = detailPopup;
        const meta = TYPE_META[entry.type] || { icon: "•" };
        const timeStr = `${String(Math.floor(entry.mins / 60)).padStart(2, '0')}:${String(entry.mins % 60).padStart(2, '0')}`;
        return (
          <DetailPopup icon={meta.icon} timeStr={timeStr} onClose={() => setDetailPopup(null)}>
            {entry.type === "journal" && <p className="text-sm font-semibold">{entry.label}</p>}
            {entry.type === "checkin" && <p className="text-sm font-semibold">System Meeting</p>}
            {entry.type === "bulletin" && (() => {
              // Defensive: even though we filter task-bulletins out of the
              // event column above, if one ever sneaks through (e.g. an
              // older record) strip the `[task:ID] ` prefix so the raw
              // identifier doesn't surface in the popup body.
              const raw = entry.data.content || "";
              const cleaned = raw.replace(/^\[task:[^\]]+\]\s*/, "");
              return <p className="text-sm text-foreground whitespace-pre-wrap line-clamp-6">{cleaned}</p>;
            })()}
            {(entry.type === "task" || entry.type === "task_done") && <p className="text-sm font-semibold">{entry.label}</p>}
            {entry.type === "symptom_checkin" && (
              <div className="space-y-1">
                {(entry.data.items || []).map(({ symptom, checkIn }, i) => (
                  <p key={i} className="text-sm" style={{ color: symptom?.color || "#8b5cf6" }}>
                    {symptom?.label || "?"}{checkIn.severity != null ? ` · ${formatSeverityForSymptom(symptom, checkIn.severity)}` : ""}
                  </p>
                ))}
              </div>
            )}
            {["sleep", "lineage", "diary", "poll", "reflection", "alter_note", "daily_task"].includes(entry.type) && (
              <p className="text-sm font-semibold whitespace-pre-wrap">{entry.label}</p>
            )}
            {entry.type === "reminder" && (
              <div className="space-y-1.5">
                <p className="text-sm font-semibold whitespace-pre-wrap">{entry.data?.title || entry.label || "Reminder"}</p>
                {entry.data?.body && entry.data.body !== entry.data?.title && (
                  <p className="text-sm text-foreground whitespace-pre-wrap">{entry.data.body}</p>
                )}
                <button
                  type="button"
                  onClick={() => { setDetailPopup(null); navigate("/reminders"); }}
                  className="text-xs text-primary hover:underline"
                >
                  View in Reminders →
                </button>
              </div>
            )}
            {entry.type === "daily_tasks" && (() => {
              const ids = entry.data?.completed_task_ids || [];
              const titleById = {};
              for (const tpl of dailyTaskTemplates) { if (tpl?.id) titleById[tpl.id] = tpl.title || "Task"; }
              const names = ids.map((id) => titleById[id]).filter(Boolean);
              return (
                <div className="space-y-1.5">
                  <p className="text-sm font-semibold">{ids.length} daily task{ids.length !== 1 ? "s" : ""} done</p>
                  {names.length > 0 ? (
                    <ul className="text-sm space-y-0.5">
                      {names.map((n, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-emerald-500">✓</span>
                          <span className="text-foreground">{n}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-muted-foreground">Task names unavailable.</p>
                  )}
                </div>
              );
            })()}
          </DetailPopup>
        );
      })()}
    </div>
  );
}