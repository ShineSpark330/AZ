import React, { useState } from "react";
import { useTerms } from "@/lib/useTerms";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { HardDrive, Lock, Loader2, ShieldCheck, Eye, Trash2 } from "lucide-react";
import {
  isEncryptionEnabled, setEncryptionEnabled,
} from "@/lib/storageMode";
import { enableEncryption, disableEncryption, clearStoredData } from "@/lib/localDb";
import { runAutoBackupNow } from "@/lib/autoBackup";
import { BACKUP_LS_KEYS } from "@/lib/backupKeys";
import PersistentStorageStatus from "./PersistentStorageStatus";

export default function StorageModeSettings() {
  const terms = useTerms();
  const encEnabled = isEncryptionEnabled();

  const [showPasswordForm, setShowPasswordForm] = useState(null);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteInput, setDeleteInput] = useState("");
  const [deleting, setDeleting] = useState(false);

  const handleDeleteAllLocalData = async () => {
    if (deleteInput.trim().toLowerCase() !== "delete my data") return;
    setDeleting(true);
    try {
      // Storage invariant: anything that destroys data saves a copy first.
      // Same path as the Octocon / OpenPlural wipes — cancelling the
      // backup cancels the wipe, and a failed backup never deletes.
      try {
        // Every system — this wipes all of them, so a system that can't be
        // read right now must stop the wipe, not be skipped (review M4).
        const backupResult = await runAutoBackupNow({ allSystems: "required" });
        if (backupResult === "cancelled") {
          setError("Backup was cancelled — nothing was deleted.");
          setDeleting(false);
          return;
        }
      } catch (e) {
        setError(`Couldn't save a safety backup, so nothing was deleted: ${e?.message || e}`);
        setDeleting(false);
        return;
      }
      // Best-effort: tear down the Friends profile on the cloud relay first so
      // the user is unsynced from every friend before local data goes away.
      // (deleteIdentity itself already swallows network failures.)
      try {
        const { deleteIdentity } = await import("@/lib/friendsApi");
        await deleteIdentity();
      } catch {}
      // Fully remove the stored DB (not loadDbDump({}), which leaves an
      // empty record the boot path treats as a returning user) so the
      // reload below lands on the first-run onboarding screen.
      await clearStoredData();
      // …and EVERY other system's blob, the systems registry, and the
      // media stores — clearing only the active blob left the other
      // systems fully intact and still detected (owner report).
      const { wipeAllSystemsData } = await import("@/lib/systems");
      await wipeAllSystemsData();
      // Clear all Symphony localStorage keys so the app re-runs first-time
      // onboarding. disclaimer_acknowledged_v1 is included deliberately —
      // it used to survive the wipe, so a fully-reset app skipped the
      // disclaimer while re-showing everything else (inconsistent).
      // Every backed-up preference key too — some real content (the
      // always-unlocked grocery lists) and several preferences don't use
      // the symphony_ prefix and used to survive "Delete Everything".
      const extraKeys = new Set([...BACKUP_LS_KEYS, "terms_setup_done", "tour_seen", "disclaimer_acknowledged_v1"]);
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith("symphony_") || extraKeys.has(key)) {
          localStorage.removeItem(key);
        }
      });
      window.location.href = "/";
    } catch (e) {
      setError("Failed to delete data: " + e.message);
      setDeleting(false);
    }
  };

  const handleEnableEncryption = async () => {
    if (newPassword !== confirmPassword) { setError("Passwords do not match."); return; }
    if (newPassword.length < 6) { setError("Password must be at least 6 characters."); return; }
    setLoading(true);
    try {
      await enableEncryption(newPassword);
      setEncryptionEnabled(true);
      setSuccess("Encryption enabled! Your data is now protected.");
      setShowPasswordForm(null);
      setNewPassword(""); setConfirmPassword("");
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  };

  const handleDisableEncryption = async () => {
    setLoading(true);
    try {
      await disableEncryption(oldPassword);
      setEncryptionEnabled(false);
      setSuccess("Encryption disabled. Data saved as plain text.");
      setShowPasswordForm(null);
      setOldPassword("");
    } catch { setError("Incorrect password."); } finally { setLoading(false); }
  };

  const handleChangePassword = async () => {
    if (newPassword !== confirmPassword) { setError("Passwords do not match."); return; }
    if (newPassword.length < 6) { setError("Password must be at least 6 characters."); return; }
    setLoading(true);
    try {
      // Step 1 — decrypt with the old password. A wrong password throws here
      // BEFORE any data is rewritten (initLocalDb refuses to clear the key),
      // so the data stays safely encrypted.
      try {
        await disableEncryption(oldPassword);
      } catch {
        setError("Incorrect current password.");
        return;
      }
      // Step 2 — the data is now plaintext on disk; re-encrypt with the new
      // password. If THIS fails (rare), don't pretend it's still encrypted —
      // reflect that it's currently unencrypted so the user can re-enable.
      try {
        await enableEncryption(newPassword);
      } catch {
        setEncryptionEnabled(false);
        setError("Couldn't set the new password — your data is currently UNENCRYPTED. Re-enable encryption from Data Storage to protect it again.");
        return;
      }
      setSuccess("Password changed successfully.");
      setShowPasswordForm(null);
      setOldPassword(""); setNewPassword(""); setConfirmPassword("");
    } finally { setLoading(false); }
  };

  const resetForm = () => {
    setShowPasswordForm(null);
    setOldPassword(""); setNewPassword(""); setConfirmPassword("");
    setError(""); setSuccess("");
  };

  return (
    <Card className="border-border/50">
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <HardDrive className="w-5 h-5 text-primary" />
          </div>
          <div>
            <CardTitle className="text-lg">Data Storage</CardTitle>
            <CardDescription>
              Local only{encEnabled && <span className="ml-2 text-xs text-primary">🔒 Encrypted</span>}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {success && <p className="text-sm text-green-600 bg-green-50 dark:bg-green-950/30 rounded-lg px-3 py-2">{success}</p>}
        {error && <p className="text-sm text-destructive bg-destructive/5 rounded-lg px-3 py-2">{error}</p>}

        <div className="text-sm text-muted-foreground bg-muted/40 rounded-xl p-3 space-y-2">
          <p>
            By default your data lives only on this device. No internet connection or account required, no analytics, no crash telemetry — the only things that ever leave are the opt-in features listed under Data & privacy.
          </p>
          <details className="text-xs">
            <summary className="cursor-pointer text-foreground/80 hover:text-foreground">
              What's actually stored, and what encryption covers
            </summary>
            <div className="mt-2 space-y-2 pl-1 border-l-2 border-border/50 pl-3">
              <p>
                <span className="font-medium text-foreground">IndexedDB (encrypted when encryption is on)</span> — alters, fronting sessions, journals, emotion / symptom check-ins, activities, plans, to-dos, diary cards, reminders, lineage events, locations, status notes, custom fields, grounding techniques, grocery lists you didn't mark "available when locked", and so on.
              </p>
              <p>
                <span className="font-medium text-foreground">localStorage</span> — small per-browser settings (theme, last-opened list ids, daily-task firing markers), native push registration IDs, and grocery lists you explicitly marked "available when locked". These stay on this device but are NOT covered by the encryption password. Your Friends identity lives here too, and it <em>is</em> sealed with your password when encryption is on. Your preferences are also copied into the database, so a browser storage wipe doesn't lose your theme and setup.
              </p>
              <p>
                <span className="font-medium text-foreground">When encryption is on</span> — the IndexedDB blob is wrapped with AES-256-GCM using a key derived from your password via PBKDF2 (600,000 iterations; data encrypted by older app versions upgrades automatically the next time it's unlocked). The salt is embedded inside the encrypted payload so a localStorage wipe alone can't make data permanently undecryptable. <span className="font-medium text-foreground">If you lose the password, the encrypted data cannot be recovered.</span>
              </p>
              <p>
                <span className="font-medium text-foreground">Never stored</span> — analytics, crash telemetry, usage tracking, advertising IDs. There's no Symphony account and no server-side copy of your data. Friends Mode (off until you set it up) sends only what its privacy notice lists — your display name, {terms.system} name, friend code, friends list, push registration, public key, current {terms.front}, and any {terms.alters} you share (end-to-end encrypted) — never journals, emotions, symptoms, plans, locations, or chat.
              </p>
            </div>
          </details>
        </div>

        <div className="rounded-xl border border-border/40 p-3">
          <PersistentStorageStatus />
        </div>

        {/* Encryption controls */}
        {!showPasswordForm && (
          <div className="flex gap-2">
            {!encEnabled ? (
              <Button variant="outline" onClick={() => { setShowPasswordForm("enable"); setError(""); setSuccess(""); }} className="flex-1 gap-2">
                <Lock className="w-4 h-4" /> Enable Encryption
              </Button>
            ) : (
              <>
                <Button variant="outline" onClick={() => { setShowPasswordForm("change"); setError(""); setSuccess(""); }} className="flex-1 gap-2">
                  <ShieldCheck className="w-4 h-4" /> Change Password
                </Button>
                <Button variant="outline" onClick={() => { setShowPasswordForm("disable"); setError(""); setSuccess(""); }} className="gap-2 text-destructive hover:text-destructive">
                  <ShieldCheck className="w-4 h-4" /> Remove
                </Button>
              </>
            )}
          </div>
        )}

        {showPasswordForm === "enable" && (
          <div className="space-y-3 rounded-xl border border-border/50 p-3">
            <Label>New Password</Label>
            <div className="relative">
              <Input type={showPass ? "text" : "password"} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="Password..." className="pr-10" />
              <button onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"><Eye className="w-4 h-4" /></button>
            </div>
            <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm password..." />
            <div className="flex gap-2">
              <Button variant="outline" onClick={resetForm} className="flex-1">Cancel</Button>
              <Button onClick={handleEnableEncryption} disabled={loading} className="flex-1 bg-primary hover:bg-primary/90">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Enable"}
              </Button>
            </div>
          </div>
        )}

        {showPasswordForm === "disable" && (
          <div className="space-y-3 rounded-xl border border-destructive/30 p-3">
            <Label>Current Password</Label>
            <Input type="password" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} placeholder="Enter current password..." />
            <div className="flex gap-2">
              <Button variant="outline" onClick={resetForm} className="flex-1">Cancel</Button>
              <Button onClick={handleDisableEncryption} disabled={loading} className="flex-1 bg-destructive hover:bg-destructive/90 text-white">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Remove Encryption"}
              </Button>
            </div>
          </div>
        )}

        {showPasswordForm === "change" && (
          <div className="space-y-3 rounded-xl border border-border/50 p-3">
            <Label>Current Password</Label>
            <Input type="password" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} placeholder="Current password..." />
            <Label>New Password</Label>
            <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="New password..." />
            <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm new password..." />
            <div className="flex gap-2">
              <Button variant="outline" onClick={resetForm} className="flex-1">Cancel</Button>
              <Button onClick={handleChangePassword} disabled={loading} className="flex-1 bg-primary hover:bg-primary/90">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Change Password"}
              </Button>
            </div>
          </div>
        )}

        {/* Delete all local data */}
        {!showDeleteConfirm && (
          <Button
            variant="ghost"
            onClick={() => setShowDeleteConfirm(true)}
            className="w-full gap-2 text-destructive hover:text-destructive hover:bg-destructive/10 text-sm"
          >
            <Trash2 className="w-4 h-4" /> Delete All Local Data
          </Button>
        )}

        {showDeleteConfirm && (
          <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-4 space-y-3">
            <p className="text-sm font-semibold text-destructive">⚠️ This is permanent</p>
            <p className="text-xs text-muted-foreground">All your local data will be permanently deleted. This cannot be undone. A full backup is saved to your device first — cancelling that backup cancels the delete.</p>
            <p className="text-xs font-medium">Type <span className="font-mono bg-muted px-1 rounded">delete my data</span> to confirm:</p>
            <Input
              value={deleteInput}
              onChange={(e) => setDeleteInput(e.target.value)}
              placeholder="delete my data"
              className="h-8 text-sm border-destructive/40"
            />
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => { setShowDeleteConfirm(false); setDeleteInput(""); }} className="flex-1">Cancel</Button>
              <Button
                size="sm"
                onClick={handleDeleteAllLocalData}
                disabled={deleteInput.trim().toLowerCase() !== "delete my data" || deleting}
                className="flex-1 bg-destructive hover:bg-destructive/90 text-white"
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Delete Everything"}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
