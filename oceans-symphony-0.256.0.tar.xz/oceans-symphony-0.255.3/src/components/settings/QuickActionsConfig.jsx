import React, { useState, useMemo } from "react";
import { confirm } from "@/components/shared/ConfirmDialog";
import AlterSearchSelect from "@/components/shared/AlterSearchSelect";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ChevronUp, ChevronDown, ChevronRight, Trash2, Plus, Check, X, Pencil, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useTerms } from "@/lib/useTerms";
import { WHEEL } from "@/components/emotions/EmotionWheelPicker";
import { LOCATION_CATEGORIES } from "@/lib/locationCategories";
import { DEFAULT_GROUPS } from "@/components/diary/DiarySection";
import { applyTerms } from "@/lib/dailyTaskSystem";
import { getRootCategories } from "@/lib/categoryTreeUtils";
import { ALL_PAGES } from "@/utils/navigationConfig";
import { contactDisplayName } from "@/lib/contacts";

const CHECKIN_SECTIONS = [
  { id: "feeling", label: "Feeling / Emotions" },
  { id: "fronting", label: "Fronting" },
  { id: "activity", label: "Activity" },
  { id: "symptoms", label: "Symptoms / Habits" },
  { id: "diary", label: "Diary" },
  { id: "note", label: "Note" },
  { id: "location", label: "Location" },
];

// Flatten WHEEL into { label, category, color } entries
const BUILTIN_EMOTIONS = (() => {
  const out = [];
  Object.entries(WHEEL).forEach(([key, v]) => {
    if (v.flat) v.flat.forEach(lbl => out.push({ label: lbl, category: v.label, color: v.color }));
    if (v.cores) Object.entries(v.cores).forEach(([core, { color, subs }]) => {
      out.push({ label: core, category: v.label, color });
      subs.forEach(s => out.push({ label: s, category: v.label, color }));
    });
  });
  return out;
})();

function blankForm() {
  return { label: "", type: "open_checkin_section", emoji: null, config: {} };
}

// ── Activity category picker ──────────────────────────────────────────────────
function ActivityCategoryPicker({ categories, selectedId, onChange }) {
  const [expandedId, setExpandedId] = useState(null);
  const roots = useMemo(() => getRootCategories(categories), [categories]);
  const childrenOf = useMemo(() => {
    const map = {};
    categories.forEach(c => {
      if (c.parent_category_id) (map[c.parent_category_id] ??= []).push(c);
    });
    Object.values(map).forEach(arr => arr.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)));
    return map;
  }, [categories]);
  const selectedCat = categories.find(c => c.id === selectedId);

  if (categories.length === 0)
    return <p className="text-xs text-muted-foreground mt-1">No activities yet. Add them via Manage Activities on the Activity Tracker.</p>;

  return (
    <div className="space-y-1">
      {selectedCat && (
        <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-primary/10 border border-primary/30 text-xs font-medium text-primary mb-2">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: selectedCat.color || "currentColor" }} />
          {selectedCat.name}
          <button onClick={() => onChange("")} className="ml-auto text-primary/60 hover:text-primary"><X className="w-3 h-3" /></button>
        </div>
      )}
      <div className="max-h-48 overflow-y-auto rounded-lg border border-border/40 divide-y divide-border/30">
        {roots.map(root => {
          const subs = childrenOf[root.id] || [];
          const isExpanded = expandedId === root.id;
          const isSelected = selectedId === root.id;
          return (
            <div key={root.id}>
              <div className={`flex items-center text-sm transition-colors ${isSelected ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/40 text-foreground"}`}>
                <button type="button" onClick={() => onChange(root.id)} className="flex-1 flex items-center gap-2 px-3 py-2 text-left">
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: root.color || "#888" }} />
                  <span className="flex-1">{root.name}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 flex-shrink-0" />}
                </button>
                {subs.length > 0 && (
                  <button type="button" onClick={() => setExpandedId(isExpanded ? null : root.id)} className="px-2 py-2 text-muted-foreground hover:text-foreground">
                    <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isExpanded ? "rotate-90" : ""}`} />
                  </button>
                )}
              </div>
              {isExpanded && subs.map(sub => {
                const isSub = selectedId === sub.id;
                return (
                  <button key={sub.id} type="button" onClick={() => onChange(sub.id)}
                    className={`w-full flex items-center gap-2 pl-8 pr-3 py-1.5 text-xs transition-colors ${isSub ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/30 text-muted-foreground"}`}>
                    <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: sub.color || root.color || "#888" }} />
                    <span className="flex-1 text-left">{sub.name}</span>
                    {isSub && <Check className="w-3 h-3 flex-shrink-0" />}
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Emotion picker (full WHEEL + custom) ──────────────────────────────────────
function EmotionPicker({ customEmotions, selectedLabel, onChange }) {
  const [search, setSearch] = useState("");

  const allEmotions = useMemo(() => {
    const custom = customEmotions.map(e => ({ label: e.label, category: "My Custom Emotions", color: "#a855f7" }));
    return [...custom, ...BUILTIN_EMOTIONS];
  }, [customEmotions]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? allEmotions.filter(e => e.label.toLowerCase().includes(q)) : allEmotions;
  }, [search, allEmotions]);

  const grouped = useMemo(() => {
    const map = {};
    filtered.forEach(e => { (map[e.category] ??= []).push(e); });
    return map;
  }, [filtered]);

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search emotions…" className="pl-8 h-8 text-sm" />
      </div>
      {selectedLabel && (
        <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-primary/10 border border-primary/30 text-xs font-medium text-primary">
          {selectedLabel}
          <button onClick={() => onChange("")} className="ml-auto text-primary/60 hover:text-primary"><X className="w-3 h-3" /></button>
        </div>
      )}
      <div className="max-h-52 overflow-y-auto rounded-lg border border-border/40 divide-y divide-border/30">
        {Object.entries(grouped).map(([cat, emotions]) => (
          <div key={cat}>
            <p className="text-[0.625rem] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-1.5 bg-muted/20">{cat}</p>
            <div className="flex flex-wrap gap-1.5 px-3 py-2">
              {emotions.map(e => (
                <button key={e.label} type="button"
                  onClick={() => onChange(e.label)}
                  className={`px-2.5 py-1 rounded-full text-xs font-medium border transition-all ${selectedLabel === e.label ? "text-white border-transparent" : "border-border/50 text-foreground hover:border-primary/40"}`}
                  style={selectedLabel === e.label ? { backgroundColor: e.color, borderColor: e.color } : {}}>
                  {e.label}
                </button>
              ))}
            </div>
          </div>
        ))}
        {Object.keys(grouped).length === 0 && (
          <p className="text-xs text-muted-foreground px-3 py-4 text-center">No matches</p>
        )}
      </div>
    </div>
  );
}

// ── Symptom picker with search ────────────────────────────────────────────────
function SymptomPicker({ symptoms, selectedId, onChange }) {
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? symptoms.filter(s => s.label.toLowerCase().includes(q)) : symptoms;
  }, [search, symptoms]);

  if (symptoms.length === 0)
    return <p className="text-xs text-muted-foreground">No symptoms defined yet. Add them via Check-In → Symptoms section.</p>;

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search symptoms…" className="pl-8 h-8 text-sm" />
      </div>
      <div className="space-y-1.5 max-h-48 overflow-y-auto">
        {filtered.map(s => {
          const color = s.color || "#8B5CF6";
          const isSelected = selectedId === s.id;
          return (
            <div key={s.id} className="flex items-center gap-2 px-3 py-2 rounded-xl border transition-all"
              style={{ borderColor: isSelected ? color : "hsl(var(--border))", backgroundColor: isSelected ? `${color}15` : "hsl(var(--card))" }}>
              <span className="flex-1 text-sm font-medium">{s.label}</span>
              <button type="button" onClick={() => onChange(isSelected ? undefined : s.id)}
                className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 transition-all border"
                style={{ borderColor: isSelected ? color : "hsl(var(--border))", backgroundColor: isSelected ? color : "transparent", color: isSelected ? "#fff" : color }}>
                {isSelected ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
              </button>
            </div>
          );
        })}
        {filtered.length === 0 && <p className="text-xs text-muted-foreground px-1">No matches</p>}
      </div>
    </div>
  );
}

// ── Page picker (generic "jump to any page" shortcut) ────────────────────────
function PagePicker({ selectedId, onChange }) {
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? ALL_PAGES.filter(p => p.label.toLowerCase().includes(q)) : ALL_PAGES;
  }, [search]);

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search pages…" className="pl-8 h-8 text-sm" />
      </div>
      <div className="space-y-1 max-h-52 overflow-y-auto rounded-lg border border-border/40 p-1">
        {filtered.map(p => {
          const Icon = p.icon;
          const isSelected = selectedId === p.id;
          return (
            <button key={p.id} type="button" onClick={() => onChange(p.id)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
                isSelected ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/40 text-foreground"
              }`}>
              {Icon && <Icon className="w-3.5 h-3.5 flex-shrink-0" />}
              <span className="flex-1">{p.label}</span>
              {isSelected && <Check className="w-3.5 h-3.5 flex-shrink-0" />}
            </button>
          );
        })}
        {filtered.length === 0 && <p className="text-xs text-muted-foreground px-2 py-3 text-center">No matches</p>}
      </div>
    </div>
  );
}

// ── Contact picker ────────────────────────────────────────────────────────────
function ContactPicker({ contacts, selectedId, onChange }) {
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = contacts.filter(c => !c.is_archived);
    return q ? list.filter(c => contactDisplayName(c).toLowerCase().includes(q)) : list;
  }, [search, contacts]);

  if (contacts.length === 0)
    return <p className="text-xs text-muted-foreground">No contacts yet. Add one from the Contacts page.</p>;

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search contacts…" className="pl-8 h-8 text-sm" />
      </div>
      <div className="space-y-1 max-h-48 overflow-y-auto rounded-lg border border-border/40 p-1">
        {filtered.map(c => {
          const isSelected = selectedId === c.id;
          return (
            <button key={c.id} type="button" onClick={() => onChange(c.id)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
                isSelected ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/40 text-foreground"
              }`}>
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: c.color || "#0ea5e9" }} />
              <span className="flex-1">{contactDisplayName(c)}</span>
              {isSelected && <Check className="w-3.5 h-3.5 flex-shrink-0" />}
            </button>
          );
        })}
        {filtered.length === 0 && <p className="text-xs text-muted-foreground px-2 py-3 text-center">No matches</p>}
      </div>
    </div>
  );
}

// ── Diary field picker ────────────────────────────────────────────────────────
function DiaryFieldPicker({ diaryGroups, selectedGroupId, selectedFieldKey, onChange }) {
  return (
    <div className="max-h-52 overflow-y-auto rounded-lg border border-border/40 divide-y divide-border/30">
      {diaryGroups.map(group => (
        <div key={group.id}>
          <p className="text-[0.625rem] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-1.5 bg-muted/20">{group.label}</p>
          {group.fields.filter(f => f.enabled !== false).map(field => {
            const isSel = selectedGroupId === group.id && selectedFieldKey === field.data_key;
            return (
              <button key={field.id} type="button"
                onClick={() => onChange(group.id, field.data_key, field.type, field.label, field.max)}
                className={`w-full flex items-center gap-2 px-3 py-2 text-sm transition-colors text-left ${isSel ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/40 text-foreground"}`}>
                <span className="flex-1">{field.label}</span>
                <span className="text-xs text-muted-foreground">
                  {field.type === "rating" ? `0–${field.max}` : field.type === "boolean" ? "Yes/No" : "Number"}
                </span>
                {isSel && <Check className="w-3.5 h-3.5 flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}

// ── ActionForm ────────────────────────────────────────────────────────────────
function ActionForm({ initialData, alters, symptoms, activityCategories, customEmotions, diaryGroups, dailyTaskTemplates, contacts, onSave, onCancel, terms }) {
  const [data, setData] = useState(initialData || blankForm());

  const actionTypes = [
    { id: "open_checkin_section", label: "Open Check-In at a specific section" },
    { id: "open_set_front", label: `Open Set ${terms.Front}ers modal` },
    { id: "set_front_alter", label: `Set a specific ${terms.alter} as ${terms.front} (replaces current)` },
    { id: "add_to_front_alter", label: `Add a specific ${terms.alter} to ${terms.front} (keeps current)` },
    { id: "log_activity", label: "Log an activity" },
    { id: "start_activity", label: "Start an activity now (active timer)" },
    { id: "log_symptom", label: "Log a symptom or habit" },
    { id: "log_emotion", label: "Log an emotion" },
    { id: "log_diary", label: "Log a diary entry" },
    { id: "log_location", label: "Log a location" },
    { id: "mark_contact_with", label: "Mark a contact as currently with you" },
    { id: "toggle_sleep", label: "Start / end sleep" },
    { id: "set_status_note", label: "Post a quick status" },
    { id: "add_task", label: "Add a to-do" },
    { id: "toggle_daily_task", label: "Toggle a daily task" },
    { id: "navigate_to_page", label: "Open a page" },
    { id: "view_grocery_list", label: "View grocery list (privacy cover)" },
    { id: "add_grocery_item", label: "Add to grocery list" },
  ];

  const activeAlters = alters.filter(a => !a.is_archived);
  const activeSymptoms = symptoms.filter(s => !s.is_archived);
  const sortedCategories = [...activityCategories].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const setType = type => setData(d => ({ ...d, type, config: {} }));
  const setConfig = (key, value) => setData(d => ({ ...d, config: { ...d.config, [key]: value } }));

  const derivedLabel = () => {
    if (data.type === "set_front_alter") {
      const a = activeAlters.find(a => a.id === data.config?.alter_id);
      return a?.name || `Set ${terms.fronter}`;
    }
    if (data.type === "add_to_front_alter") {
      const a = activeAlters.find(a => a.id === data.config?.alter_id);
      return a?.name || `Add to ${terms.front}`;
    }
    if (data.type === "log_diary") return data.config?.field_label || "Diary field";
    if (data.type === "log_activity") {
      const c = activityCategories.find(c => c.id === data.config?.category_id);
      return c?.name || "Activity";
    }
    if (data.type === "open_checkin_section") {
      const s = CHECKIN_SECTIONS.find(s => s.id === data.config?.section);
      const label = s?.id === "fronting" ? terms.Fronting : s?.label;
      return label || "Check-In section";
    }
    if (data.type === "log_symptom") {
      const s = activeSymptoms.find(s => s.id === data.config?.symptom_id);
      return s?.label || "Symptom";
    }
    if (data.type === "log_emotion") return data.config?.emotion_label || "Emotion";
    if (data.type === "log_location") {
      const cat = LOCATION_CATEGORIES.find(c => c.id === data.config?.default_category);
      return cat ? `${cat.emoji} ${cat.label}` : "Location";
    }
    if (data.type === "open_set_front") return `Set ${terms.Front}ers`;
    if (data.type === "toggle_daily_task") {
      const t = dailyTaskTemplates?.find(t => t.id === data.config?.task_id);
      return t ? applyTerms(t.title, terms) : "Daily task";
    }
    if (data.type === "start_activity") {
      const c = activityCategories.find(c => c.id === data.config?.category_id);
      return c ? `Start ${c.name}` : "Start activity";
    }
    if (data.type === "mark_contact_with") {
      const c = contacts?.find(c => c.id === data.config?.contact_id);
      return c ? `With ${contactDisplayName(c)}` : "Mark contact with you";
    }
    if (data.type === "toggle_sleep") return "Start / end sleep";
    if (data.type === "set_status_note") return "Quick status";
    if (data.type === "add_task") return "Add a to-do";
    if (data.type === "navigate_to_page") {
      const p = ALL_PAGES.find(p => p.id === data.config?.page_id);
      return p ? `Open ${p.label}` : "Open page";
    }
    return data.type;
  };

  const handleSave = () => {
    if ((data.type === "set_front_alter" || data.type === "add_to_front_alter") && !data.config?.alter_id) { toast.error(`Choose an ${terms.alter}`); return; }
    if (data.type === "log_activity" && !data.config?.category_id) { toast.error("Choose an activity category"); return; }
    if (data.type === "open_checkin_section" && !data.config?.section) { toast.error("Choose a section"); return; }
    if (data.type === "log_symptom" && !data.config?.symptom_id) { toast.error("Choose a symptom"); return; }
    if (data.type === "log_emotion" && !data.config?.emotion_label?.trim()) { toast.error("Choose an emotion"); return; }
    if (data.type === "log_diary" && !data.config?.field_data_key) { toast.error("Choose a diary field"); return; }
    if (data.type === "toggle_daily_task" && !data.config?.task_id) { toast.error("Choose a daily task"); return; }
    if (data.type === "start_activity" && !data.config?.category_id) { toast.error("Choose an activity category"); return; }
    if (data.type === "mark_contact_with" && !data.config?.contact_id) { toast.error("Choose a contact"); return; }
    if (data.type === "navigate_to_page" && !data.config?.page_id) { toast.error("Choose a page"); return; }
    onSave({ ...data, label: derivedLabel(), emoji: null });
  };

  return (
    <div className="space-y-3 p-3 bg-muted/20 rounded-xl border border-border/40">
      <div>
        <Label className="text-xs font-medium mb-1 block">Action type</Label>
        <select value={data.type} onChange={e => setType(e.target.value)}
          className="w-full h-9 px-2 rounded-lg border border-border/50 bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary">
          {actionTypes.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
        </select>
      </div>

      {(data.type === "set_front_alter" || data.type === "add_to_front_alter") && (
        <div>
          <Label className="text-xs font-medium mb-1 block">Which {terms.alter}?</Label>
          <AlterSearchSelect
            alters={activeAlters}
            value={data.config?.alter_id || null}
            onChange={id => setConfig("alter_id", id || "")}
            terms={terms}
            showNone={false}
            placeholder={`Select an ${terms.alter}…`}
          />
        </div>
      )}

      {data.type === "open_checkin_section" && (
        <div>
          <Label className="text-xs font-medium mb-1 block">Which section?</Label>
          <select value={data.config?.section || ""} onChange={e => setConfig("section", e.target.value)}
            className="w-full h-9 px-2 rounded-lg border border-border/50 bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary">
            <option value="">Select a section…</option>
            {CHECKIN_SECTIONS.map(s => <option key={s.id} value={s.id}>{s.id === "fronting" ? terms.Fronting : s.label}</option>)}
          </select>
        </div>
      )}

      {data.type === "log_activity" && (
        <div className="space-y-2">
          <div>
            <Label className="text-xs font-medium mb-1 block">Activity category</Label>
            <ActivityCategoryPicker categories={sortedCategories} selectedId={data.config?.category_id || ""} onChange={id => setConfig("category_id", id || undefined)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Duration (minutes, optional)</Label>
            <Input type="number" value={data.config?.duration_minutes || ""} onChange={e => setConfig("duration_minutes", e.target.value ? parseInt(e.target.value) : undefined)} placeholder="e.g. 15" className="h-8 text-sm" min="1" />
          </div>
        </div>
      )}

      {data.type === "start_activity" && (
        <div>
          <Label className="text-xs font-medium mb-1 block">Activity category</Label>
          <ActivityCategoryPicker categories={sortedCategories} selectedId={data.config?.category_id || ""} onChange={id => setConfig("category_id", id || undefined)} />
          <p className="text-xs text-muted-foreground mt-1">Starts an active timer immediately — no fronting picker, end it later from the dashboard.</p>
        </div>
      )}

      {data.type === "mark_contact_with" && (
        <div>
          <Label className="text-xs font-medium mb-2 block">Which contact?</Label>
          <ContactPicker contacts={contacts || []} selectedId={data.config?.contact_id} onChange={id => setConfig("contact_id", id)} />
          <p className="text-xs text-muted-foreground mt-1">Tapping this toggles them currently "with you" on or off.</p>
        </div>
      )}

      {data.type === "navigate_to_page" && (
        <div>
          <Label className="text-xs font-medium mb-2 block">Which page?</Label>
          <PagePicker selectedId={data.config?.page_id} onChange={id => setConfig("page_id", id)} />
        </div>
      )}

      {data.type === "toggle_sleep" && (
        <p className="text-xs text-muted-foreground">Starts sleep now if none is in progress, or ends the in-progress one — no config needed.</p>
      )}

      {data.type === "set_status_note" && (
        <p className="text-xs text-muted-foreground">Prompts for the status text when tapped — no config needed.</p>
      )}

      {data.type === "add_task" && (
        <p className="text-xs text-muted-foreground">Prompts for the to-do title when tapped — no config needed.</p>
      )}

      {data.type === "log_symptom" && (
        <div>
          <Label className="text-xs font-medium mb-2 block">Symptom / habit</Label>
          <SymptomPicker symptoms={activeSymptoms} selectedId={data.config?.symptom_id} onChange={id => setConfig("symptom_id", id)} />
        </div>
      )}

      {data.type === "log_emotion" && (
        <div>
          <Label className="text-xs font-medium mb-2 block">Emotion</Label>
          <EmotionPicker customEmotions={customEmotions} selectedLabel={data.config?.emotion_label || ""} onChange={lbl => setConfig("emotion_label", lbl || undefined)} />
        </div>
      )}

      {data.type === "log_diary" && (
        <div>
          <Label className="text-xs font-medium mb-1 block">Which diary field?</Label>
          {data.config?.field_label && (
            <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-primary/10 border border-primary/30 text-xs font-medium text-primary mb-2">
              {data.config.field_label}
              <span className="text-primary/60 ml-1">
                {data.config.field_type === "rating" ? `(0–${data.config.field_max})` : data.config.field_type === "boolean" ? "(Yes/No)" : "(Number)"}
              </span>
              <button onClick={() => setData(d => ({ ...d, config: {} }))} className="ml-auto text-primary/60 hover:text-primary"><X className="w-3 h-3" /></button>
            </div>
          )}
          <DiaryFieldPicker
            diaryGroups={diaryGroups}
            selectedGroupId={data.config?.group_id || ""}
            selectedFieldKey={data.config?.field_data_key || ""}
            onChange={(groupId, fieldDataKey, fieldType, fieldLabel, fieldMax) =>
              setData(d => ({ ...d, config: { group_id: groupId, field_data_key: fieldDataKey, field_type: fieldType, field_label: fieldLabel, field_max: fieldMax ?? null } }))}
          />
        </div>
      )}

      {data.type === "toggle_daily_task" && (
        <div>
          <Label className="text-xs font-medium mb-1 block">Which daily task?</Label>
          {dailyTaskTemplates && dailyTaskTemplates.length === 0 ? (
            <p className="text-xs text-muted-foreground">No manual daily tasks found. Add them via the Daily Tasks section.</p>
          ) : (
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {(dailyTaskTemplates || []).map(t => {
                const isSel = data.config?.task_id === t.id;
                return (
                  <button key={t.id} type="button" onClick={() => setConfig("task_id", t.id)}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl border text-sm transition-all text-left ${isSel ? "bg-primary/10 border-primary/40 text-primary font-medium" : "border-border/50 hover:bg-muted/40 text-foreground"}`}>
                    <span className="flex-1 truncate">{applyTerms(t.title, terms)}</span>
                    {t.points > 0 && <span className="text-xs text-muted-foreground flex-shrink-0">+{t.points} XP</span>}
                    {isSel && <Check className="w-3.5 h-3.5 flex-shrink-0 text-primary" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {data.type === "log_location" && (
        <div>
          <Label className="text-xs font-medium mb-2 block">Default category (optional)</Label>
          <div className="flex flex-wrap gap-1.5">
            {LOCATION_CATEGORIES.map(cat => {
              const isSel = data.config?.default_category === cat.id;
              return (
                <button key={cat.id} type="button" onClick={() => setConfig("default_category", isSel ? undefined : cat.id)}
                  className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-all ${isSel ? "text-white border-transparent" : "border-border/50 hover:border-primary/40"}`}
                  style={isSel ? { backgroundColor: cat.color } : {}}>
                  <span>{cat.emoji}</span> {cat.label}
                </button>
              );
            })}
          </div>
          <p className="text-xs text-muted-foreground mt-1">You can still change the category when logging.</p>
        </div>
      )}

      <div className="flex gap-2">
        <Button size="sm" onClick={handleSave} className="gap-1"><Check className="w-3.5 h-3.5" /> Save</Button>
        <Button size="sm" variant="ghost" onClick={onCancel} className="gap-1 text-muted-foreground"><X className="w-3.5 h-3.5" /> Cancel</Button>
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function QuickActionsConfig() {
  const queryClient = useQueryClient();
  const terms = useTerms();
  const [adding, setAdding] = useState(false);
  const [editId, setEditId] = useState(null);

  const { data: quickActions = [] } = useQuery({ queryKey: ["quickActions"], queryFn: () => base44.entities.QuickAction.list("order") });
  const { data: alters = [] } = useQuery({ queryKey: ["alters"], queryFn: () => base44.entities.Alter.list() });
  const { data: symptoms = [] } = useQuery({ queryKey: ["symptoms"], queryFn: () => base44.entities.Symptom.list() });
  const { data: activityCategories = [] } = useQuery({ queryKey: ["activityCategories"], queryFn: () => base44.entities.ActivityCategory.list() });
  const { data: customEmotions = [] } = useQuery({ queryKey: ["customEmotions"], queryFn: () => base44.entities.CustomEmotion.list() });
  const { data: diaryTemplates = [] } = useQuery({ queryKey: ["diaryTemplate"], queryFn: () => base44.entities.DiaryTemplate.list() });
  const { data: allTaskTemplates = [] } = useQuery({ queryKey: ["dailyTaskTemplates"], queryFn: () => base44.entities.DailyTaskTemplate.list("sort_order", 200) });
  const { data: contacts = [] } = useQuery({ queryKey: ["contacts"], queryFn: () => base44.entities.Contact.list() });
  const dailyTaskTemplates = useMemo(() => allTaskTemplates.filter(t => t.is_active !== false && t.mode === "MANUAL"), [allTaskTemplates]);
  const diaryGroups = useMemo(() => {
    const tpl = diaryTemplates[0];
    if (!tpl?.groups) return DEFAULT_GROUPS;
    return tpl.groups.filter(g => g.enabled !== false).sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [diaryTemplates]);

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["quickActions"] });

  const createMut = useMutation({
    mutationFn: data => base44.entities.QuickAction.create(data),
    onSuccess: () => { invalidate(); setAdding(false); toast.success("Shortcut added"); },
    onError: () => toast.error("Failed to save"),
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.QuickAction.update(id, data),
    onSuccess: () => { invalidate(); setEditId(null); toast.success("Updated"); },
    onError: () => toast.error("Failed to update"),
  });
  const deleteMut = useMutation({
    mutationFn: id => base44.entities.QuickAction.delete(id),
    onSuccess: () => { invalidate(); toast.success("Removed"); },
    onError: () => toast.error("Failed to remove"),
  });

  const sorted = [...quickActions].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const moveAction = async (index, dir) => {
    const target = sorted[index];
    const swap = sorted[index + dir];
    if (!swap) return;
    await Promise.all([
      base44.entities.QuickAction.update(target.id, { order: index + dir }),
      base44.entities.QuickAction.update(swap.id, { order: index }),
    ]);
    invalidate();
  };

  const handleAdd = formData => createMut.mutate({ label: formData.label, type: formData.type, emoji: null, config: formData.config || {}, order: sorted.length });
  const handleEdit = formData => updateMut.mutate({ id: editId, data: { label: formData.label, type: formData.type, emoji: null, config: formData.config || {} } });

  const typeLabel = type => ({
    open_checkin: "Open full Check-In",
    open_checkin_section: "Open at section",
    set_front_alter: `Set ${terms.alter} (replaces)`,
    add_to_front_alter: `Add ${terms.alter} to ${terms.front}`,
    log_activity: "Log activity",
    log_symptom: "Log symptom",
    log_emotion: "Log emotion",
    log_diary: "Log diary entry",
    log_location: "Log location",
    open_set_front: `Open Set ${terms.Front}ers`,
    toggle_daily_task: "Toggle daily task",
    view_grocery_list: "Grocery list",
    add_grocery_item: "Add to grocery list",
    start_activity: "Start activity",
    mark_contact_with: "Mark contact with you",
    toggle_sleep: "Start / end sleep",
    set_status_note: "Quick status",
    add_task: "Add a to-do",
    navigate_to_page: "Open a page",
  }[type] || type);

  return (
    <div data-tour="settings-quick-actions" className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold">Shortcuts</p>
          <p className="text-xs text-muted-foreground mt-0.5">Hold any key on the quick actions bar (or the apps button) to pop these up; on the classic dashboard, hold the Quick Check-In button.</p>
        </div>
        {!adding && (
          <Button size="sm" variant="outline" className="gap-1.5 flex-shrink-0" onClick={() => setAdding(true)}>
            <Plus className="w-3.5 h-3.5" /> Add
          </Button>
        )}
      </div>

      {adding && (
        <ActionForm alters={alters} symptoms={symptoms} activityCategories={activityCategories} customEmotions={customEmotions}
          diaryGroups={diaryGroups} dailyTaskTemplates={dailyTaskTemplates} contacts={contacts} terms={terms} onSave={handleAdd} onCancel={() => setAdding(false)} />
      )}

      {sorted.length === 0 && !adding && (
        <p className="text-xs text-muted-foreground italic px-1">No quick actions yet. Add some to speed up your logging workflow.</p>
      )}

      <div className="space-y-1.5">
        {sorted.map((action, i) => (
          <div key={action.id}>
            {editId === action.id ? (
              <ActionForm initialData={{ label: action.label, type: action.type, emoji: action.emoji || "", config: action.config || {} }}
                alters={alters} symptoms={symptoms} activityCategories={activityCategories} customEmotions={customEmotions}
                diaryGroups={diaryGroups} dailyTaskTemplates={dailyTaskTemplates} contacts={contacts} terms={terms} onSave={handleEdit} onCancel={() => setEditId(null)} />
            ) : (
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-muted/20 border border-border/30 group">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{action.label}</p>
                  <p className="text-xs text-muted-foreground">{typeLabel(action.type)}</p>
                </div>
                <div className="flex items-center gap-1 hover-reveal transition-opacity">
                  <button onClick={() => moveAction(i, -1)} disabled={i === 0} className="p-1 rounded hover:bg-muted disabled:opacity-30"><ChevronUp className="w-3.5 h-3.5" /></button>
                  <button onClick={() => moveAction(i, 1)} disabled={i === sorted.length - 1} className="p-1 rounded hover:bg-muted disabled:opacity-30"><ChevronDown className="w-3.5 h-3.5" /></button>
                  <button onClick={() => setEditId(action.id)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="w-3.5 h-3.5" /></button>
                  <button onClick={async () => { if ((await confirm(`Remove the quick action "${action.label}"?`))) deleteMut.mutate(action.id); }} className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
