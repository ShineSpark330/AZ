import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import DOMPurify from "dompurify";
import { blocksToHTML } from "@/components/shared/BlockEditor";
import { resolveImageUrl } from "@/lib/imageUrlResolver";
import { spoilersToHtml } from "@/lib/renderBulletinContent";
import { scopeBioStyles, bioHasStyle, rewriteInlineAnimations, sanitizeInlineStyleAttrs } from "@/lib/scopedBioStyle";

// Strip <style> blocks out of a single block's HTML — when scoping is active
// their CSS is hoisted (scoped) into one injected <style> at the container.
function stripStyleTags(html) {
  return (html || "").replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, "");
}

// The placeholder HTML is a hardcoded constant — sanitizing the dynamic content
// only. The placeholder string is repeated verbatim and contains only safe
// inline-styled <span>.
const PLACEHOLDER_HTML = '<span style="opacity:0.4;font-size:0.875rem;font-style:italic;">Tap a field to edit…</span>';

function sanitizeBlockHtml(html) {
  // Allow data-* attributes so internal-link / data-edit hooks keep working.
  // Also turn ||spoiler|| markers into censor bars (DOMPurify keeps the
  // class; the global tap handler + .spoiler CSS do the reveal).
  //
  // ADD_TAGS:["style"] — Raw mode is documented to support <style> blocks and
  // CSS animations, but DOMPurify strips <style> by default, so any bio using
  // @keyframes rendered as static (the animation: property survived but its
  // keyframes were gone). Allow <style>; DOMPurify still sanitises the CSS
  // (drops @import / expression() / javascript: url()), and arbitrary inline
  // styles — which can already restyle the page — are permitted anyway.
  // sanitizeInlineStyleAttrs runs FIRST: inline style="" attributes bypass
  // <style> scoping entirely, so their declarations get the same filter
  // (no position:fixed/sticky overlays, z-index clamp, url() allowlist).
  const clean = DOMPurify.sanitize(spoilersToHtml(sanitizeInlineStyleAttrs(html || "")), { ADD_ATTR: ["target", "data-log-type", "data-entity-id"], ADD_TAGS: ["style"] });
  // Make hard-coded px font sizes (common in pasted / imported bios) respond to
  // the accessibility Text size slider by converting them to rem — the same
  // visual size at the default scale, but now they grow/shrink with the slider.
  // Without this, such bios silently ignore the slider while the rest of the
  // page scales.
  return clean.replace(/font-size:\s*([\d.]+)px/gi, (_, n) => `font-size:${(parseFloat(n) / 16).toFixed(4)}rem`);
}

export default function SimplePreview({ blocks, onBlockChange, readOnly = false, scopeId = null }) {
  const navigate = useNavigate();
  const [editModal, setEditModal] = useState(null);
  const [editValue, setEditValue] = useState("");
  // Map of local-image:// URL -> resolved data URL for rendering
  const [resolvedImages, setResolvedImages] = useState({});

  // Both local forms need resolving — the /local-image/ SW path 404s on iOS
  // native (no service worker there), so never render it raw.
  const isLocalSrc = (s) => s?.startsWith("local-image://") || s?.startsWith("/local-image/");

  useEffect(() => {
    // Collect all image srcs from blocks that need resolution
    const srcs = new Set();
    for (const block of blocks) {
      if (isLocalSrc(block.src)) srcs.add(block.src);
      if (block.images) block.images.forEach(i => { if (isLocalSrc(i.src)) srcs.add(i.src); });
    }
    if (!srcs.size) return;
    let cancelled = false;
    Promise.all([...srcs].map(async url => {
      const resolved = await resolveImageUrl(url);
      return [url, resolved];
    })).then(pairs => {
      if (cancelled) return;
      setResolvedImages(prev => {
        const next = { ...prev };
        pairs.forEach(([url, resolved]) => { if (resolved) next[url] = resolved; });
        return next;
      });
    });
    return () => { cancelled = true; };
  }, [blocks]);

  // Resolve a src for rendering (falls back to original if not yet resolved)
  const resolveSrc = (src) => (isLocalSrc(src) ? resolvedImages[src] || "" : src);

  // Per-profile CSS scoping. Any <style> in a bio's blocks is extracted, its
  // selectors prefixed with `.${scopeClass}` and its @keyframes renamed per
  // profile, then injected once. This makes bio animations actually render on
  // the page AND keeps one profile's CSS from touching other profiles / the
  // app. When there's no <style>, this is a no-op (bodies render unchanged).
  const scoped = useMemo(() => {
    if (!scopeId) return null;
    const combined = (blocks || []).map((b) => b.content || b.text || "").join("\n");
    if (!bioHasStyle(combined)) return null;
    return scopeBioStyles(combined, scopeId);
  }, [blocks, scopeId]);

  // Body HTML for a block, with <style> stripped when scoping hoisted it and
  // inline animation refs pointed at the renamed (scoped) @keyframes.
  const bodyFor = (html) => (scoped ? rewriteInlineAnimations(stripStyleTags(html), scoped.renamed) : html);

  const handleClick = (e, block, field) => {
    // Check for internal link clicks (works in both read-only and edit mode)
    const linkEl = e.target.closest("[data-internal-link]");
    if (linkEl) {
      e.preventDefault();
      const route = linkEl.getAttribute("data-internal-link");
      if (route) navigate(route);
      return;
    }
    if (readOnly) return;
    // Only open editor when a [data-edit] span (template variable) is clicked
    const editSpan = e.target.closest("[data-edit]");
    if (editSpan) {
      // Capture the span's INDEX among this block's edit-spans so commit can
      // target the exact field even when several fields are blank or share
      // the same text (matching by text content alone hit the wrong field).
      const allSpans = [...e.currentTarget.querySelectorAll("[data-edit]")];
      const spanIndex = allSpans.indexOf(editSpan);
      setEditModal({ block, field, span: editSpan, spanIndex, mode: "span" });
      setEditValue(editSpan.textContent);
    }
    // Static template text outside spans is not editable here — clicking it does nothing
  };

  const commitEdit = () => {
    if (!editModal) return;
    const { block, field, span, spanIndex, mode } = editModal;
    const html = field === "content" ? block.content : block.text;

    if (mode === "span" && span) {
      // Replace just the text inside the specific data-edit span
      const tmp = document.createElement("div");
      tmp.innerHTML = html || "";
      const spans = tmp.querySelectorAll("[data-edit]");
      // Prefer the exact span by index (robust to blank/duplicate fields);
      // fall back to matching by original text content.
      let target = null;
      if (typeof spanIndex === "number" && spanIndex >= 0 && spanIndex < spans.length) {
        target = spans[spanIndex];
      } else {
        for (const s of spans) {
          if (s.textContent === span.textContent) { target = s; break; }
        }
      }
      if (target) {
        target.textContent = editValue;
        onBlockChange(block.id, { [field]: tmp.innerHTML });
      }
    }
    setEditModal(null);
  };

  return (
    <>
      {!readOnly && (
        <style>{`
          .sp-editable [data-edit] { cursor: pointer; text-decoration: underline; text-decoration-style: dotted; border-radius: 3px; padding: 0 2px; }
          .sp-editable [data-edit]:hover { background: rgba(99,102,241,0.12); }
        `}</style>
      )}
      {scoped?.styleCss && <style>{scoped.styleCss}</style>}
      <div className={[
        readOnly ? "wysiwyg-content space-y-2" : "wysiwyg-content sp-editable space-y-2 rounded-xl border border-input bg-background p-3 min-h-[200px]",
        scoped?.scopeClass || "",
      ].filter(Boolean).join(" ")}>
        {blocks.map(block => {
          if (block.type === "text") {
            return (
              <div key={block.id}
                onClick={(e) => handleClick(e, block, "content")}
                className="px-2 py-1 rounded-lg min-h-[24px]"
                dangerouslySetInnerHTML={{ __html: block.content ? sanitizeBlockHtml(bodyFor(block.content)) : (!readOnly ? PLACEHOLDER_HTML : '') }}
              />
            );
          }

          if (block.type === "img-left" || block.type === "img-right") {
            const isLeft = block.type === "img-left";
            return (
              <div key={block.id} className="flex gap-3 items-start"
                style={{ flexDirection: isLeft ? "row" : "row-reverse" }}>
                {block.src && (
                  <img src={resolveSrc(block.src)} alt={block.alt || ""}
                    style={block.cropped
                      ? { width: block.size || 120, height: block.size || 120, objectFit: "cover", borderRadius: 8, flexShrink: 0 }
                      : { width: block.size || 120, height: "auto", borderRadius: 8, flexShrink: 0 }} />
                )}
                <div onClick={(e) => handleClick(e, block, "text")}
                  className="flex-1 px-2 py-1 rounded-lg min-h-[40px]"
                  dangerouslySetInnerHTML={{ __html: block.text ? sanitizeBlockHtml(bodyFor(block.text)) : (!readOnly ? PLACEHOLDER_HTML : '') }} />
              </div>
            );
          }

          if (block.type === "img-solo") {
            const align = block.align || "left";
            const marginStyle = align === "center"
              ? { marginLeft: "auto", marginRight: "auto" }
              : align === "right"
              ? { marginLeft: "auto", marginRight: 0 }
              : { marginLeft: 0, marginRight: "auto" };
            return (
              <div key={block.id} style={{ margin: "8px 0", width: "100%" }}>
                <img src={resolveSrc(block.src)} alt={block.alt || ""}
                  style={{ display: "block", width: block.size || 240, height: block.cropped ? block.size || 240 : "auto", objectFit: block.cropped ? "cover" : undefined, borderRadius: 8, maxWidth: "100%", ...marginStyle }} />
              </div>
            );
          }

          // gallery block — render with resolved srcs
          if (block.type === "gallery") {
            const images = (block.images || []).filter(i => i.src);
            const maxH = block.maxHeight || 160;
            return (
              <div key={block.id} style={{ display: "flex", gap: 8, alignItems: "flex-start", margin: "8px 0", flexWrap: "wrap" }}>
                {images.map((img, idx) => (
                  <img key={idx} src={resolveSrc(img.src)} alt={img.alt || ""}
                    style={img.cropped
                      ? { height: maxH, width: maxH, objectFit: "cover", borderRadius: 8, flexShrink: 0 }
                      : { maxHeight: maxH, width: "auto", height: "auto", borderRadius: 8, flexShrink: 0 }} />
                ))}
              </div>
            );
          }

          // fallback for divider / raw / unknown — strip script tag before rendering
          const rawHtml = blocksToHTML([block]);
          const html = rawHtml.replace(/<script[^>]+data-blocks-json[^>]*>[\s\S]*?<\/script>/g, "")
            .replace(/^<div[^>]*>/, "").replace(/<\/div>$/, "");
          return (
            <div key={block.id}
              onClick={(e) => !readOnly && handleClick(e, block, "content")}
              style={{ width: "100%" }}
              dangerouslySetInnerHTML={{ __html: sanitizeBlockHtml(bodyFor(html)) }} />
          );
        })}
        {blocks.length === 0 && !readOnly && (
          <p className="text-muted-foreground text-sm italic px-1">No content yet. Switch to Blocks to add content.</p>
        )}
      </div>

      {!readOnly && editModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[80]">
          <div className="bg-background border-2 border-border rounded-2xl p-5 space-y-4 w-full max-w-md mx-4 shadow-2xl">
            <p className="text-sm font-medium">
              {editModal.mode === "span" ? "Edit field" : "Edit text"}
            </p>
            <textarea
              autoFocus
              value={editValue}
              onChange={e => setEditValue(e.target.value)}
              className="w-full min-h-[80px] px-3 py-2.5 rounded-xl border border-input bg-transparent text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-y leading-relaxed"
              spellCheck={true}
            />
            <div className="flex gap-2 justify-end">
              <button type="button" onClick={() => setEditModal(null)}
                className="px-4 py-2 rounded-xl bg-muted text-muted-foreground text-sm font-medium hover:bg-muted/80">
                Cancel
              </button>
              <button type="button" onClick={commitEdit}
                className="px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium">
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}