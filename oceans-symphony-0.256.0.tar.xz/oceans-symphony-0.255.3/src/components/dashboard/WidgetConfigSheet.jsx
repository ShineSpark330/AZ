// Per-widget advanced config for the experimental homescreen — a bottom
// sheet (vaul Drawer) hosted ONCE at ExperimentalDashboard level and keyed
// by the widget instanceId being configured. The caller derives the live
// widget from home state each render, so persisted changes flow straight
// back into the open sheet.
//
// Config: display name (settings.label), display mode (widget.mode), style
// override (settings.style — "inherit" clears it), and for app shortcuts a
// custom icon image (settings.iconUrl, picked via the shared asset picker).
//
// Widget-specific options are DECLARED, not hand-coded here: a registry
// entry can carry
//   configFields: [{ key, type: "text"|"textarea"|"toggle"|"select"|"number",
//                    label, placeholder, help, options: [{value,label}],
//                    min, max, default }]
// and this sheet renders them, writing straight to settings[key]. That's
// what lets the catalogue grow without this file growing with it.

import React from "react";
const WysiwygEditorLazy = React.lazy(() => import("@/components/shared/WysiwygEditor"));

// Rich text with a DEBOUNCED commit — the wysiwyg emits per keystroke and
// committing straight through would persist the whole board every letter.
// Local state is the truth while typing (never re-seeded from the prop —
// the "description won't delete" lesson); pending text flushes on unmount.
function RichTextField({ value, onCommit, placeholder }) {
  const [draft, setDraft] = React.useState(value || "");
  const timer = React.useRef(null);
  const pending = React.useRef(null);
  const commitRef = React.useRef(onCommit);
  commitRef.current = onCommit;
  React.useEffect(() => {
    const flushNow = () => {
      clearTimeout(timer.current);
      if (pending.current != null) { const v = pending.current; pending.current = null; commitRef.current(v); }
    };
    // Same as DebouncedText: write what was typed if the app is closed or
    // backgrounded with the editor still open.
    const onVisibility = () => { if (document.visibilityState === "hidden") flushNow(); };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", flushNow);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", flushNow);
      flushNow();
    };
  }, []);
  const change = (v) => {
    setDraft(v);
    pending.current = v;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => { pending.current = null; commitRef.current(v); }, 600);
  };
  return (
    <React.Suspense fallback={<div className="h-24 rounded-lg border border-input bg-background animate-pulse" />}>
      <WysiwygEditorLazy value={draft} onChange={change} placeholder={placeholder || "Write anything here…"} />
    </React.Suspense>
  );
}
import { Image as ImageIcon, X, Trash2, ChevronDown, ChevronUp, Check, RotateCcw, LayoutGrid, Palette, Settings2, Copy, Star, SlidersHorizontal, ArrowUpToLine, ArrowDownToLine, Type } from "lucide-react";
import PinnedAltersConfigPanel from "@/components/alters/PinnedAltersConfigPanel";
import IconPicker from "@/components/shared/IconPicker";
import { usePeekHeight, PeekHandle } from "@/components/v2/PeekResize";
import FontUploadButton from "@/components/shared/FontUploadButton";
import { DOCK_KEY } from "@/components/v2/V2Frame";
import UndoRedoButtons from "@/components/v2/UndoRedoHistory";
import { useFontOptions } from "@/lib/useFontOptions";
// Same collapsible section shell Display options uses, so the two editors
// read as one system rather than two conventions.
import { SubSection } from "@/components/settings/SettingsUI";
import { confirm } from "@/components/shared/ConfirmDialog";
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription,
} from "@/components/ui/drawer";
import { HOME_MODES, effectiveMode } from "@/lib/experimentalHome";
import { HOME_STYLES } from "@/lib/homeStyles";
import { useResolvedAvatarUrl } from "@/hooks/useResolvedAvatarUrl";
import { useTerms } from "@/lib/useTerms";
import { useTheme } from "@/lib/ThemeContext";
import AlterArrangementEditor from "@/components/shared/AlterArrangementEditor";
import { useAlterLabel } from "@/lib/useAlterLabel";
import { buildGridItems } from "@/lib/navCatalogue";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import ColorPicker from "@/components/shared/ColorPicker";
import { Switch } from "@/components/ui/switch";
import ProfileSongPicker from "@/components/shared/ProfileSongPicker";
import {
  themeToLook, BORDER_STYLES, SHADOW_PRESETS, USER_STYLE_PREFIX,
  LOOK_GROUPS, lookCoverage, lookForGroups, OFF, mergeLook, pickLook, userStyleId,
  FONT_STYLE_OPTIONS,
} from "@/lib/widgetLook";
import { getStyleLook } from "@/lib/homeStyles";
import { SearchableSelect } from "@/components/shared/SearchableSelect";
import { SearchableMultiList } from "@/v2/widgets";
import { widgetAutoLabel } from "@/lib/widgetRegistry";
import { sheetPortalGuards } from "@/lib/sheetPortalGuards";
import { applyTerms } from "@/lib/dailyTaskSystem";
import { resolveQuickButtons, QUICK_BUTTON_DEFS } from "@/components/dashboard/QuickCheckinButtons";
import LucideByName from "@/components/shared/LucideByName";

// Text inputs here commit as you type (debounced) AND flush on unmount.
// Committing only onBlur loses whatever was typed when the sheet is closed
// with Escape or the drag handle — the input unmounts without ever blurring,
// and the user's text is simply gone.
function DebouncedText({ value, onCommit, multiline, rows, maxLength, placeholder, className }) {
  const [local, setLocal] = React.useState(value ?? "");
  const timer = React.useRef(null);
  const pending = React.useRef(null);
  const commitRef = React.useRef(onCommit);
  commitRef.current = onCommit;

  React.useEffect(() => {
    const flushNow = () => {
      if (timer.current) { clearTimeout(timer.current); timer.current = null; }
      if (pending.current !== null) { const v = pending.current; pending.current = null; commitRef.current(v); }
    };
    // The Android back button can close the app outright, and a phone can
    // background it mid-typing; neither unmounts this field in time, so
    // the last few letters would never be written. Flush as the page hides.
    const onVisibility = () => { if (document.visibilityState === "hidden") flushNow(); };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", flushNow);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", flushNow);
      flushNow();
    };
  }, []);

  const change = (v) => {
    setLocal(v);
    pending.current = v;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      timer.current = null;
      const val = pending.current;
      pending.current = null;
      if (val !== null) commitRef.current(val);
    }, 350);
  };
  const flush = () => {
    if (timer.current) { clearTimeout(timer.current); timer.current = null; }
    if (pending.current !== null) { const v = pending.current; pending.current = null; onCommit(v); }
  };

  const props = {
    value: local, placeholder, maxLength, className,
    onChange: (e) => change(e.target.value),
    onBlur: flush,
  };
  return multiline ? <textarea {...props} rows={rows || 3} /> : <input {...props} />;
}

function AppListField({ value = [], onChange, terms }) {
  const [q, setQ] = React.useState("");
  const items = React.useMemo(() => buildGridItems(terms.Alters, terms.System), [terms.Alters, terms.System]);
  const needle = q.trim().toLowerCase();
  const shown = needle ? items.filter((i) => i.label.toLowerCase().includes(needle)) : items;
  const toggle = (id) => onChange(value.includes(id) ? value.filter((x) => x !== id) : [...value, id]);
  return (
    <div className="space-y-2">
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search apps…"
        className="w-full h-9 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
      <div className="max-h-56 overflow-y-auto overscroll-contain space-y-0.5 pr-1">
        {shown.map((i) => {
          const on = value.includes(i.id);
          const Icon = i.icon;
          return (
            <button key={i.id} type="button" onClick={() => toggle(i.id)}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg border text-left text-sm ${
                on ? "border-primary/60 bg-primary/10" : "border-transparent hover:bg-muted/40"
              }`}>
              <Icon className="w-4 h-4 flex-shrink-0 text-muted-foreground" />
              <span className="truncate flex-1">{i.label}</span>
              {on && <Check className="w-3.5 h-3.5 text-primary flex-shrink-0" />}
            </button>
          );
        })}
        {shown.length === 0 && <p className="text-xs text-muted-foreground px-1 py-2">No apps match that.</p>}
      </div>
    </div>
  );
}

// Pick-and-order list: each option has a checkbox and, while on, up/down
// arrows. Stores the array of enabled values in display order. Generic —
// the header widget's name/date/time uses it, and anything else whose
// config is "which of these, in what order".
function OrderToggleField({ field, value, onChange }) {
  const options = field.options || [];
  const stored = Array.isArray(value) ? value.filter((v) => options.some((o) => o.value === v)) : null;
  const enabled = stored && stored.length ? stored : (field.default || []);
  const rest = options.filter((o) => !enabled.includes(o.value));
  const move = (id, dir) => {
    const i = enabled.indexOf(id);
    const j = i + dir;
    if (i === -1 || j < 0 || j >= enabled.length) return;
    const next = [...enabled];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  const toggle = (id, on) => {
    if (on) onChange([...enabled, id]);
    else if (enabled.length > 1) onChange(enabled.filter((x) => x !== id));
  };
  const row = (o, on, idx) => (
    <div key={o.value} className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-border/40">
      <input type="checkbox" checked={on} disabled={on && enabled.length === 1}
        onChange={(e) => toggle(o.value, e.target.checked)}
        aria-label={o.label} className="w-4 h-4 rounded accent-primary flex-shrink-0" />
      <span className={`flex-1 text-sm truncate ${on ? "" : "text-muted-foreground"}`}>{o.label}</span>
      {on && (
        <span className="flex items-center gap-0.5 flex-shrink-0">
          <button type="button" aria-label={`Move ${o.label} up`} disabled={idx === 0}
            onClick={() => move(o.value, -1)}
            className="w-7 h-7 flex items-center justify-center rounded-lg border border-border/50 text-muted-foreground hover:text-foreground disabled:opacity-30">
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
          <button type="button" aria-label={`Move ${o.label} down`} disabled={idx === enabled.length - 1}
            onClick={() => move(o.value, 1)}
            className="w-7 h-7 flex items-center justify-center rounded-lg border border-border/50 text-muted-foreground hover:text-foreground disabled:opacity-30">
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </span>
      )}
    </div>
  );
  return (
    <div className="space-y-1">
      {enabled.map((id, idx) => { const o = options.find((x) => x.value === id); return o ? row(o, true, idx) : null; })}
      {rest.map((o) => row(o, false, -1))}
    </div>
  );
}

// The quick-action-buttons widget's per-button editor: toggle, reorder,
// rename and re-icon each button (any icon, or an uploaded image).
// Stores [{ id, on, label, iconName, iconUrl }].
function ButtonIconPreview({ iconUrl, iconName, Fallback }) {
  const src = useResolvedAvatarUrl(iconUrl || "");
  if (iconUrl && src) return <img src={src} alt="" className="w-4 h-4 rounded-[4px] object-cover" />;
  if (iconName) return <LucideByName name={iconName} className="w-4 h-4" fallback={<Fallback className="w-4 h-4" />} />;
  return <Fallback className="w-4 h-4" />;
}
function QuickButtonsField({ settings, onChange, terms }) {
  const buttons = resolveQuickButtons(settings);
  const [iconFor, setIconFor] = React.useState(null); // button id
  const onCount = buttons.filter((b) => b.on).length;
  const commit = (next) => onChange(next.map((b) => ({ id: b.id, on: b.on, label: b.label || "", iconName: b.iconName || "", iconUrl: b.iconUrl || "" })));
  const patch = (id, p) => commit(buttons.map((b) => (b.id === id ? { ...b, ...p } : b)));
  const move = (id, dir) => {
    const i = buttons.findIndex((b) => b.id === id);
    const j = i + dir;
    if (i === -1 || j < 0 || j >= buttons.length) return;
    const next = [...buttons];
    [next[i], next[j]] = [next[j], next[i]];
    commit(next);
  };
  return (
    <div className="space-y-1">
      {buttons.map((b, idx) => {
        const def = QUICK_BUTTON_DEFS.find((d) => d.id === b.id);
        if (!def) return null;
        const DefIcon = def.icon;
        const label = applyTerms(def.label, terms);
        return (
          <div key={b.id} className={`rounded-lg border px-2.5 py-1.5 space-y-1.5 ${b.on ? "border-border/50" : "border-border/30"}`}>
            <div className="flex items-center gap-2">
              <input type="checkbox" checked={b.on} disabled={b.on && onCount === 1}
                onChange={(e) => patch(b.id, { on: e.target.checked })}
                aria-label={label} className="w-4 h-4 rounded accent-primary flex-shrink-0" />
              <span className={`flex-1 text-sm truncate ${b.on ? "" : "text-muted-foreground"}`}>{b.label || label}</span>
              <span className="flex items-center gap-0.5 flex-shrink-0">
                <button type="button" aria-label={`Move ${label} up`} disabled={idx === 0}
                  onClick={() => move(b.id, -1)}
                  className="w-7 h-7 flex items-center justify-center rounded-lg border border-border/50 text-muted-foreground hover:text-foreground disabled:opacity-30">
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
                <button type="button" aria-label={`Move ${label} down`} disabled={idx === buttons.length - 1}
                  onClick={() => move(b.id, 1)}
                  className="w-7 h-7 flex items-center justify-center rounded-lg border border-border/50 text-muted-foreground hover:text-foreground disabled:opacity-30">
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>
              </span>
            </div>
            {b.on && (
              <div className="flex items-center gap-1.5 pl-6">
                <button type="button" onClick={() => setIconFor(b.id)}
                  aria-label={`${label} icon`}
                  className="w-8 h-8 flex items-center justify-center rounded-lg border border-border/50 text-muted-foreground hover:text-foreground flex-shrink-0">
                  <ButtonIconPreview iconUrl={b.iconUrl} iconName={b.iconName} Fallback={DefIcon} />
                </button>
                <DebouncedText value={b.label} placeholder={label} maxLength={40}
                  onCommit={(v) => { if (v !== b.label) patch(b.id, { label: v.trim() }); }}
                  className="flex-1 min-w-0 h-8 px-2.5 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
              </div>
            )}
          </div>
        );
      })}
      <IconPicker open={!!iconFor} onClose={() => setIconFor(null)}
        current={buttons.find((b) => b.id === iconFor)?.iconName || ""}
        onPick={(o) => { if (iconFor) patch(iconFor, { iconName: o.iconName || "", iconUrl: o.iconUrl || "" }); }} />
    </div>
  );
}

// The saved quick-action LIST (what press-and-hold on Quick Check-In
// opens) — the full Settings manager, hosted right in the widget's own
// config. Collapsed by default: it's a big panel.
const QuickActionsConfigLazy = React.lazy(() => import("@/components/settings/QuickActionsConfig"));
function QuickActionsManagerField({ label }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className="rounded-lg border border-border/40 overflow-hidden">
      <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open}
        className="w-full flex items-center justify-between px-3 py-2.5 bg-muted/15 hover:bg-muted/30 text-left text-sm font-medium">
        <span>{label}</span>
        <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="px-3 py-3 border-t border-border/30">
          <React.Suspense fallback={<div className="h-24 rounded-lg bg-muted/30 animate-pulse" />}>
            <QuickActionsConfigLazy />
          </React.Suspense>
        </div>
      )}
    </div>
  );
}

// Builder for "links to anywhere": journals, alters, groups — each added
// through a SEARCHABLE picker (house rule: large systems, no bare lists).
function LinksField({ value = [], onChange }) {
  const [kind, setKind] = React.useState("journal");
  const formatAlter = useAlterLabel();
  const { data: alters = [] } = useQuery({ queryKey: ["alters"], queryFn: () => base44.entities.Alter.list() });
  const { data: groups = [] } = useQuery({ queryKey: ["groups"], queryFn: () => base44.entities.Group.list() });
  const { data: entries = [] } = useQuery({ queryKey: ["journalEntries"], queryFn: () => base44.entities.JournalEntry.list() });
  const journals = React.useMemo(() => {
    const set = new Set(entries.map((e) => e.folder).filter(Boolean));
    try { JSON.parse(localStorage.getItem("os_journal_folders") || "[]").forEach((f) => set.add(f)); }
    catch { /* none saved */ }
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [entries]);

  const options = kind === "journal"
    ? journals.map((f) => ({ id: f, label: f }))
    : kind === "alter"
      ? alters.filter((a) => !a.is_archived).map((a) => ({ id: a.id, label: a.name || a.alias || "?" }))
      : groups.map((g) => ({ id: g.id, label: g.name || "Group" }));

  const labelFor = (l) => {
    if (l.type === "journal") return l.id;
    if (l.type === "alter") { const a = alters.find((x) => x.id === l.id); return a ? formatAlter(a) : "?"; }
    return groups.find((g) => g.id === l.id)?.name || "?";
  };

  return (
    <div className="space-y-2">
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {value.map((l, i) => (
            <span key={`${l.type}_${l.id}_${i}`}
              className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border border-border/60">
              <span className="text-muted-foreground">{l.type}:</span> {labelFor(l)}
              <button type="button" aria-label={`Remove ${labelFor(l)}`}
                onClick={() => onChange(value.filter((_, j) => j !== i))}
                className="text-muted-foreground hover:text-destructive"><X className="w-3 h-3" /></button>
            </span>
          ))}
        </div>
      )}
      <div className="flex gap-1.5">
        {[["journal", "Journal"], ["alter", "Member"], ["group", "Group"]].map(([v, label]) => (
          <button key={v} type="button" onClick={() => setKind(v)}
            className={`text-xs px-2.5 py-1 rounded-full border ${
              kind === v ? "border-primary/60 bg-primary/10 text-primary" : "border-border/50 text-muted-foreground"
            }`}>{label}</button>
        ))}
      </div>
      <SearchableSelect
        value={null}
        onChange={(id) => { if (id) onChange([...value, { type: kind, id }]); }}
        options={options.filter((o) => !value.some((l) => l.type === kind && l.id === o.id))}
        placeholder="Add a link…"
        searchPlaceholder="Search…"
      />
    </div>
  );
}

// Searchable group/subsystem picker (house rule: never a bare select —
// large systems have many groups).
function GroupField({ value, onChange }) {
  const { data: groups = [] } = useQuery({
    queryKey: ["groups"],
    queryFn: () => base44.entities.Group.list(),
  });
  const options = [
    { id: "", label: "Everyone" },
    ...groups.map((g) => ({ id: g.id, label: g.name || "Group" })),
  ];
  return (
    <SearchableSelect
      value={value}
      onChange={(v) => onChange(v)}
      options={options}
      placeholder="Everyone"
      searchPlaceholder="Search groups…"
    />
  );
}


// ── Dynamic-source fields ───────────────────────────────────────────
// The sheet must carry a widget's FULL functional config, not only its
// look (owner rule) — including choices whose options come from live data
// (chat channels, polls, journals, boards). In-widget switchers still
// exist for convenience, but widgets are inert in edit mode, so the sheet
// is the canonical place to configure them.
const DYNAMIC_SOURCES = {
  chatChannels: {
    queryKey: ["systemChatChannels"],
    queryFn: () => base44.entities.SystemChatChannel.list(),
    toOptions: (rows) => rows.map((c) => ({ id: c.id, label: `#${c.name}` })),
    searchPlaceholder: "Search channels…",
  },
  polls: {
    queryKey: ["polls"],
    queryFn: () => base44.entities.Poll.list(),
    toOptions: (rows) => [...rows]
      .sort((a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0))
      .map((p) => ({ id: p.id, label: p.question || "Poll" })),
    searchPlaceholder: "Search polls…",
  },
  journalFolders: {
    queryKey: ["journalEntries"],
    queryFn: () => base44.entities.JournalEntry.list(),
    toOptions: (rows) => {
      const set = new Set(rows.map((e) => e.folder).filter(Boolean));
      try { JSON.parse(localStorage.getItem("os_journal_folders") || "[]").forEach((f) => set.add(f)); } catch { /* none saved */ }
      return [...set].sort((a, b) => a.localeCompare(b)).map((f) => ({ id: f, label: f }));
    },
    searchPlaceholder: "Search journals…",
  },
  symptoms: {
    queryKey: ["symptoms"],
    queryFn: () => base44.entities.Symptom.list(),
    toOptions: (rows) => rows.filter((x) => !x.is_archived).map((x) => ({ id: x.id, label: x.label || x.name || "Symptom" })),
    searchPlaceholder: "Search symptoms…",
  },
  innerMaps: {
    queryKey: ["innerWorldMaps"],
    queryFn: () => base44.entities.InnerWorldMap.list(),
    toOptions: (rows) => rows.filter((m) => !m.is_archived)
      .sort((a, b) => (a.order || 0) - (b.order || 0))
      .map((m) => ({ id: m.id, label: m.name || "Map" })),
    searchPlaceholder: "Search maps…",
  },
  innerLayers: {
    queryKey: ["innerWorldLayersWithMaps"],
    queryFn: async () => {
      const [layers, maps] = await Promise.all([
        base44.entities.InnerWorldLayer.list(),
        base44.entities.InnerWorldMap.list(),
      ]);
      return { layers, maps };
    },
    toOptions: ({ layers = [], maps = [] } = {}) => {
      const mapName = Object.fromEntries(maps.map((m) => [m.id, m.name || "Map"]));
      return layers.map((l) => ({ id: l.id, label: `${mapName[l.map_id] || "Map"} · ${l.name || "Layer"}` }));
    },
    searchPlaceholder: "Search layers…",
  },
  boards: {
    fallback: ["system"],
    queryKey: ["groups"],
    queryFn: () => base44.entities.Group.list(),
    toOptions: (rows, terms) => [
      { id: "system", label: `${terms?.System || "System"} board` },
      ...rows.map((g) => ({ id: g.id, label: g.name || "Group" })),
    ],
    searchPlaceholder: "Search boards…",
  },
};

function DynamicSelectField({ field, value, onChange }) {
  const src = DYNAMIC_SOURCES[field.source];
  const { data: rows = [] } = useQuery({ queryKey: src.queryKey, queryFn: src.queryFn });
  const options = [
    ...(field.emptyLabel ? [{ id: "", label: field.emptyLabel }] : []),
    ...src.toOptions(rows),
  ];
  return (
    <SearchableSelect
      value={value || ""}
      onChange={(v) => onChange(v ?? "")}
      options={options}
      placeholder={field.emptyLabel || field.label}
      searchPlaceholder={src.searchPlaceholder}
    />
  );
}

function DynamicMultiField({ field, value = [], onChange, terms }) {
  const src = DYNAMIC_SOURCES[field.source];
  const { data: rows = [] } = useQuery({ queryKey: src.queryKey, queryFn: src.queryFn });
  const options = src.toOptions(rows, terms);
  // Some multi-fields must always hold something (a board widget with no
  // board is nothing); others treat empty as "use the default set".
  const fallback = field.fallback ?? src.fallback ?? [];
  const current = value.length ? value : fallback;
  return (
    <SearchableMultiList
      options={options}
      selectedIds={current}
      onToggle={(id) => {
        const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
        onChange(next.length ? next : fallback);
      }}
      searchPlaceholder={src.searchPlaceholder}
    />
  );
}

const MODE_LABEL = { minimal: "Minimal", normal: "Normal", expanded: "Expanded", detailed: "Detailed" };

// The colour pickers used to fall back to hardcoded hexes, so before you
// customised anything they showed a generic blue/grey rather than the
// colour actually on screen — which makes "nudge this slightly" impossible.
// Read the live widget's computed colours instead and seed the pickers with
// those. Probed once per sheet-open.
// `revision` re-probes whenever the widget's look changes (a preset
// applied, a colour cleared) — read once on open, the swatches went stale
// and disagreed with the widget under them.
function useLiveColors(open, instanceId, revision = "") {
  const [tick, setTick] = React.useState(0);
  // The DOM repaints AFTER the settings write; probe on the next frame.
  React.useEffect(() => {
    if (!open) return undefined;
    const id = requestAnimationFrame(() => setTick((t) => t + 1));
    return () => cancelAnimationFrame(id);
  }, [open, revision]);
  return React.useMemo(() => {
    if (!open || typeof document === "undefined") return {};
    const toHex = (c) => {
      const str = String(c || "");
      const m = str.match(/[\d.]+/g);
      if (!m || m.length < 3) return null;
      let [r, g, b] = m.map(Number);
      const a = m.length > 3 ? Number(m[3]) : 1;
      if (a === 0) return null; // transparent tells us nothing
      // Chrome reports modern colours as `color(srgb 1 0 0 / .25)` with
      // 0-1 components — scaling those as 0-255 gave near-black swatches.
      if (/^color\(/i.test(str)) { r *= 255; g *= 255; b *= 255; }
      const clamp = (x) => Math.max(0, Math.min(255, Math.round(x)));
      return "#" + [r, g, b].map((x) => clamp(x).toString(16).padStart(2, "0")).join("");
    };
    const wrap = instanceId ? document.querySelector(`[data-widget-id="${instanceId}"]`) : null;
    const box = wrap?.querySelector("section") || wrap?.querySelector("[data-widget-content]") || wrap;
    const root = getComputedStyle(document.documentElement);
    const body = getComputedStyle(document.body);
    const cs = box ? getComputedStyle(box) : null;
    const accentVar = (root.getPropertyValue("--v2-accent") || root.getPropertyValue("--color-primary") || "").trim();
    const num = (v, fallback) => { const n = parseFloat(v); return Number.isFinite(n) ? Math.round(n) : fallback; };
    return {
      bg: (cs && toHex(cs.backgroundColor)) || toHex(body.backgroundColor) || undefined,
      textColor: (cs && toHex(cs.color)) || toHex(body.color) || undefined,
      borderColor: (cs && toHex(cs.borderTopColor)) || undefined,
      accent: accentVar.startsWith("#") ? accentVar : undefined,
      // Shape and type are probed too, because "save this look as a style"
      // has to capture what the widget ACTUALLY looks like. Most widgets
      // store no radius/border/font of their own — those come from the app
      // theme through CSS and never appear in the look object, so saving
      // from stored values alone produced a style that set almost nothing.
      radius: cs ? num(cs.borderTopLeftRadius, undefined) : undefined,
      // The box's measured border is the OUTLINE now (Border width means
      // the widget's inner borders since v0.239.0).
      outlineW: cs ? num(cs.borderTopWidth, undefined) : undefined,
      borderStyle: cs && cs.borderTopStyle !== "none" ? cs.borderTopStyle : undefined,
      padding: cs ? num(cs.paddingTop, undefined) : undefined,
      shadow: cs && cs.boxShadow && cs.boxShadow !== "none" ? cs.boxShadow : "none",
      font: cs?.fontFamily || undefined,
      fontScale: 100,
    };
     
  }, [open, instanceId, tick]);
}

// Mirrors the TokenRow slider in Display options (− / range / + / readout)
// so both editors handle a size the same way, plus this sheet's own Reset
// (a widget value can be unset = follow the app).
function SliderRow({ label, value, fallback, min, max, step = 1, unit = "px", onChange, onReset }) {
  // Edit-menu anatomy (docs/v2-edit-menu-spec.md): the row shows its name,
  // current value and a visible "set" button; the slider only exists after
  // that explicit tap, so a scroll through the sheet can't move a setting.
  const [open, setOpen] = React.useState(false);
  const unset = value === undefined || value === "";
  const shown = unset ? "app default" : `${value}${unit}`;
  const current = unset ? fallback : Number(value);
  const bump = (dir) => onChange(Math.min(max, Math.max(min, current + dir * step)));
  return (
    <div className="py-1">
      <div className="flex items-center gap-2">
        <span className="text-xs font-medium flex-1 min-w-0 truncate">{label}</span>
        <span className="text-xs text-muted-foreground tabular-nums flex-shrink-0">{shown}</span>
        <button type="button" aria-label={`${label} — set`} aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className={`w-8 h-8 flex items-center justify-center rounded-lg border flex-shrink-0 ${
            open ? "border-primary/60 text-primary" : "border-border/60 text-muted-foreground hover:text-foreground"
          }`}>
          <SlidersHorizontal className="w-3.5 h-3.5" />
        </button>
      </div>
      {open && (
        <div className="flex items-center gap-2 pt-1.5">
          <button type="button" aria-label={`${label} −`} onClick={() => bump(-1)}
            className="w-7 h-7 rounded-lg border border-border/60 text-muted-foreground hover:text-foreground flex items-center justify-center text-sm leading-none flex-shrink-0">−</button>
          <input type="range" min={min} max={max} step={step} value={current}
            onChange={(e) => onChange(parseInt(e.target.value, 10))}
            className="flex-1" aria-label={label} />
          <button type="button" aria-label={`${label} +`} onClick={() => bump(1)}
            className="w-7 h-7 rounded-lg border border-border/60 text-muted-foreground hover:text-foreground flex items-center justify-center text-sm leading-none flex-shrink-0">+</button>
          {onReset && (
            <button type="button" onClick={onReset}
              className="text-xs px-2 py-1 rounded-full border border-border/50 text-muted-foreground flex-shrink-0 whitespace-nowrap">Reset</button>
          )}
        </div>
      )}
    </div>
  );
}

export default function WidgetConfigSheet({
  widget,            // live widget object or null (sheet closed)
  def,               // registry entry for widget.widgetId
  pageStyleId,       // the page's style (shown as the "inherit" hint)
  onClose,
  onMode,            // (instanceId, mode)
  onSettings,        // (instanceId, patch)
  onPickIcon,        // (instanceId) → opens the shared AssetPickerModal
  onRemove,          // (instanceId) → delete this widget
  onResetWidget,     // (instanceId) → back to registry defaults
  onEditLayout,      // () → turn on home-screen edit mode (move/resize)
  onApplyLook,       // (scope: "all" | "page" | "pick") → copy this look out
  resolvedLook = {}, // what this widget actually looks like right now
  userStyles = [],   // the user's own saved styles
  onSaveStyle,       // (label, look) → save the current look as a style
  onDeleteStyle,     // (styleId)
  onPickBackground,  // (instanceId) → opens the shared AssetPickerModal
  onRestoreSnapshot, // (instanceId, { mode, settings }) → put the widget back how it was when the sheet opened
}) {
  const open = !!widget && !!def;
  // Everything in this sheet applies live, so closing used to just keep
  // whatever happened — including accidents. Snapshot the widget as the
  // sheet opens; closing with changes asks Keep / Undo / Keep editing
  // (the same guard the planner's editor got). One component, so every
  // surface that hosts this menu — board, home screen, desktop, the
  // pinned-bar config — gets the guard at once.
  const openSnap = React.useRef(null);
  const [closeAsk, setCloseAsk] = React.useState(false);
  React.useEffect(() => {
    if (!widget?.instanceId) { openSnap.current = null; setCloseAsk(false); return; }
    if (openSnap.current?.id === widget.instanceId) return;
    openSnap.current = {
      id: widget.instanceId,
      mode: widget.mode,
      settings: JSON.parse(JSON.stringify(widget.settings || {})),
    };
    setCloseAsk(false);
  }, [widget?.instanceId]);
  const editorDirty = () => {
    const snap = openSnap.current;
    if (!snap || snap.id !== widget?.instanceId) return false;
    return snap.mode !== widget.mode
      || JSON.stringify(widget.settings || {}) !== JSON.stringify(snap.settings);
  };
  const requestClose = () => {
    if (editorDirty() && onRestoreSnapshot) setCloseAsk(true);
    else onClose();
  };
  const undoAndClose = () => {
    const snap = openSnap.current;
    if (snap && snap.id === widget?.instanceId) {
      onRestoreSnapshot?.(snap.id, { mode: snap.mode, settings: snap.settings });
    }
    setCloseAsk(false);
    onClose();
  };
  const live = useLiveColors(open, widget?.instanceId, JSON.stringify(widget?.settings || {}) + (pageStyleId || ""));
  const [styleOpen, setStyleOpen] = React.useState(false);
  const [builtinOpen, setBuiltinOpen] = React.useState(false);
  const [themesOpen, setThemesOpen] = React.useState(false);
  const [cssOpen, setCssOpen] = React.useState(false);
  const [advOpen, setAdvOpen] = React.useState(false);
  const [naming, setNaming] = React.useState(false);
  const [applyOpen, setApplyOpen] = React.useState(false);
  const [styleName, setStyleName] = React.useState("");
  // Which parts of the look a saved style should carry. All of them by
  // default — a preset that covers everything needs no caveats.
  const [saveGroups, setSaveGroups] = React.useState(LOOK_GROUPS.map((g) => g.id));
  const [exclusionsFor, setExclusionsFor] = React.useState(null); // style id
  // Always drag-resizable (the grab bar is the size control — no separate
  // Peek mode); height shared with Display options. The page never dims
  // under it: settings apply live and watching the widget is the point.
  const peekResize = usePeekHeight("symphony_options_peek_h", 85);
  const peekH = peekResize.peekH;
  React.useEffect(() => {
    if (!open) return undefined;
    document.documentElement.setAttribute("data-v2-peek", "1");
    // Bring the widget being styled into the visible strip above the sheet.
    const node = widget && document.querySelector(`[data-widget-id="${widget.instanceId}"]`);
    node?.scrollIntoView({ block: "start", behavior: "smooth" });
    return () => document.documentElement.removeAttribute("data-v2-peek");
  }, [open, widget]);
  // Dock top/bottom — same flip (and same remembered choice) as the other
  // edit sheets, so a widget near the bottom edge isn't hidden under its
  // own options.
  const [dock, setDock] = React.useState(() => {
    try { return localStorage.getItem(DOCK_KEY) === "top" ? "top" : "bottom"; } catch { return "bottom"; }
  });
  const flipDock = () => {
    const next = dock === "top" ? "bottom" : "top";
    setDock(next);
    try { localStorage.setItem(DOCK_KEY, next); } catch { /* storage off */ }
  };
  const settings = widget?.settings || {};
  const iconPreview = useResolvedAvatarUrl(settings.iconUrl || "");
  const [iconPickerOpen, setIconPickerOpen] = React.useState(false);
  const fontOptions = useFontOptions();
  // Classic Appearance themes, offered as widget looks.
  const { allPresets = {}, userCustomPresets = {} } = useTheme() || {};
  // Which half of a theme to translate — the live document class is the
  // honest signal (themeMode can be "system").
  const isDarkMode = typeof document !== "undefined" && document.documentElement.classList.contains("dark");
  const themeLookEntries = React.useMemo(() => [
    ...Object.entries(userCustomPresets).map(([name, preset]) => ({ name, preset, mine: true })),
    ...Object.entries(allPresets).map(([name, preset]) => ({ name, preset, mine: false })),
  ].filter(({ preset }) => preset && (preset.light || preset.dark)), [allPresets, userCustomPresets]);
  const t = useTerms();
  if (!open) return null;

  const defLabel = widgetAutoLabel(def, settings, t);
  // Setting an opacity on a colour the widget only INHERITS has nothing to
  // fade, so pin the live colour at the same time — otherwise the slider
  // moves and nothing happens.
  const setAlpha = (colorKey, opacityKey, value, fallbackColor) =>
    onSettings(widget.instanceId, {
      [opacityKey]: value,
      ...(settings[colorKey] ? {} : { [colorKey]: fallbackColor }),
    });
  // OFF is a real stored value ("this style has no gradient"), not a colour.
  const gradHex = (v) => (v && v !== OFF ? v : "");
  // The gradient the widget is ACTUALLY drawing = the built-in / saved
  // style underneath, the widget's own fields on top (the same merge
  // widgetLookFor does). The pickers used to show only the widget's own
  // fields, so with a style applied they sat on default colours while the
  // widget showed the style's gradient (the user's report).
  const effective = (() => {
    const st = settings.style;
    const savedId = userStyleId(st);
    const saved = savedId ? userStyles.find((x) => x.id === savedId) : null;
    const builtinId = HOME_STYLES.some((h) => h.id === st) ? st : pageStyleId;
    return mergeLook(mergeLook(getStyleLook(builtinId), saved?.look || {}), pickLook(settings));
  })();
  const gradOn = gradHex(effective.gradFrom) && gradHex(effective.gradTo);
  // A style can carry "no custom CSS" as an explicit value; that's an
  // empty editor, not the literal word.
  const ownCss = settings.css && settings.css !== OFF ? settings.css : "";

  const saveStyle = () => {
    const label = styleName.trim();
    if (!label || saveGroups.length === 0) return;
    // Save from what the widget actually LOOKS like, not only the keys it
    // happens to store — a colour inherited from the page style is still
    // part of the look the user is naming.
    onSaveStyle?.(label.slice(0, 40), lookForGroups(resolvedLook, settings, saveGroups, live));
    setNaming(false);
    setStyleName("");
  };
  // Host-added modes (def.extraModes — e.g. the classic home's "Classic")
  // aren't in HOME_MODES, so effectiveMode would coerce them away and the
  // wrong pill would highlight. They pass through as-is.
  const mode = (def.extraModes || []).some((x) => x.id === widget.mode)
    ? widget.mode
    : effectiveMode(widget.mode, def.supportsModes);
  const styleOverride = HOME_STYLES.some((s) => s.id === settings.style) ? settings.style : "";
  const pageStyleLabel = HOME_STYLES.find((s) => s.id === pageStyleId)?.label || "Current";

  return (
    <Drawer key={dock} direction={dock} open={open} modal={false} onOpenChange={(v) => { if (!v) requestClose(); }}>
      <DrawerContent direction={dock} hideHandle
        style={{ maxHeight: `${peekH}vh`, height: `${peekH}vh` }} {...sheetPortalGuards}>
        {/* The grab bar IS the resize handle — every sheet is always
            drag-resizable (no separate Peek mode). */}
        <PeekHandle resize={peekResize} dock={dock} />
        {/* Close guard: changes here apply live, so leaving with edits
            asks what to do with them instead of silently keeping them. */}
        {closeAsk && (
          <div className="absolute inset-0 z-50 bg-background/85 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="w-full max-w-xs rounded-2xl border border-border/60 bg-card p-4 space-y-3 shadow-xl">
              <p className="text-sm font-semibold">Keep these changes?</p>
              <p className="text-xs text-muted-foreground">You changed this widget while the menu was open.</p>
              <div className="space-y-1.5">
                <button type="button" onClick={() => { setCloseAsk(false); onClose(); }}
                  className="w-full h-10 rounded-lg bg-primary text-primary-foreground text-sm font-medium">
                  Keep changes
                </button>
                <button type="button" onClick={undoAndClose}
                  className="w-full h-10 rounded-lg border border-border/60 text-sm font-medium hover:bg-muted/50">
                  Undo my changes
                </button>
                <button type="button" onClick={() => setCloseAsk(false)}
                  className="w-full h-10 rounded-lg border border-border/60 text-sm text-muted-foreground hover:bg-muted/50">
                  Keep editing
                </button>
              </div>
            </div>
          </div>
        )}
        <DrawerHeader className="pb-1">
          <div className="flex items-start justify-between gap-2">
            <span className="flex items-center gap-2 min-w-0">
              {/* The standard close chevron — points the way the sheet leaves. */}
              <button type="button" onClick={requestClose} aria-label="Close"
                className="p-1 -ml-1 rounded-lg text-muted-foreground hover:text-foreground flex-shrink-0">
                {dock === "top" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              <DrawerTitle className="text-base truncate">{settings.label || defLabel}</DrawerTitle>
              <DrawerDescription className="sr-only">Widget options</DrawerDescription>
            </span>
            <span className="flex items-center gap-1.5 flex-shrink-0">
            <UndoRedoButtons />
            <button type="button" onClick={flipDock}
              aria-label="Move this panel to the other edge" title="Move this panel to the other edge"
              className="flex items-center justify-center w-8 h-8 rounded-lg border border-border/60 text-muted-foreground hover:text-foreground">
              {dock === "top" ? <ArrowDownToLine className="w-3.5 h-3.5" /> : <ArrowUpToLine className="w-3.5 h-3.5" />}
            </button>
            </span>
          </div>
        </DrawerHeader>
        <div
          className="px-4 pb-6 space-y-4 overflow-y-auto overscroll-contain flex-1 min-h-0"
          // Bottom-nav height included: on pages where the classic bottom
          // bar is up, the sheet's last rows were hidden behind it.
          style={{ paddingBottom: "calc(var(--os-sab) + var(--bottom-nav-height, 0px) + 24px)" }}
        >
          {/* Rename */}
          {/* First thing in the sheet — moving is the most common intent
              when you hold a widget (the user's call). */}
          {onEditLayout && (
            <button
              type="button"
              onClick={onEditLayout}
              className="w-full flex items-center justify-center gap-2 h-10 rounded-lg border border-border/60 text-sm font-medium hover:bg-muted/50"
            >
              <LayoutGrid className="w-4 h-4" /> Move &amp; resize widgets
            </button>
          )}
          <div>
            <label className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground block mb-1">
              Display name
            </label>
            <DebouncedText
              key={widget.instanceId}
              value={settings.label || ""}
              placeholder={defLabel}
              maxLength={60}
              onCommit={(v) => {
                const next = v.trim();
                if (next !== (settings.label || "")) onSettings(widget.instanceId, { label: next });
              }}
              className="w-full h-9 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
            />
          </div>

          <SubSection title="Widget config" icon={Settings2}>
          {/* Widget-specific options, declared by the registry entry. A
              field with section:"ui" (a size, a shape) renders under UI &
              text instead — config is WHAT the widget shows. */}
          {(def.configFields || []).filter((f) => f.section !== "ui").map((f) => {
            // showIf: a field only appears when it means something for the
            // current settings — the cure for option-soup config sheets.
            if (typeof f.showIf === "function" && !f.showIf(settings)) return null;
            if (f.type === "pinnedAlters") return <PinnedAltersConfigPanel key={f.key} />;
            if (f.type === "quickButtons") {
              return (
                <QuickButtonsField key={f.key} settings={settings} terms={t}
                  onChange={(next) => onSettings(widget.instanceId, { [f.key]: next })} />
              );
            }
            if (f.type === "quickActionsManager") {
              return <QuickActionsManagerField key={f.key} label={applyTerms(f.label, t)} />;
            }
            const val = settings[f.key] ?? f.default ?? "";
            const commit = (v) => onSettings(widget.instanceId, { [f.key]: v });
            return (
              <div key={f.key}>
                {f.type !== "toggle" && (
                  <label className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground block mb-1">
                    {applyTerms(f.label, t)}
                  </label>
                )}
                {f.type === "text" && (
                  <DebouncedText key={`${widget.instanceId}:${f.key}`} value={val} placeholder={f.placeholder ? applyTerms(f.placeholder, t) : undefined}
                    maxLength={f.maxLength || 120} onCommit={(v) => { if (v !== val) commit(v); }}
                    className="w-full h-9 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
                )}
                {f.type === "orderToggle" && (
                  <OrderToggleField field={f} value={val} onChange={commit} />
                )}
                {f.type === "richtext" && (
                  /* THE full editor — same WysiwygEditor + MiniToolbar the
                     journals and bios use, so text widgets can carry colours,
                     fonts, images and in-app link buttons (owner spec:
                     "utilize all full formatting functionality"). */
                  <RichTextField key={`${widget.instanceId}:${f.key}`} value={val}
                    onCommit={(v) => { if (v !== val) commit(v); }} placeholder={f.placeholder} />
                )}
                {f.type === "textarea" && (
                  <DebouncedText key={`${widget.instanceId}:${f.key}`} value={val} placeholder={f.placeholder}
                    multiline rows={f.rows || 3} maxLength={f.maxLength || 2000}
                    onCommit={(v) => { if (v !== val) commit(v); }}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm resize-y focus:outline-none focus:ring-1 focus:ring-ring" />
                )}
                {f.type === "toggle" && (
                  <label className="flex items-center justify-between gap-3 text-sm cursor-pointer">
                    <span>{applyTerms(f.label, t)}</span>
                    <input type="checkbox" checked={val !== false && val !== ""} onChange={(e) => commit(e.target.checked)}
                      className="w-4 h-4 rounded accent-primary" />
                  </label>
                )}
                {f.type === "select" && (
                  <div className="flex flex-wrap gap-1.5">
                    {(f.options || []).map((o) => (
                      <button key={o.value} type="button" onClick={() => commit(o.value)}
                        className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                          String(val) === String(o.value)
                            ? "border-primary/60 bg-primary/10 text-primary"
                            : "border-border/50 text-muted-foreground hover:text-foreground"
                        }`}>
                        {o.label}
                      </button>
                    ))}
                  </div>
                )}
                {/* Static multi-pick: same chips as select, but each toggles
                    membership in an array (e.g. which task sets a widget shows). */}
                {f.type === "multi" && (
                  <div className="flex flex-wrap gap-1.5">
                    {(f.options || []).map((o) => {
                      const arr = Array.isArray(val) ? val : (val != null ? [val] : []);
                      const on = arr.some((x) => String(x) === String(o.value));
                      return (
                        <button key={o.value} type="button" aria-pressed={on}
                          onClick={() => commit(on ? arr.filter((x) => String(x) !== String(o.value)) : [...arr, o.value])}
                          className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                            on ? "border-primary/60 bg-primary/10 text-primary" : "border-border/50 text-muted-foreground hover:text-foreground"
                          }`}>
                          {o.label}
                        </button>
                      );
                    })}
                  </div>
                )}
                {f.type === "dynamicSelect" && (
                  <DynamicSelectField field={f} value={val} onChange={commit} />
                )}
                {f.type === "arrangement" && (
                  <AlterArrangementEditor value={Array.isArray(val) ? val : []} onChange={commit} />
                )}
                {f.type === "symptoms" && (
                  <DynamicMultiField field={{ ...f, source: "symptoms" }} value={Array.isArray(val) ? val : []}
                    onChange={commit} terms={t} />
                )}
                {f.type === "dynamicMulti" && (
                  <DynamicMultiField field={f} value={Array.isArray(val) ? val : []} onChange={commit} terms={t} />
                )}
                {f.type === "links" && (
                  <LinksField value={Array.isArray(val) ? val : []} onChange={(next) => commit(next)} />
                )}
                {f.type === "group" && (
                  <GroupField value={val || ""} onChange={(v) => commit(v || "")} />
                )}
                {f.type === "apps" && (
                  <AppListField value={Array.isArray(val) ? val : []}
                    onChange={(next) => commit(next)} terms={t} />
                )}
                {/* A range reads as "drag me"; a number box reads as "type an
                    exact value", which is the wrong affordance for a size. */}
                {f.type === "song" && (
                  <ProfileSongPicker value={val || null} onChange={(v) => commit(v)} subjectLabel="page" />
                )}
                {f.type === "range" && (
                  <div>
                    <input type="range" value={Number(val) || 0}
                      min={f.min ?? 0} max={f.max ?? 100} step={f.step ?? 1}
                      onChange={(e) => commit(Number(e.target.value))}
                      aria-label={f.label}
                      className="w-full accent-primary" />
                    <span className="text-[0.6875rem] text-muted-foreground">
                      {f.format ? f.format(Number(val) || 0) : `${Number(val) || 0}${f.unit || "px"}`}
                    </span>
                  </div>
                )}
                {f.type === "number" && (
                  <input type="number" key={`${widget.instanceId}:${f.key}`} defaultValue={val}
                    min={f.min} max={f.max}
                    onBlur={(e) => {
                      const n = parseInt(e.target.value, 10);
                      if (!Number.isNaN(n)) commit(Math.min(f.max ?? 99, Math.max(f.min ?? 0, n)));
                    }}
                    className="w-24 h-9 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
                )}
                {f.help && <p className="text-[0.6875rem] text-muted-foreground mt-1">{f.help}</p>}
              </div>
            );
          })}

          </SubSection>
          {/* Appearance overrides, in the unified edit-menu anatomy
              (docs/v2-edit-menu-spec.md): UI size / Colors / Background /
              Presets, each a chevron section, sliders behind set buttons.
              These write CSS variables onto the widget wrapper, so the
              whole-app settings apply by default and this widget alone
              departs from them where the user says so. */}
          <SubSection title="UI & text" icon={Type} defaultOpen>
          {/* Same set-then-slide row as every other size here — a bare
              slider moved on a scroll through the sheet (the report). */}
          <SliderRow label="Content size" value={settings.controlScale} fallback={100}
            min={60} max={200} step={5} unit="%"
            onChange={(v) => onSettings(widget.instanceId, { controlScale: v })}
            onReset={() => onSettings(widget.instanceId, { controlScale: "" })} />
          {/* Layout (mode / across / down / content size) lives here with type
              and shape — one standard section, not two (the user's call). */}

          {/* Display mode. `def.extraModes` lets a HOST add modes of its
              own — the classic home offers "Classic" (the untouched
              classic card) ahead of the board modes. */}
          {(def.supportsModes.length > 1 || (def.extraModes || []).length > 0) && (
            <div>
              <label className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground block mb-1">
                Display mode
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  ...(def.extraModes || []).map((x) => x.id),
                  ...HOME_MODES.filter((m) => def.supportsModes.includes(m)),
                ].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => onMode(widget.instanceId, m)}
                    className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                      m === mode
                        ? "border-primary/60 bg-primary/10 text-primary"
                        : "border-border/50 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {(def.extraModes || []).find((x) => x.id === m)?.label || MODE_LABEL[m]}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Content alignment within the widget's box. Centered by
              default; overflowing content still starts at the top. */}
          <p className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground">Alignment</p>
          <div>
            <label className="text-xs font-medium block mb-1">Horizontal</label>
            <div className="flex flex-wrap gap-1.5">
              {[["stretch", "Fill"], ["left", "Left"], ["center", "Center"], ["right", "Right"]].map(([v, label]) => (
                <button key={v} type="button"
                  onClick={() => onSettings(widget.instanceId, { halign: v })}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                    (settings.halign || "stretch") === v
                      ? "border-primary/60 bg-primary/10 text-primary"
                      : "border-border/50 text-muted-foreground hover:text-foreground"
                  }`}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-medium block mb-1">Vertical</label>
            <div className="flex flex-wrap gap-1.5">
              {[["top", "Top"], ["center", "Center"], ["bottom", "Bottom"]].map(([v, label]) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => onSettings(widget.instanceId, { valign: v })}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                    (settings.valign || "center") === v
                      ? "border-primary/60 bg-primary/10 text-primary"
                      : "border-border/50 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Scales everything the widget draws (rows, buttons, avatars,
              spacing), on top of whatever text size is set. */}

          {/* Size / shape fields a widget declares for this section (e.g.
              the pinned bar's height and icon size). Ranges only — that's
              what a size is. */}
          {/* Set-then-slide, like every other size row (house rule). */}
          {(def.configFields || []).filter((f) => f.section === "ui" && f.type === "range").map((f) => (
            <SliderRow key={f.key} label={applyTerms(f.label, t)}
              value={settings[f.key]} fallback={f.default ?? 0}
              min={f.min ?? 0} max={f.max ?? 100} step={f.step ?? 1} unit={f.unit || "px"}
              onChange={(v) => onSettings(widget.instanceId, { [f.key]: v })}
              onReset={() => onSettings(widget.instanceId, { [f.key]: "" })} />
          ))}

          <div className="space-y-3 pt-2 border-t border-border/30">
            {/* Body and header type, side by side as two matching rows.
                The header font reaches the widget's titles/headings (h1–h4
                and the display face) — the body font never did, which is
                why the header widget's name wasn't restyleable. Both take
                uploaded custom fonts, and each carries its own style chips
                (bold / italic / small caps). Standard on every widget. */}
            {[
              { label: "Font", fontKey: "font", stylesKey: "fontStyles" },
              { label: "Header font", fontKey: "headerFont", stylesKey: "headerFontStyles" },
            ].map(({ label, fontKey, stylesKey }) => {
              const styles = Array.isArray(settings[stylesKey]) ? settings[stylesKey] : [];
              const toggleStyle = (id) => {
                let next = styles.includes(id) ? styles.filter((x) => x !== id) : [...styles, id];
                // Bold and Light are opposite weights — picking one drops
                // the other.
                if (id === "bold" && next.includes("bold")) next = next.filter((x) => x !== "light");
                if (id === "light" && next.includes("light")) next = next.filter((x) => x !== "bold");
                onSettings(widget.instanceId, { [stylesKey]: next });
              };
              const chipPreview = {
                bold: { fontWeight: 700 },
                light: { fontWeight: 300 },
                italic: { fontStyle: "italic" },
                underline: { textDecorationLine: "underline" },
                strikethrough: { textDecorationLine: "line-through" },
                smallcaps: { fontVariant: "small-caps" },
                uppercase: { textTransform: "uppercase", fontSize: "0.625rem" },
              };
              return (
                <div key={fontKey}>
                  <label className="text-xs font-medium block mb-1">{label}</label>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 min-w-0">
                      <SearchableSelect
                        value={settings[fontKey] || ""}
                        onChange={(v) => onSettings(widget.instanceId, { [fontKey]: v || "" })}
                        // Includes the user's own uploaded fonts, not just
                        // the built-in catalogue (owner rule).
                        options={fontOptions}
                        placeholder="Use the app font"
                        searchPlaceholder="Search fonts…"
                        renderOption={(o) => (
                          <span style={{ fontFamily: o.id || undefined }}>{o.label}</span>
                        )}
                      />
                    </div>
                    <FontUploadButton onUploaded={(family) => onSettings(widget.instanceId, { [fontKey]: family })} />
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {FONT_STYLE_OPTIONS.map(({ id, label: chip }) => (
                      <button key={id} type="button" aria-pressed={styles.includes(id)}
                        onClick={() => toggleStyle(id)}
                        className={`text-[0.6875rem] px-2.5 py-1 rounded-full border ${
                          styles.includes(id) ? "border-primary/60 bg-primary/10 text-primary" : "border-border/50 text-muted-foreground"
                        }`}
                        style={chipPreview[id]}>
                        {chip}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}

            <SliderRow label="Corner radius" value={settings.radius} fallback={12}
              min={0} max={32} unit="px"
              onChange={(v) => onSettings(widget.instanceId, { radius: v })}
              onReset={() => onSettings(widget.instanceId, { radius: "" })} />

            {/* Split (owner ask): Border width scales the borders INSIDE
                the widget; Element outline is the widget's own box shell
                (what Border width used to mean). */}
            <SliderRow label="Border width" value={settings.borderW} fallback={1}
              min={0} max={8} unit="px"
              onChange={(v) => onSettings(widget.instanceId, { borderW: v })}
              onReset={() => onSettings(widget.instanceId, { borderW: "" })} />

            <SliderRow label="Element outline" value={settings.outlineW} fallback={1}
              min={0} max={8} unit="px"
              onChange={(v) => onSettings(widget.instanceId, { outlineW: v })}
              onReset={() => onSettings(widget.instanceId, { outlineW: "" })} />

            <SliderRow label="Text size" value={settings.fontScale} fallback={100}
              min={70} max={160} unit="%"
              onChange={(v) => onSettings(widget.instanceId, { fontScale: v })}
              onReset={() => onSettings(widget.instanceId, { fontScale: "" })} />

            <SliderRow label="Inner spacing" value={settings.padding} fallback={12}
              min={0} max={32} unit="px"
              onChange={(v) => onSettings(widget.instanceId, { padding: v })}
              onReset={() => onSettings(widget.instanceId, { padding: "" })} />

            <div className="grid grid-cols-1 min-[420px]:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium block mb-1">Border style</label>
                <div className="flex flex-wrap gap-1">
                  {BORDER_STYLES.map((v) => (
                    <button key={v} type="button"
                      onClick={() => onSettings(widget.instanceId, { borderStyle: settings.borderStyle === v ? "" : v })}
                      className={`text-[0.6875rem] px-2 py-1 rounded-full border ${
                        settings.borderStyle === v ? "border-primary/60 bg-primary/10 text-primary" : "border-border/50 text-muted-foreground"
                      }`}>{v}</button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium block mb-1">Shadow</label>
              <div className="flex flex-wrap gap-1">
                {Object.keys(SHADOW_PRESETS).map((v) => (
                  <button key={v} type="button"
                    onClick={() => onSettings(widget.instanceId, { shadow: settings.shadow === v ? "" : v })}
                    className={`text-xs px-2.5 py-1 rounded-full border ${
                      settings.shadow === v ? "border-primary/60 bg-primary/10 text-primary" : "border-border/50 text-muted-foreground"
                    }`}>{v}</button>
                ))}
              </div>
            </div>
          </div>
          </SubSection>

          <SubSection title="Colors & background" icon={Palette}>
          <div className="space-y-3">
            {/* Four swatches on one line. The name, hex field, opacity,
                Clear and "use the app colour" all live inside each picker's
                popover — labelling them in the row squeezed the text into
                unreadable vertical slivers on a narrow sheet.
                Opacity sits with its OWN colour rather than applying to the
                whole widget, so you can ghost the text, see through the
                border, or fade a gradient out independently. Dragging one
                anchors to the live colour so there's something to fade. */}
            <div>
              <label className="text-xs font-medium block mb-1.5">Colours</label>
              <div className="flex items-center gap-3">
                <ColorPicker compact label="Highlight colour"
                  value={settings.accent || live.accent || "#3b82f6"}
                  onChange={(v) => onSettings(widget.instanceId, { accent: v })}
                  opacity={{ value: settings.accentOpacity, onChange: (v) => setAlpha("accent", "accentOpacity", v, live.accent || "#3b82f6") }}
                  onClear={() => onSettings(widget.instanceId, { accent: "", accentOpacity: "" })}
                  extraAction={{ label: "Use the app colour", onClick: () => onSettings(widget.instanceId, { accent: "", accentOpacity: "" }) }} />
                <ColorPicker compact label="Background"
                  value={settings.bg || live.bg || "#111827"}
                  onChange={(v) => onSettings(widget.instanceId, { bg: v })}
                  opacity={{ value: settings.bgOpacity, onChange: (v) => setAlpha("bg", "bgOpacity", v, live.bg || "#111827") }}
                  onClear={() => onSettings(widget.instanceId, { bg: "", bgOpacity: "" })} />
                <ColorPicker compact label="Text colour"
                  value={settings.textColor || live.textColor || "#e5e7eb"}
                  onChange={(v) => onSettings(widget.instanceId, { textColor: v })}
                  opacity={{ value: settings.textOpacity, onChange: (v) => setAlpha("textColor", "textOpacity", v, live.textColor || "#e5e7eb") }}
                  onClear={() => onSettings(widget.instanceId, { textColor: "", textOpacity: "" })} />
                <ColorPicker compact label="Border colour"
                  value={settings.borderColor || live.borderColor || "#3b82f6"}
                  onChange={(v) => onSettings(widget.instanceId, { borderColor: v })}
                  opacity={{ value: settings.borderOpacity, onChange: (v) => setAlpha("borderColor", "borderOpacity", v, live.borderColor || "#3b82f6") }}
                  onClear={() => onSettings(widget.instanceId, { borderColor: "", borderOpacity: "" })} />
              </div>
            </div>
            {/* Background gradient — a layer OVER the background colour
                above. A toggle owns it: swatches only show while it's on
                (two always-visible pickers read as unrelated colours). */}
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <label className="text-xs font-medium">Background gradient</label>
                <Switch checked={!!gradOn} onCheckedChange={(on) => {
                  if (on) {
                    onSettings(widget.instanceId, {
                      gradFrom: gradHex(effective.gradFrom) || live.bg || "#38bdf8",
                      gradTo: gradHex(effective.gradTo) || "#6ee7b7",
                    });
                  } else {
                    onSettings(widget.instanceId, { gradFrom: "", gradTo: "", gradFromOpacity: "", gradToOpacity: "", gradAngle: "" });
                  }
                }} aria-label="Background gradient" />
              </div>
              {gradOn && (
                <>
                  <div className="flex items-center gap-3">
                    <ColorPicker compact label="From"
                      value={gradHex(effective.gradFrom) || live.bg || "#38bdf8"}
                      onChange={(v) => onSettings(widget.instanceId, { gradFrom: v, ...(gradHex(settings.gradTo) ? {} : { gradTo: gradHex(effective.gradTo) || "#6ee7b7" }) })}
                      opacity={{ value: settings.gradFromOpacity ?? effective.gradFromOpacity, onChange: (v) => setAlpha("gradFrom", "gradFromOpacity", v, gradHex(effective.gradFrom) || live.bg || "#38bdf8") }}
                      onClear={() => onSettings(widget.instanceId, { gradFrom: "", gradTo: "", gradFromOpacity: "", gradToOpacity: "" })} />
                    <ColorPicker compact label="To"
                      value={gradHex(effective.gradTo) || "#6ee7b7"}
                      onChange={(v) => onSettings(widget.instanceId, { gradTo: v, ...(gradHex(settings.gradFrom) ? {} : { gradFrom: gradHex(effective.gradFrom) || live.bg || "#38bdf8" }) })}
                      opacity={{ value: settings.gradToOpacity ?? effective.gradToOpacity, onChange: (v) => setAlpha("gradTo", "gradToOpacity", v, gradHex(effective.gradTo) || "#6ee7b7") }}
                      onClear={() => onSettings(widget.instanceId, { gradFrom: "", gradTo: "", gradFromOpacity: "", gradToOpacity: "" })} />
                  </div>
                  <SliderRow label="Gradient angle" value={settings.gradAngle} fallback={Number(effective.gradAngle) || 135}
                    min={0} max={360} step={15} unit="°"
                    onChange={(v) => onSettings(widget.instanceId, { gradAngle: v })}
                    onReset={() => onSettings(widget.instanceId, { gradAngle: "" })} />
                </>
              )}
            </div>

            <SliderRow label="Frosted blur" value={settings.blur} fallback={0}
              min={0} max={24} unit="px"
              onChange={(v) => onSettings(widget.instanceId, { blur: v })}
              onReset={() => onSettings(widget.instanceId, { blur: "" })} />

            <div>
              <label className="text-xs font-medium block mb-1">Background image</label>
              <div className="flex items-center gap-2 flex-wrap">
                <button type="button" onClick={() => onPickBackground?.(widget.instanceId)}
                  className="h-9 px-3 rounded-lg border border-border text-xs flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5" /> {settings.bgImage ? "Change" : "Choose"}
                </button>
                {settings.bgImage && (
                  <>
                    <div className="flex gap-1">
                      {["cover", "contain", "repeat"].map((v) => (
                        <button key={v} type="button" onClick={() => onSettings(widget.instanceId, { bgSize: v })}
                          className={`text-xs px-2 py-1 rounded-full border ${
                            (settings.bgSize || "cover") === v ? "border-primary/60 bg-primary/10 text-primary" : "border-border/50 text-muted-foreground"
                          }`}>{v}</button>
                      ))}
                    </div>
                    <button type="button" onClick={() => onSettings(widget.instanceId, { bgImage: "" })}
                      className="text-xs px-2 py-1 rounded-full border border-border/50 text-muted-foreground flex-shrink-0 whitespace-nowrap">Remove</button>
                  </>
                )}
              </div>
            </div>

            {/* Advanced — per-side spacing overrides. Collapsed: these are
                the escape hatches, not the everyday controls. */}
            <div>
              <button type="button" onClick={() => setAdvOpen((v) => !v)}
                className="w-full flex items-center justify-between text-xs font-medium py-1">
                <span>Advanced</span>
                <ChevronDown className="w-3.5 h-3.5" style={{ transform: advOpen ? "rotate(180deg)" : "none", transition: "transform .18s" }} />
              </button>
              {advOpen && (
                <div className="space-y-2 pt-1">
                  {[["padTop", "Top spacing"], ["padBottom", "Bottom spacing"], ["padLeft", "Left spacing"], ["padRight", "Right spacing"]].map(([key, label]) => (
                    <SliderRow key={key} label={label} value={settings[key]} fallback={settings.padding ?? 12}
                      min={0} max={48} unit="px"
                      onChange={(v) => onSettings(widget.instanceId, { [key]: v })}
                      onReset={() => onSettings(widget.instanceId, { [key]: "" })} />
                  ))}
                  {/* Per-side OUTLINE widths — each side of the widget's
                      box can depart from the uniform Element outline. */}
                  {[["borderTopW", "Top outline"], ["borderBottomW", "Bottom outline"], ["borderLeftW", "Left outline"], ["borderRightW", "Right outline"]].map(([key, label]) => (
                    <SliderRow key={key} label={label} value={settings[key]} fallback={settings.outlineW ?? 1}
                      min={0} max={8} unit="px"
                      onChange={(v) => onSettings(widget.instanceId, { [key]: v })}
                      onReset={() => onSettings(widget.instanceId, { [key]: "" })} />
                  ))}
                </div>
              )}
            </div>

            {/* The escape hatch: your own CSS, scoped to this widget. */}
            <div>
              <button type="button" onClick={() => setCssOpen((v) => !v)}
                className="w-full flex items-center justify-between text-xs font-medium py-1">
                <span>Your own CSS{ownCss ? " — in use" : ""}</span>
                <ChevronDown className="w-3.5 h-3.5" style={{ transform: cssOpen ? "rotate(180deg)" : "none", transition: "transform .18s" }} />
              </button>
              {cssOpen && (
                <>
                  <DebouncedText multiline rows={5} value={ownCss}
                    placeholder={"border-image: url(...) 30 round;\nletter-spacing: .04em;"}
                    onCommit={(v) => onSettings(widget.instanceId, { css: v })}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-xs font-mono resize-y focus:outline-none focus:ring-1 focus:ring-ring" />
                  <p className="text-[0.6875rem] text-muted-foreground mt-1">
                    Plain CSS declarations, applied to this widget only. Anything CSS can do — border images, gradients, filters.
                  </p>
                </>
              )}
            </div>
          </div>
          </SubSection>

          <SubSection title="Presets">
          {/* Style presets — collapsed, because nine full-width cards open by
              default buried everything else in this sheet. */}
          <div>
            <button type="button" onClick={() => setStyleOpen((v) => !v)}
              className="w-full flex items-center justify-between text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground py-1">
              <span>Style preset{styleOverride ? ` — ${HOME_STYLES.find((x) => x.id === styleOverride)?.label}` : " — inherit"}</span>
              <ChevronDown className="w-3.5 h-3.5" style={{ transform: styleOpen ? "rotate(180deg)" : "none", transition: "transform .18s" }} />
            </button>
            <div className="space-y-1" hidden={!styleOpen}>
              {naming ? (
                <div className="space-y-2 pb-1">
                  <div className="flex gap-1.5">
                    <input autoFocus value={styleName} onChange={(e) => setStyleName(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") saveStyle(); if (e.key === "Escape") setNaming(false); }}
                      placeholder="Name this style" maxLength={40}
                      className="flex-1 h-8 px-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
                    <button type="button" onClick={saveStyle} disabled={!styleName.trim() || saveGroups.length === 0}
                      className="text-xs px-2.5 py-1.5 rounded-lg border border-primary/50 text-primary disabled:opacity-40">Save</button>
                    <button type="button" onClick={() => setNaming(false)}
                      className="text-xs px-2.5 py-1.5 rounded-lg border border-border/50 text-muted-foreground">Cancel</button>
                  </div>
                  {/* What the style carries. Leave them all on and it's a
                      whole look; untick some and it becomes a partial style
                      you can lay over anything — which is why saved styles
                      show what they touch. */}
                  <div className="flex flex-wrap gap-1">
                    {LOOK_GROUPS.map((g) => {
                      const on = saveGroups.includes(g.id);
                      return (
                        <button key={g.id} type="button"
                          onClick={() => setSaveGroups((prev) => (on ? prev.filter((x) => x !== g.id) : [...prev, g.id]))}
                          aria-pressed={on}
                          className={`text-[0.6875rem] px-2 py-1 rounded-full border ${
                            on ? "border-primary/60 bg-primary/10 text-primary" : "border-border/50 text-muted-foreground"
                          }`}>{g.label}</button>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="flex gap-1.5 pb-1">
                  <button type="button" onClick={() => { setStyleName(""); setNaming(true); }}
                    className="text-xs px-2.5 py-1.5 rounded-lg border border-primary/50 text-primary">
                    Save this look as a style
                  </button>
                </div>
              )}
              {userStyles.map((st) => {
                const on = settings.style === `${USER_STYLE_PREFIX}${st.id}`;
                const cov = lookCoverage(st.look || {});
                return (
                  <div key={st.id}>
                  <div className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${
                    on ? "border-primary/60 bg-primary/10" : "border-border/40"
                  }`}>
                    <button type="button" className="flex-1 text-left text-sm font-medium min-w-0"
                      onClick={() => onSettings(widget.instanceId, { style: `${USER_STYLE_PREFIX}${st.id}` })}>
                      <span className="truncate block">{st.label}</span>
                      <span className="text-xs text-muted-foreground block">Yours</span>
                    </button>
                    {/* A style that decides everything needs no caveat. One
                        that leaves parts alone says so, and the star opens
                        exactly what it does and doesn't touch. */}
                    {!cov.complete && (
                      <button type="button"
                        aria-label={`What "${st.label}" changes`}
                        title="Partial style — see what it changes"
                        onClick={() => setExclusionsFor(exclusionsFor === st.id ? null : st.id)}
                        className={`p-1 flex-shrink-0 ${exclusionsFor === st.id ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                        <Star className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button type="button" aria-label={`Delete ${st.label}`}
                      onClick={async () => {
                        const ok = await confirm({
                          title: `Delete "${st.label}"?`,
                          body: "Widgets using it go back to inheriting the page style. Their own tweaks stay.",
                          confirmLabel: "Delete", destructive: true,
                        });
                        if (ok) onDeleteStyle?.(st.id);
                      }}
                      className="p-1 text-muted-foreground hover:text-destructive">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  {exclusionsFor === st.id && (
                    <div className="mt-1 mb-1 px-3 py-2 rounded-lg border border-border/40 bg-muted/30 space-y-1.5">
                      <div>
                        <p className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground">Changes</p>
                        <p className="text-xs">{cov.covers.map((g) => g.label).join(", ") || "nothing"}</p>
                      </div>
                      <div>
                        <p className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground">Leaves alone</p>
                        <p className="text-xs">{cov.leaves.map((g) => g.label).join(", ")}</p>
                      </div>
                    </div>
                  )}
                  </div>
                );
              })}
              <button
                type="button"
                onClick={() => onSettings(widget.instanceId, { style: "" })}
                className={`w-full text-left px-3 py-2 rounded-lg border text-sm transition-all ${
                  !styleOverride
                    ? "border-primary/60 bg-primary/10"
                    : "border-border/40 hover:border-border"
                }`}
              >
                <span className="font-medium">Inherit page style</span>
                <span className="text-xs text-muted-foreground block">Currently “{pageStyleLabel}”</span>
              </button>
              {/* The two catalogues fold away behind labelled groups —
                  the flat run of ~30 full-width cards buried the sheet
                  (owner report), and nothing said how the two differ. */}
              <div className="rounded-lg border border-border/40 overflow-hidden mt-1">
                <button type="button" onClick={() => setBuiltinOpen((v) => !v)} aria-expanded={builtinOpen}
                  className="w-full flex items-center gap-2 px-3 py-2.5 bg-muted/15 hover:bg-muted/30 text-left">
                  <span className="flex-1 min-w-0">
                    <span className="text-sm font-medium block">Widget styles{styleOverride ? ` — ${HOME_STYLES.find((x) => x.id === styleOverride)?.label}` : ""}</span>
                    <span className="text-[0.6875rem] text-muted-foreground block">Ready-made looks for the widget's box</span>
                  </span>
                  <span className="text-[0.6875rem] text-muted-foreground tabular-nums flex-shrink-0">{HOME_STYLES.length}</span>
                  <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform flex-shrink-0 ${builtinOpen ? "rotate-180" : ""}`} />
                </button>
                {builtinOpen && (
                  <div className="px-2 py-2 space-y-1 border-t border-border/30">
                    {HOME_STYLES.map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => onSettings(widget.instanceId, { style: s.id })}
                        className={`w-full text-left px-3 py-2 rounded-lg border text-sm transition-all ${
                          styleOverride === s.id
                            ? "border-primary/60 bg-primary/10"
                            : "border-border/40 hover:border-border"
                        }`}
                      >
                        <span className="font-medium">{s.label}</span>
                        <span className="text-xs text-muted-foreground block">{s.description}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {/* The user's app themes, translated into widget looks
                  (owner request). Applying one writes the look onto this
                  widget, so it stays tweakable afterwards. */}
              {themeLookEntries.length > 0 && (
                <div className="rounded-lg border border-border/40 overflow-hidden">
                  <button type="button" onClick={() => setThemesOpen((v) => !v)} aria-expanded={themesOpen}
                    className="w-full flex items-center gap-2 px-3 py-2.5 bg-muted/15 hover:bg-muted/30 text-left">
                    <span className="flex-1 min-w-0">
                      <span className="text-sm font-medium block">From your app themes</span>
                      <span className="text-[0.6875rem] text-muted-foreground block">Copies a theme's colours &amp; font onto this widget</span>
                    </span>
                    <span className="text-[0.6875rem] text-muted-foreground tabular-nums flex-shrink-0">{themeLookEntries.length}</span>
                    <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform flex-shrink-0 ${themesOpen ? "rotate-180" : ""}`} />
                  </button>
                  {themesOpen && (
                    <div className="px-2 py-2 space-y-1 border-t border-border/30">
                      {themeLookEntries.map(({ name, preset, mine }) => (
                        <button
                          key={`theme_${name}`}
                          type="button"
                          onClick={() => onSettings(widget.instanceId, { ...themeToLook(preset, isDarkMode), style: "" })}
                          className="w-full text-left px-3 py-2 rounded-lg border border-border/40 hover:border-border text-sm transition-all flex items-center gap-2.5"
                        >
                          <span className="w-6 h-6 rounded-md border border-border/50 flex-shrink-0"
                            style={{ backgroundImage: `linear-gradient(135deg, ${(preset.dark || preset.light)?.surface || "#222"}, ${(preset.dark || preset.light)?.primary || "#888"})` }} />
                          <span className="min-w-0">
                            <span className="font-medium capitalize block truncate">{name}</span>
                            <span className="text-xs text-muted-foreground block">{mine ? "Your theme" : "Built-in theme"}</span>
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          </SubSection>

          {/* Icon override — app shortcuts only */}
          {widget.widgetId === "app_shortcut" && (
            <SubSection title="Icon">
            <div>
              <label className="text-[0.6875rem] font-semibold uppercase tracking-wide text-muted-foreground block mb-1">
                Icon
              </label>
              <div className="flex items-center gap-2">
                {iconPreview ? (
                  <img src={iconPreview} alt="" className="w-11 h-11 rounded-2xl object-cover border border-border/40" />
                ) : (
                  <span className="w-11 h-11 rounded-2xl border border-dashed border-border/50 flex items-center justify-center text-muted-foreground">
                    <ImageIcon className="w-4 h-4" />
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => setIconPickerOpen(true)}
                  className="text-xs px-3 py-1.5 rounded-full border border-border/50 text-muted-foreground hover:text-foreground"
                >
                  {settings.iconName ? `Icon: ${settings.iconName}` : "Choose icon…"}
                </button>
                <button
                  type="button"
                  onClick={() => onPickIcon(widget.instanceId)}
                  className="text-xs px-3 py-1.5 rounded-full border border-border/50 text-muted-foreground hover:text-foreground"
                >
                  Choose image…
                </button>
                <IconPicker open={iconPickerOpen} onClose={() => setIconPickerOpen(false)} allowImage={false}
                  current={settings.iconName || ""}
                  onPick={(o) => onSettings(widget.instanceId, { iconName: o.iconName || "" })} />
                {(settings.iconUrl || settings.iconName) && (
                  <button
                    type="button"
                    onClick={() => onSettings(widget.instanceId, { iconUrl: "", iconName: "" })}
                    aria-label="Remove custom icon"
                    className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded-lg text-muted-foreground hover:text-destructive"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
            </SubSection>
          )}
          <div className="pt-2 border-t border-border/50 space-y-2">
            {/* Copy this widget's look onto others — the alternative is
                re-setting eight fields per widget by hand. */}
            {onApplyLook && (
              <div className="rounded-lg border border-border/40 overflow-hidden">
                <button type="button" onClick={() => setApplyOpen((v) => !v)}
                  aria-expanded={applyOpen}
                  className="w-full flex items-center gap-2 px-3 py-2.5 bg-muted/15 hover:bg-muted/30 text-left">
                  <Copy className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                  <span className="flex-1 text-[0.6875rem] font-semibold uppercase tracking-wider text-muted-foreground">
                    Apply this look to…
                  </span>
                  <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform ${applyOpen ? "rotate-180" : ""}`} />
                </button>
                {applyOpen && (
                  <div className="px-3 py-3 space-y-1.5 border-t border-border/30">
                    {[
                      ["page", "All widgets on this page"],
                      ["all", "All widgets, every page"],
                      ["pick", "Pick widgets…"],
                    ].map(([scope, label]) => (
                      <button key={scope} type="button"
                        onClick={() => { setApplyOpen(false); onApplyLook(scope); }}
                        className="w-full text-left text-sm px-3 h-9 rounded-lg border border-border/50 hover:bg-muted/40">
                        {label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Undo every tweak at once — size, mode, name, look, alignment,
                content size and this widget's own options. */}
            <button
              type="button"
              onClick={async () => {
                const ok = await confirm({
                  title: `Reset ${settings.label || defLabel} to default?`,
                  body: "Its size, display mode, name, look and options all go back to how the widget ships. It stays on the page, and none of your data changes.",
                  confirmLabel: "Reset",
                });
                if (ok) onResetWidget?.(widget.instanceId);
              }}
              className="w-full flex items-center justify-center gap-2 h-10 rounded-lg border border-border/60 text-sm font-medium hover:bg-muted/50"
            >
              <RotateCcw className="w-4 h-4" /> Reset all
            </button>
            <button
              type="button"
              onClick={async () => {
                const ok = await confirm({
                  title: `Remove ${settings.label || defLabel}?`,
                  body: "It comes off this page. Nothing it shows is deleted, and you can add it back any time.",
                  confirmLabel: "Remove",
                  destructive: true,
                });
                if (ok) onRemove?.(widget.instanceId);
              }}
              className="w-full flex items-center justify-center gap-2 h-10 rounded-lg border border-destructive/40 text-destructive text-sm font-medium hover:bg-destructive/10"
            >
              <Trash2 className="w-4 h-4" /> Remove widget
            </button>
          </div>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
